<?php

defined( 'ABSPATH' ) || die('Trapaceando, hein');