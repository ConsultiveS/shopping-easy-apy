<?php
/**
 * Transparent checkout form.
 *
 * @author  DanSP
 * @package WooCommerce_EasyPayment/Templates
 * @version 2.12.5
 * @file ../includes/class-wc-easypayment-gateway.php
 * function payment_fields()  que trás os valores
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

$arr_methods = array(
    'credit_card' => $easypayment_credit_card,
    'boleto' => $easypayment_boleto,
    'carne' => "no", //$easypayment_carne,
    'pix' => $easypayment_pix,
    'subscription' => "no", //$easypayment_subscription
);

$arr_methods_translate = array(
    'credit_card' => __("Credit Card", "woocommerce-easypayment"),
    'boleto' => __("Billet", "woocommerce-easypayment"),
    'carne' => __("Slip", "woocommerce-easypayment"),
    'pix' => __("PIX", "woocommerce-easypayment"),
    'subscription' => __("Subscription", "woocommerce-easypayment")
);

$o = 0;
$nav_html = '';
foreach ($arr_methods as $chave => $valor) {
    if ($valor == 'yes') {
        $method2process[$chave] = $valor;

        $actived = $o == 0 ? 'active' : '';
        $aria_selected = $o == 0 ? 'true' : 'false';
        $checked = $o == 0 ? 'checked="checked"' : '';
        $method_sluged = str_replace('_de_', '_', str_replace('-', '_', sanitize_title($chave)));
        $method_sluged_arr[] = $method_sluged;

        $nav_html .= "
            <div class='mb-5 nav-link $actived' data-bs-toggle='tab' data-named='$method_sluged' data-bs-target='#nav-$method_sluged' type='button' role='tab' aria-controls='nav-$method_sluged' aria-selected='$aria_selected'>
                <input type='radio' name='easypayment_method' value='$method_sluged' id='nav-$method_sluged-tab' class='d-none' $checked>
                <label for='nav-$method_sluged-tab'>" . $arr_methods_translate[$chave] . "</label>
            </div>";
        $o++;
    }
}
$activeNow = [];
if (count($arr_methods) > 0) {

    foreach ($arr_methods as $ke => $va) {
        if ($va == "yes") {
            $activeNow[$ke] = true;
            break;
        }
    }
}
?>

<fieldset id="easypayment-payment-form"
    class="<?php echo 'storefront' === basename(get_template_directory()) ? 'woocommerce-easypayment-form-storefront' : ''; ?>"
    data-cart_total="<?php echo esc_attr(number_format($cart_total, 2, '.', '')); ?>">
    <!-- Tabs Begin -->
    <input type="hidden" name="easypayment_cart_total"
        value="<?php echo esc_attr(number_format($cart_total, 2, '.', '')); ?>" readonly="readonly" />
    <input type="hidden" name="easypayment_method" id="easypayment_method" value="<?php echo $method_sluged_arr[0]; ?>"
        readonly="readonly" />
    <nav>
        <div class="nav nav-tabs" id="nav-tab" role="tablist">
            <?php echo $nav_html; ?>
        </div>
    </nav>

    <div class="tab-content" id="nav-tabContent">
        <?php
        if ($easypayment_credit_card == 'yes'):
            ?>
            <!-- START - CARTÃO -->
            <div class="tab-pane fade <?php _e(isset($activeNow['credit_card']) && $activeNow['credit_card'] == true ? "show active" : "") ?>"
                id="nav-credit_card" role="tabpanel" aria-labelledby="nav-credit_card-tab">
                <div class="container cartao_plastico preload">
                    <!-- <?php cartao_de_plastico(); ?>                 -->
                    <div class="row mb-4">
                        <div class="col">
                            <div class="form-floating mb-6">
                                <input type="text" class="form-control" name="cartao_credito[holder_name]"
                                    id="cartao_credito[holder_name]" maxlength="20">
                                <label
                                    for="cartao_credito[holder_name]"><?php _e("Holder name", "woocommerce-easypayment") ?></label>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-floating mb-6">
                                <input type="text" class="form-control format-cpf" name="cartao_credito[holder_cpf_cnpj]"
                                    id="cartao_credito[holder_cpf_cnpj]">
                                <label
                                    for="cartao_credito[holder_cpf_cnpj]"><?php _e("CPF", "woocommerce-easypayment") ?></label>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col">
                            <div class="form-floating mb-6">
                                <input type="text" class="form-control" name="cartao_credito[card_number]"
                                    id="cartao_credito[card_number]" maxlength="19" pattern="[0-9]*" inputmode="numeric">
                                <svg id="ccicon" class="ccicon" width="750" height="471" viewBox="0 0 750 471" version="1.1"
                                    xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"></svg>
                                <?php
                                if ((isset($card_demo) && $card_demo == 'yes') && current_user_can('manage_options')) {
                                    echo '<label for="cartao_credito[card_number]">' . __("Card number", "woocommerce-easypayment") . '</label><span id="generatecard">' . __("Random test", "woocommerce-easypayment") . '</span>';
                                }
                                ?>
                                <label for="card_number"><?php _e("Card number", "woocommerce-easypayment") ?></label>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col">
                            <div class="form-floating mb-6">
                                <input type="text" class="form-control" name="cartao_credito[cvv]" id="cartao_credito[cvv]"
                                    pattern="[0-9]*" inputmode="numeric">
                                <label for="cartao_credito[cvv]"><?php _e("CVV", "woocommerce-easypayment") ?></label>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-floating mb-6">
                                <input type="text" class="form-control" name="cartao_credito[expiration]"
                                    id="cartao_credito[expiration]" pattern="[0-9]*" inputmode="numeric">
                                <label for="cartao_credito[expiration]"><?php _e("Expiration", "woocommerce-easypayment") ?>
                                    (mm/yy)</label>
                            </div>
                        </div>
                    </div>
                    <?php
                    $totalIncart = number_format($cart_total, 2, '.', '');
                    $valorMinimo = WC_EASYPAYMENT_CARTAO_CREDITO_PRECO_MINIMO;
                    $valorMaximo = WC_EASYPAYMENT_CARTAO_CREDITO_MAX_PARCELA;
                    $taxaFixa = WC_EASYPAYMENT_CARTAO_CREDITO_TAXA_FIXA;
                    $ratesEasyPayment = WC_EASYPAYMENT_DEFAULT_RATES;

                    $aVista = wc_price(number_format($cart_total, 2, '.', ''));
                    $outerParcelas = '';
                    foreach ($ratesEasyPayment as $rateInstallment => $rateInstallmentValue) {
                        $priceFloat = ((($cart_total / 100) * $rateInstallmentValue) + $cart_total) / $rateInstallment;
                        $price = wc_price(number_format($priceFloat, 2, '.', ''));

                        if ($priceFloat <= $valorMinimo)
                            break;

                        if ($rateInstallmentValue > $valorMinimo) {
                            $outerParcelas .= "<option value='$rateInstallment'>" . sprintf(__("%sx of %s", "woocommerce-easypayment"), $rateInstallment, $price) . "</option>";
                        } else {
                            $outerParcelas .= "<option value='1' selected>" . sprintf(__("In cash by %s", "woocommerce-easypayment"), $aVista) . "</option>";
                        }
                    }

                    ?>
                    <div class="row mb-4">
                        <div class="col">
                            <div class="form-floating">
                                <select class="form-select" name="cartao_credito[number_installments]"
                                    id="cartao_credito[number_installments]" aria-label="Floating label select">
                                    <?php echo $outerParcelas; ?>
                                </select>
                                <label
                                    for="cartao_credito[number_installments]"><?php _e("Installments", "woocommerce-easypayment") ?></label>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <!-- END - CARTÃO -->
            <?php
        endif;

        if ($easypayment_boleto == 'yes'): ?>
            <!-- START - BOLETO -->
            <div class="tab-pane fade <?php _e(isset($activeNow['boleto']) && $activeNow['boleto'] == true ? "show active" : "") ?>"
                id="nav-boleto" role="tabpanel" aria-labelledby="nav-boleto-tab">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="easypaymentBoletoMaster"></div>
                        </div>
                        <div class="col-12 easypayment_message_boleto">
                            <?php
                            _e(sprintf(__("* After clicking on \"Proceed to payment\" you will have access to the bank slip that you can print and pay on your internet banking or in a lottery, the value is <b>%s</b>", "wocommerce-easypayment"), wc_price(number_format($cart_total, 2, '.', ''))));
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END - BOLETO -->
            <?php
        endif;

        if ($easypayment_carne == 'yes'):
            ?>
            <!-- START - CARNÊ -->
            <div class="tab-pane fade" id="nav-carne" role="tabpanel" aria-labelledby="nav-carne-tab">
                <div class="container">
                    <?php
                    $totalIncartCarne = number_format($cart_total, 2, '.', '');
                    $valorMinimo = WC_EASYPAYMENT_CARNE_PRECO_MINIMO;
                    $valorMaximo = WC_EASYPAYMENT_CARNE_MAX_PARCELA;

                    for ($c = 1; $c < $totalIncartCarne; $c++) {
                        $val_installmentCarne = $totalIncartCarne / $c;
                        if ($val_installmentCarne >= $valorMinimo) {
                            $init_installmentsCarne[] = $val_installmentCarne;
                        }
                    }
                    $outerParcelasCarne = '';
                    $aVistaCarne = wc_price(number_format($cart_total, 2, '.', ''));
                    if (isset($init_installmentsCarne) && count($init_installmentsCarne) > 0) {
                        $cpp = 0;
                        $outerParcelasCarne .= "<option value='' selected>" . __("-- Select a parcel --", "woocommerce-easypayment") . "</option>";
                        foreach ($init_installmentsCarne as $valor_parcelas_carne) {
                            $cpp++;
                            $parcelado_carne = wc_price(number_format($valor_parcelas_carne + $taxaFixa, 2, '.', ''));
                            if ($valor_parcelas_carne >= $valorMinimo) {
                                if ($cpp == 1) {
                                    //$outerParcelasCarne .= "<option value='$cpp'>A vista por $aVistaCarne</option>";
                                } else {
                                    $outerParcelasCarne .= "<option value='$cpp'>" . sprintf(__("Pay in up to %s installments of %s", "woocommerce-easypayment"), $cpp, $parcelado_carne) . "</option>";
                                }
                                if ($valorMaximo <= $cpp)
                                    break;
                            }
                        }
                    } else {
                        $outerParcelasCarne .= "<option value='1' selected>" . sprintf(__("Pay the amount of %s upfront", "woocommerce-easypayment"), $aVistaCarne) . "Pague o valor de sss a vista</option>";
                    }
                    ?>
                    <div class="row mb-4">
                        <div class="col">
                            <?php
                            _e(sprintf("Payment in the carnê you can spread your purchases directly on the boleto in up to 12 interest-free installments! the first installment will be on the day %s", "woocommerce-easypayment"), date("d/m/Y", strtotime(WC_EASYPAYMENT_CARNE_LIMITE)));
                            ?>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <div class="col">
                            <div class="form-floating">
                                <select class="form-select" name="carne[number_installments]"
                                    id="carne[number_installments]" aria-label="Floating label select">
                                    <?php echo $outerParcelasCarne; ?>
                                </select>
                                <label
                                    for="carne[number_installments]"><?php _e("Installments", "woocommerce-easypayment") ?></label>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!-- END - CARNÊ -->
            <?php
        endif;

        if ($easypayment_pix == 'yes'): ?>
            <!-- START - PIX -->
            <div class="tab-pane fade" id="nav-pix" role="tabpanel" aria-labelledby="nav-pix-tab">
                <div class="col-12">
                    <div class="easypaymentPixMaster"></div>
                </div>
                <?php _e("Pay with PIX, a Brazilian payment method, the best payment system in the world!", "woocommerce-easypayment") ?>
            </div>
            <!-- END - PIX -->
            <?php
        endif;

        if ($easypayment_subscription == 'yes'):
            ?>
            <!-- START - SUBSCRIPTION -->
            <div class="tab-pane fade" id="nav-subscription" role="tabpanel" aria-labelledby="nav-subscription-tab">
                <?php _e("Subscription", "woocommerce-easypayment") ?>
            </div>
            <!-- START - SUBSCRIPTION -->
            <?php
        endif;
        ?>
    </div>
    <!-- Tabs End -->
</fieldset>
<!-- <script src='https://cdnjs.cloudflare.com/ajax/libs/imask/3.4.0/imask.min.js'></script>
<script src="<?php echo WC_EASYPAYMENT_PLUGIN_URL; ?>/assets/js/frontend/transparent-checkout.js"></script> -->
<script>
    jQuery('body').ready(function () {
        jQuery('#bootstrap-css').remove(); //Remove bootstrap older
    });
</script>


<?php

function cartao_de_plastico()
{
    return;
    ?>
    <div class="creditcard">
        <div class="front">
            <div id="ccsingle"></div>
            <svg version="1.1" id="cardfront" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                x="0px" y="0px" viewBox="0 0 750 471" style="enable-background:new 0 0 750 471;" xml:space="preserve">
                <g id="Front">
                    <g id="CardBackground">
                        <g id="Page-1_1_">
                            <g id="amex_1_">
                                <path id="Rectangle-1_1_" class="lightcolor grey"
                                    d="M40,0h670c22.1,0,40,17.9,40,40v391c0,22.1-17.9,40-40,40H40c-22.1,0-40-17.9-40-40V40C0,17.9,17.9,0,40,0z" />
                            </g>
                        </g>
                        <path class="darkcolor greydark"
                            d="M750,431V193.2c-217.6-57.5-556.4-13.5-750,24.9V431c0,22.1,17.9,40,40,40h670C732.1,471,750,453.1,750,431z" />
                    </g>
                    <text transform="matrix(1 0 0 1 60.106 295.0121)" id="svgnumber" class="st2 st3 st4">0123 4567 8910
                        1112</text>
                    <text transform="matrix(1 0 0 1 54.1064 428.1723)" id="svgname"
                        class="st2 st5 st6"><?php _e("John Doe", "woocommerce-easypayment") ?></text>
                    <text transform="matrix(1 0 0 1 54.1074 389.8793)"
                        class="st7 st5 st8"><?php _e("Holder name", "woocommerce-easypayment") ?></text>
                    <text transform="matrix(1 0 0 1 479.7754 388.8793)"
                        class="st7 st5 st8"><?php _e("Expiration", "woocommerce-easypayment") ?></text>
                    <text transform="matrix(1 0 0 1 65.1054 241.5)"
                        class="st7 st5 st8"><?php _e("Card number", "woocommerce-easypayment") ?></text>
                    <g>
                        <text transform="matrix(1 0 0 1 574.4219 433.8095)" id="svgexpire" class="st2 st5 st9">01/23</text>
                        <text transform="matrix(1 0 0 1 479.3848 417.0097)"
                            class="st2 st10 st11"><?php _e("Valid", "woocommerce-easypayment") ?></text>
                        <text transform="matrix(1 0 0 1 479.3848 435.6762)"
                            class="st2 st10 st11"><?php _e("Until", "woocommerce-easypayment") ?></text>
                        <polygon class="st2" points="554.5,421 540.4,414.2 540.4,427.9" />
                    </g>
                    <g id="cchip">
                        <g>
                            <path class="st22"
                                d="M168.1,143.6H82.9c-10.2,0-18.5-8.3-18.5-18.5V74.9c0-10.2,8.3-18.5,18.5-18.5h85.3c10.2,0,18.5,8.3,18.5,18.5v50.2C186.6,135.3,178.3,143.6,168.1,143.6z" />
                        </g>
                        <g>
                            <g>
                                <rect x="82" y="70" class="st12" width="1.5" height="60" />
                            </g>
                            <g>
                                <rect x="167.4" y="70" class="st12" width="1.5" height="60" />
                            </g>
                            <g>
                                <path class="st12"
                                    d="M125.5,130.8c-10.2,0-18.5-8.3-18.5-18.5c0-4.6,1.7-8.9,4.7-12.3c-3-3.4-4.7-7.7-4.7-12.3c0-10.2,8.3-18.5,18.5-18.5s18.5,8.3,18.5,18.5c0,4.6-1.7,8.9-4.7,12.3c3,3.4,4.7,7.7,4.7,12.3C143.9,122.5,135.7,130.8,125.5,130.8z M125.5,70.8c-9.3,0-16.9,7.6-16.9,16.9c0,4.4,1.7,8.6,4.8,11.8l0.5,0.5l-0.5,0.5c-3.1,3.2-4.8,7.4-4.8,11.8c0,9.3,7.6,16.9,16.9,16.9s16.9-7.6,16.9-16.9c0-4.4-1.7-8.6-4.8-11.8l-0.5-0.5l0.5-0.5c3.1-3.2,4.8-7.4,4.8-11.8C142.4,78.4,134.8,70.8,125.5,70.8z" />
                            </g>
                            <g>
                                <rect x="82.8" y="82.1" class="st12" width="25.8" height="1.5" />
                            </g>
                            <g>
                                <rect x="82.8" y="117.9" class="st12" width="26.1" height="1.5" />
                            </g>
                            <g>
                                <rect x="142.4" y="82.1" class="st12" width="25.8" height="1.5" />
                            </g>
                            <g>
                                <rect x="142" y="117.9" class="st12" width="26.2" height="1.5" />
                            </g>
                        </g>
                    </g>
                </g>
                <g id="Back">
                </g>
            </svg>
        </div>
        <div class="back">
            <svg version="1.1" id="cardback" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                x="0px" y="0px" viewBox="0 0 750 471" style="enable-background:new 0 0 750 471;" xml:space="preserve">
                <g id="Front">
                    <line class="st0" x1="35.3" y1="10.4" x2="36.7" y2="11" />
                </g>
                <g id="Back">
                    <g id="Page-1_2_">
                        <g id="amex_2_">
                            <path id="Rectangle-1_2_" class="darkcolor greydark"
                                d="M40,0h670c22.1,0,40,17.9,40,40v391c0,22.1-17.9,40-40,40H40c-22.1,0-40-17.9-40-40V40C0,17.9,17.9,0,40,0z" />
                        </g>
                    </g>
                    <rect y="61.6" class="st2" width="750" height="78" />
                    <g>
                        <path class="st3"
                            d="M701.1,249.1H48.9c-3.3,0-6-2.7-6-6v-52.5c0-3.3,2.7-6,6-6h652.1c3.3,0,6,2.7,6,6v52.5C707.1,246.4,704.4,249.1,701.1,249.1z" />
                        <rect x="42.9" y="198.6" class="st4" width="664.1" height="10.5" />
                        <rect x="42.9" y="224.5" class="st4" width="664.1" height="10.5" />
                        <path class="st5"
                            d="M701.1,184.6H618h-8h-10v64.5h10h8h83.1c3.3,0,6-2.7,6-6v-52.5C707.1,187.3,704.4,184.6,701.1,184.6z" />
                    </g>
                    <text transform="matrix(1 0 0 1 621.999 227.2734)" id="svgsecurity" class="st6 st7">123</text>
                    <g class="st8">
                        <text transform="matrix(1 0 0 1 518.083 280.0879)"
                            class="st9 st6 st10"><?php _e("CVV", "woocommerce-easypayment") ?></text>
                    </g>
                    <rect x="58.1" y="378.6" class="st11" width="375.5" height="13.5" />
                    <rect x="58.1" y="405.6" class="st11" width="421.7" height="13.5" />
                    <text transform="matrix(1 0 0 1 59.5073 228.6099)" id="svgnameback"
                        class="st12 st13"><?php _e("John Doe", "woocommerce-easypayment") ?></text>
                </g>
            </svg>
        </div>
    </div>
    <div id="message_credit_card"></div>
    <?php
}