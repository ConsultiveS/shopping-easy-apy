<?php
/**
 * Receipt page error template
 *
 * @package WooCommerce_EasyPayment/Templates
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<ul class="woocommerce-error">
	<?php
	if( isset($response['error']) ){
    	foreach ( $response['error'] as $message ) :
    		echo "<li>$message</li>";
    	endforeach;
	} else {
	    echo "Ocorreu algum erro desconhecido!";
	}
	?>
</ul>

<a class="button cancel" href="<?php echo esc_url( $order->get_cancel_order_url() ); ?>"><?php esc_html_e( 'Click to try again', 'woocommerce-easypayment' ); ?></a>
