<?php
/**
 * Plugin START
 */

defined( 'ABSPATH' ) || exit;

define( 'EPMP_ME_FILE',             __FILE__ );
define( 'EPMP_ME_BASENAME',         plugin_basename( EPMP_ME_FILE ) );
define( 'EPMP_ME_URL',              plugin_dir_url( EPMP_ME_FILE ) );
define( 'EPMP_ME_PATH',             untrailingslashit( plugin_dir_path( EPMP_ME_FILE ) ) );
define( 'EPMP_ME_TEMPLATES_PATH',   EPMP_ME_PATH . '/templates/' );

define( 'EPMP_ME_PREFIX',        'epmp_me_' );
define( 'EPMP_ME_HIDDEN_PREFIX', '_' . EPMP_ME_PREFIX );

define( 'EPMP_ME_SLUG',           'epmp-me' ); //textdomain as well

// define( 'EPMP_ME_FONTS', EPMP_ME_URL . 'assets/fonts' );
// define( 'EPMP_ME_IMG',   EPMP_ME_URL . 'assets/images' );
define( 'EPMP_ME_JS',    EPMP_ME_URL . 'assets/js' );
// define( 'EPMP_ME_CSS',   EPMP_ME_URL . 'assets/css' );

/**
 *  Plugin activation hook
 */
//  echo EPMP_ME_BASENAME;
//  echo "<br />";
//  echo WC_EASYPAYMENT_PLUGIN_URL;
//  echo "<br />";
//  echo WC_EASYPAYMENT_PLUGIN_PATH;
//  echo "<br />";
//  echo 'EPMP_ME_PATH: '.EPMP_ME_PATH;
//  echo "<br />";
//  echo '/home2/rplaca81/homologacao.shoppingeasy.com.br/wp-content/plugins/woocommerce-easypayment/includes/e-net/epmp-melhorenvio';
//  echo "<br />";
//  echo EPMP_ME_PATH . '/includes/constants.php';
 //die();
function epmp_me_activate() {

    epmp_me_load_plugin_textdomain();

    /**
     *  Requires WooCommerce and WooCommerce Melhor Envio to be installed and active
     */
    if ( !epmp_me_dependencies_running() ) {

        deactivate_plugins( EPMP_ME_BASENAME );
        ob_start();
        ?>
        <p>
            <?php _e( 'Melhor Envio requires WooCommerce and Brazilian Market on WooCommerce to run. Please, install the plugin and try again', 'epmp-melhorenvio' );?>
        </p>
        <?php if(php_sapi_name() != 'cli'):?>
        <p>
            <a href='<?=admin_url( 'plugins.php' )?>' tile=''>
                <?php _e('Return to Plugins page', 'epmp-melhorenvio')?>
            </a>
        </p>
        <?php endif;

        $result = ob_get_clean();

        // checking for WP-cli calls
        echo (php_sapi_name() == 'cli') ? preg_replace('/\s+/S', " ",strip_tags( $result)) : $result;

        wp_die();

    }

}

register_activation_hook(__FILE__, 'epmp_me_activate' );

function epmp_me_dependencies_running() {
    return apply_filters(
        'epmp_me_dependencies_running',
        class_exists( 'WooCommerce' ) && class_exists( 'Extra_Checkout_Fields_For_Brazil' )
    );
}

function epmp_me_loadplugin(){

    if( epmp_me_dependencies_running() ) {

        $loaded = include_once EPMP_ME_PATH . '/includes/functions.php';

        if( $loaded ) {
            do_action( 'epmp_me_loaded' );
        }

        if( apply_filters( 'epmp_me_testing', false ) || defined( 'EPMP_ME_TESTING' ) && EPMP_ME_TESTING ){
	        include_once EPMP_ME_PATH . '/tests/bootstrap.php';
        }

    } else {
        add_action('admin_notices', 'epmp_me_plugin_not_loaded');
    }

}

add_action( 'plugins_loaded', 'epmp_me_loadplugin' );

add_action( 'plugins_loaded', 'epmp_me_load_plugin_textdomain', 11 );

function epmp_me_plugin_not_loaded(){
    ?>
    <div class="notice notice-warning is-dismissible">
        <p><strong><?php _e( 'Melhor Envio requires WooCommerce and Brazilian Market on WooCommerce to run. Please, install the plugin and try again', 'epmp-melhorenvio' );?></strong></p>
        <button type="button" class="notice-dismiss">
            <span class="screen-reader-text"><?php _e('Dismiss this notice.', 'epmp-melhorenvio')?></span>
        </button>
    </div>
    <?php
}

/**
 * Loading text domain
 */
function epmp_me_load_plugin_textdomain() {
    load_plugin_textdomain( 'epmp-melhorenvio', false, dirname( EPMP_ME_BASENAME ) . '/languages' );
}
