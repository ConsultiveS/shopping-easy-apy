<?php
namespace Epmp\ME;

use Epmp\ME\Payload\Options;
use Epmp\ME\Payload\Payload_File_Not_Found_Exception;
use Epmp\ME\Rest_API\Endpoint;
use Epmp\ME\Rest_API\Request;
use const Epmp\ME\Constants\{ DOCUMENT_TYPE_CPF, DOCUMENT_TYPE_CNPJ };
use const Epmp\ME\Payload\Constants\{ SERVICES, SHIPPING };
use function Epmp\ME\functions\format_postcode;
use function Epmp\ME\functions\get_agencies_list_by_state;
use function Epmp\ME\functions\get_services_list;
use function Epmp\ME\functions\payload_product_factory;
use function Epmp\ME\functions\request_payload_factory;

class Shipping_Method extends \WC_Shipping_Method {

	private $services;
	private $show_delivery_time;
	private $additional_time;
	private $debug;

	private $receipt;
	private $receiver_only;

	private $shipping_class_ids;

	// Shop data
	private $shop_name;
	private $shop_phone;
	private $shop_email;
	private $shop_document_type;
	private $shop_document;
	private $shop_company_document;
	private $shop_address;
	private $shop_complement;
	private $shop_number;
	private $shop_district;
	private $shop_city;
	private $shop_state;
	private $shop_agency;
	private $shop_postal_code;

	public function __construct( $instance_id = 0 ) {

		$this->id  			= 'epmp-melhorenvio';
		$this->instance_id 	= absint( $instance_id );
		$this->method_title = 'Melhor Envio (Art-i)';

		$this->supports = [
			'shipping-zones',
			'instance-settings',
		];

		$this->init_form_fields();


		$this->enabled            = $this->get_option( 'enabled' );
		$this->title              = $this->get_option( 'title' );
		$this->services 		  = $this->get_option( 'services', [] );
		$this->show_delivery_time = $this->get_option( 'show_delivery_time', 'yes' );
		$this->additional_time    = $this->get_option( 'additional_time', 0 );
		$this->debug 			  = $this->get_option( 'debug' );

		$this->receipt            = $this->get_option( 'receipt' );
		$this->receiver_only      = $this->get_option( 'receiver_only' );

		$this->shipping_class_ids  = $this->get_option( 'shipping_class_ids', [] );

		$this->shop_name             = $this->get_option( 'shop_name' );
		$this->shop_phone            = $this->get_option( 'shop_phone' );
		$this->shop_email            = $this->get_option( 'shop_email' );
		$this->shop_document_type    = $this->get_option( 'shop_document_type' );
		$this->shop_document         = $this->get_option( 'shop_document' );
		$this->shop_company_document = $this->get_option( 'shop_company_document' );
		$this->shop_cnae 			 = $this->get_option( 'shop_cnae' );
		$this->shop_address          = $this->get_option( 'shop_address' );
		$this->shop_complement       = $this->get_option( 'shop_complement' );
		$this->shop_number           = $this->get_option( 'shop_number' );
		$this->shop_district         = $this->get_option( 'shop_district' );
		$this->shop_city             = $this->get_option( 'shop_city' );
		$this->shop_state            = $this->get_option( 'shop_state' );
		$this->shop_agency           = $this->get_option( 'shop_agency', [] );
		$this->shop_postal_code      = $this->get_option( 'shop_postal_code' );

		if( $this->enabled && empty( $this->services ) ){
					// $notice = __( 'You don\'t have any services set for Melhor Envio method.', 'epmp-melhorenvio' );
					// \WC_Admin_Notices::add_custom_notice('epmp_me_' . $this->instance_id, $notice);
		}

		add_action( 'woocommerce_update_options_shipping_' . $this->id, [ $this, 'process_admin_options' ] );

		$this->enqueue_admin_scripts();

	}

	protected function enqueue_admin_scripts(){
		if( is_admin() ){
			wp_enqueue_script('epmp-me-melhorenvio-admin',  EPMP_ME_JS . '/admin-shipping-method.js', [ 'jquery' ] );
		}
	}

	/**
	 * Admin options fields.
	 */
	public function init_form_fields() {
		$this->instance_form_fields = [
			'title'           => [
				'title'       => __( 'Title', 'epmp-melhorenvio' ),
				'type'        => 'text',
				'description' => __( 'This controls the title which the user sees during checkout.', 'epmp-melhorenvio' ),
				'desc_tip'    => true,
				'default'     => __( 'Melhor Envio', 'epmp-melhorenvio' ),
			],
			'services'        => [
				'title'       => __( 'Services', 'epmp-melhorenvio' ),
				'type'        => 'multiselect',
				'description' => __( 'Shipping services available.', 'epmp-melhorenvio' ),
				'desc_tip'    => true,
				'class'       => 'wc-enhanced-select',
				'options'     => get_services_list(),
			],

			'receipt'        => [
				'title'       => __( 'Receipt', 'epmp-melhorenvio' ),
				'type'        => 'checkbox',
				'label' => __( 'Check if you want to be notified when the parcel is delivered.', 'epmp-melhorenvio' ),
			],

			'receiver_only'        => [
				'title'       => __( 'Receiver only', 'epmp-melhorenvio' ),
				'type'        => 'checkbox',
				'label' => __( 'Check if you want the parcel to be delivered to the receiver.', 'epmp-melhorenvio' ),
			],

			'show_delivery_time' => [
				'title'       => __( 'Show delivery time', 'epmp-melhorenvio' ),
				'type'        => 'checkbox',
				'label' => __( '', 'epmp-melhorenvio' ),
			],

			'additional_time' => [
				'title'       => __( 'Additional days', 'epmp-melhorenvio' ),
				'type'        => 'number',
				'description' => __( 'Number of days to add to the delivery time.', 'epmp-melhorenvio' ),
				// 'desc_tip'    => true,
			],

			'shipping_class_ids' => [
				'title'         => __( 'Shipping Class', 'epmp-melhorenvio' ),
				'type'          => 'multiselect',
				'description'   => __( 'If necessary, select a shipping class to apply this method.', 'epmp-melhorenvio' ),
				'desc_tip'      => true,
				'class'         => 'wc-enhanced-select',
				'options'       => $this->get_shipping_classes_options(),
			],
			'shop_name' => [
				'title'       => __( 'Name', 'epmp-melhorenvio' ),
				'type'        => 'text',
				'description' => __( 'Name of the sender', 'epmp-melhorenvio' ),
				'desc_tip'    => true,
			],
			'shop_phone' => [
				'title'       => __( 'Phone', 'epmp-melhorenvio' ),
				'type'        => 'text',
				'description' => __( 'Phone of the sender', 'epmp-melhorenvio' ),
				'desc_tip'    => true,
			],
			'shop_email' => [
				'title'             => __( 'Email', 'epmp-melhorenvio' ),
				'type'              => 'text',
				'description'       => __( 'Email of the sender', 'epmp-melhorenvio' ),
				'desc_tip'          => true,
				'sanitize_callback' => [ $this, 'sanitize_email' ],
			],
			'shop_document_type' => [
				'title'             => __( 'Document type', 'epmp-melhorenvio' ),
				'type'              => 'radio_button',
				'description'       => __( 'Type of document of the sender', 'epmp-melhorenvio' ),
				'options'           => [
					DOCUMENT_TYPE_CPF  => __( 'Natural person', 'epmp-melhorenvio' ),
					DOCUMENT_TYPE_CNPJ => __( 'Legal person', 'epmp-melhorenvio' ),
				]
			],
			'shop_document' => [
				'title'             => __( 'Document', 'epmp-melhorenvio' ),
				'type'              => 'text',
				'description'       => __( 'Document of the sender; CPF if natural, CNPJ if legal', 'epmp-melhorenvio' ),
				'sanitize_callback' => [ $this, 'sanitize_document' ],
			],
			'shop_cnae' => [
				'title'             => __( 'CNAE', 'epmp-melhorenvio' ),
				'type'              => 'text',
				'description'       => __( '', 'epmp-melhorenvio' ),
				'sanitize_callback' => [ $this, 'sanitize_cnae' ],
			],
			'shop_address' => [
				'title'       => __( 'Address', 'epmp-melhorenvio' ),
				'type'        => 'text',
				'description' => __( 'Address of the sender', 'epmp-melhorenvio' ),
				'desc_tip'    => true,
			],
			'shop_complement' => [
				'title'       => __( 'Complement', 'epmp-melhorenvio' ),
				'type'        => 'text',
				'description' => __( 'Complement of the sender', 'epmp-melhorenvio' ),
				'desc_tip'    => true,
			],
			'shop_number' => [
				'title'       => __( 'Number', 'epmp-melhorenvio' ),
				'type'        => 'text',
				'description' => __( 'Number of the sender', 'epmp-melhorenvio' ),
				'desc_tip'    => true,
			],
			'shop_district' => [
				'title'       => __( 'District', 'epmp-melhorenvio' ),
				'type'        => 'text',
				'description' => __( 'District of the sender', 'epmp-melhorenvio' ),
				'desc_tip'    => true,
			],
			'shop_city' => [
				'title'       => __( 'City', 'epmp-melhorenvio' ),
				'type'        => 'text',
				'desc_tip'    => true,
				'description' => __( 'City of the sender', 'epmp-melhorenvio' ),
			],
			'shop_postal_code' => [
				'title'             => __( 'Postcode', 'epmp-melhorenvio' ),
				'type'              => 'text',
				'description'       => __( 'Postcode of the sender', 'epmp-melhorenvio' ),
				'desc_tip'          => true,
				'sanitize_callback' => [ $this, 'sanitize_postcode' ],
			],
			'shop_state' => [
				'title'       => __( 'State', 'epmp-melhorenvio' ),
				'type'        => 'select',
				'description' => __( 'State of the sender', 'epmp-melhorenvio' ),
				'desc_tip'    => true,
				'options'     => [__( 'Select a state', 'epmp-melhorenvio' )] + WC()->countries->get_states( 'BR' ),
				'default'     => '',
				'class'       => 'wc-enhanced-select',

			],
			'shop_agency' => [
				'title'       => __( 'Agency', 'epmp-melhorenvio' ),
				'type'        => 'select',
				'description' => __( 'Choose the JadLog agency from which the contents will be sent. Leave it blank if are not going to use JadLog.', 'epmp-melhorenvio' ),
				'class'       => 'wc-enhanced-select',
			],
			'debug' => [
				'title'       => __( 'Debug Log', 'epmp-melhorenvio' ),
				'type'        => 'checkbox',
				'label'       => __( 'Enable logging', 'epmp-melhorenvio' ),
				'default'     => 'no',
				/* translators: %s: method title */
				'description' => sprintf( __( 'Log %s events, such as WebServices requests.', 'epmp-melhorenvio' ), $this->method_title ) . $this->get_log_link(),
			],
		];


		$this->instance_form_fields['shop_agency']['options'] = get_agencies_list_by_state( $this->get_instance_option( 'shop_state' ) );

	}

	public function process_admin_options(){
		/**
		 * Delete service list cache because the env. might have changed.
		 */
		delete_transient( 'epmp_me_service_list' );
		parent::process_admin_options();
	}

	protected function get_available_services( $package = [] ){

		// Allow third party plug-ins to hook it based on package and/or instance info.
		return apply_filters(
			'epmp_me_available_services',
			$this->services,
			$package,
			$this
		);

	}

	/**
	 * Check if package uses only the selected shipping class.
	 *
	 * @param  array $package Cart package.
	 * @return bool
	 */
	protected function has_selected_shipping_class( $package ) {
		$has_selected_class = true;

		$shipping_classe_ids = $this->get_shipping_class_ids_as_int();

		if( empty( $shipping_classe_ids ) || in_array( -1, $this->get_shipping_class_ids_as_int() ) ) {
			return $has_selected_class;
		}

		foreach( $package['contents'] as $item_id => $values ) {

			$product = $values['data'];
			$qty     = $values['quantity'];

			if( $qty > 0 && $product->needs_shipping() ) {

				if( in_array( (int) $product->get_shipping_class_id(), $this->get_shipping_class_ids_as_int() ) ) {

					$has_selected_class = true;
					break;

				}

				$has_selected_class = false;

			}
		}

		return $has_selected_class;
	}

	protected function get_from_postcode( $package = array() ) {
		return apply_filters( 'epmp_me_from_postcode', $this->shop_postal_code, $package, $this );
	}

	protected function get_additional_time( $package = array() ) {
		return apply_filters( 'epmp_me_shipping_additional_time', $this->additional_time, $package, $this );
	}

	protected function get_shipping_class_ids_as_int(){
		return array_map( 'intval', $this->shipping_class_ids );
	}

	/**
	 * Get shipping classes options.
	 *
	 * @return array
	 */
	protected function get_shipping_classes_options() {
		$shipping_classes = WC()->shipping->get_shipping_classes();
		$options          = [
			'-1' => __( 'Any Shipping Class', 'epmp-melhorenvio' ),
			'0'  => __( 'No Shipping Class', 'epmp-melhorenvio' ),
		];

		if( ! empty( $shipping_classes ) ) {
			$options += wp_list_pluck( $shipping_classes, 'name', 'term_id' );
		}

		return $options;
	}

	protected function request_shipping( $package = [] ){

		try {

			$payload = request_payload_factory( SHIPPING, $package );

		} catch( Payload_File_Not_Found_Exception $e ){
			$this->debug( $e->getMessage() );
		} catch( \Exception $e ){
			$this->debug( $e->getMessage() );
		}

		if( !isset( $payload ) ){
			return [];
		}

		$services = $this->get_available_services( $package );

		$payload->set_services( implode( ',', $services ) );

		$options = new Options;

		$receiver_only = wc_string_to_bool( $this->get_option( 'receiver_only', 'no' ) );
		$receipt = wc_string_to_bool( $this->get_option( 'receipt', 'no' ) );
		$collect = wc_string_to_bool( $this->get_option( 'collect', 'no' ) );
		$non_commercial = DOCUMENT_TYPE_CNPJ === $this->get_option( 'shop_document_type', DOCUMENT_TYPE_CPF );

		$options->set_own_hand( apply_filters( 'epmp_me_receiver_only', 		$receiver_only,  $package, $this ) );
		$options->set_receipt(  apply_filters( 'epmp_me_receipt', 				$receipt, 		 $package, $this ) );
		$options->set_collect(  apply_filters( 'epmp_me_collect', 				$collect, 		 $package, $this ) );
		$options->set_non_commercial(  apply_filters( 'epmp_me_non_commercial', $non_commercial, $package, $this ) );

		$payload->set_options( $options );

		$from_postcode = $this->get_from_postcode( $package );

		if( empty( $from_postcode ) ){
		 	$from_postcode = WC()->countries->get_base_postcode();
		}

		$payload->set_from_postcode( format_postcode( $from_postcode ) );

		$products = [];
		$package_items = $package['contents'];

		foreach( $package_items as $item ){

			$product_id = ($item['variation_id'] != 0) ? $item['variation_id'] : $item['product_id'];

            $product = payload_product_factory( $item['data'] );

            $products[] = [
            	'id'              => $product_id,
            	'width'           => $product->get_width(),
            	'height'          => $product->get_height(),
            	'length'          => $product->get_length(),
            	'weight'          => $product->get_weight(),
            	'insurance_value' => $product->get_price(),
            	'quantity'        => $item['quantity'],
            ];

		}

		$payload->set_products( $products );

		$request = new Request( new Endpoint, $payload );

		try {
			$shipping = $request->send( Request::POST );
		} catch( \Exception $e ){
			$shipping = [];
			$this->debug( $e->getMessage() );
		}

		if( !is_array( $shipping ) ){
			$shipping = [$shipping];
		}

		$this->debug( "Request: \n" . json_encode( $payload->to_array(), JSON_PRETTY_PRINT |  JSON_UNESCAPED_UNICODE ) );
		$response = json_encode( $shipping, JSON_PRETTY_PRINT |  JSON_UNESCAPED_UNICODE );
		$this->debug( "Response: \n" . $response, $shipping );

		return apply_filters( 'epmp_me_request_shipping', $shipping );

	}

	public function is_available( $package ) {
		$is_available = parent::is_available( $package )
						&& $this->has_selected_shipping_class( $package )
						&& !empty( $this->get_available_services( $package ) );
		return apply_filters( 'epmp_me_is_shipping_available', $is_available, $package, $this );
	}

	public function calculate_shipping( $package = [] ){

		$shipping_rates = $this->request_shipping( $package );

		foreach( $shipping_rates as $rate ){

			if( !isset( $rate->custom_price ) ){
				continue;
			}

			$label_format = sprintf( '%s %s', $rate->company->name, $rate->name );

			$label = apply_filters( 'epmp_me_rate_label', $label_format, $rate, $this->title, $package );

			$custom_delivery_time = '';
			$custom_delivery_range = '';

			if( wc_string_to_bool( $this->show_delivery_time ) ){
				$additional_time = $this->get_additional_time( $package );
				$custom_delivery_time = $rate->custom_delivery_time + $additional_time;
				$custom_delivery_range = $rate->custom_delivery_range;
				$custom_delivery_range->min += $additional_time;
				$custom_delivery_range->max += $additional_time;
			}

			$this->add_rate(
				apply_filters( 'epmp_me_shipping_rate',
					[
						'cost'    => $rate->custom_price,
						'id'      => $this->id . ':' . $rate->id,
						'package' => $package,
						'label'   => $label,
						'meta_data'  => [
							'_delivery_time'  => $custom_delivery_time,
							'_delivery_range' => $custom_delivery_range,
							'_service_id'     => $rate->id,
							'_company_id'     => $rate->company->id,
							'_packages'       => json_encode( $rate->packages ),

						]
					],
					$package,
					$this,
					$rate
				)
			);

		}
	}

	/**
	 * Generate Radio Button HTML.
	 *
	 * @param string $key Field key.
	 * @param array  $data Field data.
	 * @since  1.0.0
	 * @return string
	 */
	public function generate_radio_button_html( $key, $data ) {
		$field_key = $this->get_field_key( $key );
		$defaults  = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
			'options'           => array(),
		);

		$data = wp_parse_args( $data, $defaults );

		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<label for="<?php echo esc_attr( $field_key ); ?>"><?php echo wp_kses_post( $data['title'] ); ?> <?php echo $this->get_tooltip_html( $data ); // WPCS: XSS ok. ?></label>
			</th>
			<td class="forminp">
				<fieldset>
					<legend class="screen-reader-text"><span><?php echo wp_kses_post( $data['title'] ); ?></span></legend>

					<?php foreach ( (array) $data['options'] as $option_key => $option_value ) : ?>
						<?php $id = esc_attr( $field_key . '_' . $option_key ); ?>
						<input type="radio" name="<?php echo esc_attr( $field_key ); ?>" id="<?php echo $id; ?>" value="<?php echo esc_attr( $option_key ); ?>" <?php checked( (string) $option_key, esc_attr( $this->get_option( $key ) ) ); ?> <?php echo $this->get_custom_attribute_html( $data ); // WPCS: XSS ok. ?> <?php echo esc_attr( $data['class'] ); ?> <?php disabled( $data['disabled'], true ); ?>><label for="<?php echo $id?>"><?php echo esc_html( $option_value ); ?></label>
					<?php endforeach; ?>

					<?php echo $this->get_description_html( $data ); // WPCS: XSS ok. ?>
				</fieldset>
			</td>
		</tr>
		<?php

		return ob_get_clean();
	}

	/**
	 * Generate empty HTML.
	 *
	 * @param string $key Field key.
	 * @param array  $data Field data.
	 * @since  1.0.0
	 * @return string
	 */
	public function generate_remove_html( $key, $data ) {
		return '';
	}

	public function sanitize_email( $value ){

		if( !filter_var( $value, FILTER_VALIDATE_EMAIL ) ){
			throw new \Exception( __( 'Invalid value for e-mail field', 'epmp-melhorenvio' ) );
		}

		return $value;

	}

	public function sanitize_document( $value ){

		$validation = false;

		if( DOCUMENT_TYPE_CNPJ === (int) $this->get_option( 'shop_document_type' ) ){
			$validation = \Extra_Checkout_Fields_For_Brazil_Formatting::is_cnpj( $value );
		} else {
			$validation = \Extra_Checkout_Fields_For_Brazil_Formatting::is_cpf( $value );
		}

		if( !$validation ){
			throw new \Exception( __( 'Invalid value for document field', 'epmp-melhorenvio' ) );
		}

		return $value;

	}

	public function sanitize_postcode( $value ){

		if( !\WC_Validation::is_postcode( $value, 'BR' ) ){
			throw new \Exception( __( 'Invalid value for postcode field', 'epmp-melhorenvio' ) );
		}

		return $value;

	}

	public function sanitize_cnae( $value ){

		if( 7 !== strlen( $value ) ){
			throw new \Exception( __( 'Invalid value for CNAE field', 'epmp-melhorenvio' ) );
		}

		return $value;

	}

	/**
	 * Get log.
	 *
	 * @return string
	 */
	protected function get_log_link() {
		return ' <a href="' . esc_url( admin_url( 'admin.php?page=wc-status&tab=logs&log_file=' . esc_attr( $this->id ) . '-' . sanitize_file_name( wp_hash( $this->id ) ) . '.log' ) ) . '">' . __( 'View logs.', 'epmp-melhorenvio' ) . '</a>';
	}

	protected function debug( $message = '', $raw_error = '' ){
		if( wc_string_to_bool( $this->debug ) ){
			wc_get_logger()->add( EPMP_ME_SLUG . '-shipping', $message );
			do_action( 'epmp_me_shipping_debug', $message, $raw_error );
		}
	}

}
