<?php
namespace Epmp\ME\Admin;

use function Epmp\ME\functions\is_melhorenvio_method;
use function Epmp\ME\functions\is_invoice_required_for_item;

class Orders {

	public function __construct(){
		add_action( 'add_meta_boxes_shop_order', array( $this, 'register_metabox' ) );
		add_action( 'woocommerce_process_shop_order_meta', __CLASS__ . '::save', 30, 2 );
	}

	public function register_metabox( $post ) {

		if( !isset( $_GET['post'] ) ){
			return;
		}

		$order = wc_get_order( $_GET['post'] );

		$shipping_items = $order->get_shipping_methods();

		$this->shipping_items = array_filter( $shipping_items, function( $item ){
			return is_melhorenvio_method( $item->get_method_id() );
		});

		$this->shipping_items_with_invoice = array_filter( $this->shipping_items, function( $item ){
			return is_invoice_required_for_item( $item->get_id() );
		});

		if( count( $this->shipping_items_with_invoice ) ){
			add_meta_box(
				'epmp_me_invoice',
				__( 'Invoice', 'epmp-melhorenvio' ) . ' (Melhor Envio)',
				[ $this, 'invoice_metabox_content' ],
				'shop_order',
				'side',
				'default'
			);
		}

		add_meta_box(
			'epmp_me_tracking_code',
			__( 'Tracking code', 'epmp-melhorenvio' ) . ' (Melhor Envio)',
			[ $this, 'tracking_code_metabox_content' ],
			'shop_order',
			'side',
			'default'
		);

	}

	public function invoice_metabox_content( $post ){
		include_once EPMP_ME_PATH . '/includes/views/admin/html-me-order-invoice.php';
	}

	public function tracking_code_metabox_content( $post ){
		include_once EPMP_ME_PATH . '/includes/views/admin/html-me-order-tracking-code.php';
	}

	/**
	 * Save meta box data.
	 *
	 * @param WP_Post $post
	 */
	public static function save() {
		// This $_POST is already sanitised.

	    if ( isset( $_POST['_invoice_number'] ) ) {
	        foreach( $_POST['_invoice_number'] as $item_id => $invoice_number ){
	        	$invoice_number = sanitize_text_field( $invoice_number );
	            wc_update_order_item_meta( $item_id, '_invoice_number', $invoice_number );
	        }
	    }
	    if ( isset( $_POST['_tracking_code'] ) && $tracking_codes = array_filter( $_POST['_tracking_code'] ) ) {
	        foreach( $tracking_codes as $item_id => $tracking_code ){
	        	$tracking_code = sanitize_text_field( $tracking_code );

	        	$label_data = wc_get_order_item_meta( $item_id, '_epmp_me_label_data', true );

	        	if( empty( $label_data ) ){
	        		$label_data = [];
	        		$label_data['orders'] = [
	        			[
	        				'tracking_code' => (object) [ 'melhorenvio_tracking'  => '' ],
	        				'preview' => '',
	        			]
	        		];
	        	}

	        	foreach( $label_data['orders'] as &$me_order ){
	        		$me_order['tracking_code']->melhorenvio_tracking = $tracking_code;
	        	}

	        	$label_data['preview'] = '';
	        	$label_data['print_link'] = (object) [ 'url' => '#' ];

	            wc_update_order_item_meta( $item_id, '_epmp_me_label_data', $label_data );

	        }
	    }
	}

}

return new Orders;
