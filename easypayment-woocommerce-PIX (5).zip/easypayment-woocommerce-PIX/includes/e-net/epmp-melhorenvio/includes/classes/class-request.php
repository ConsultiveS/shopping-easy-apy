<?php

namespace Epmp\ME\Rest_API;

use \Epmp\ME\Abstracts\Request_Payload;

class Request {

	protected $rest_config;
	protected $body;
	protected $endpoint;
	protected $headers;

	const POST   = 'post';
	const GET    = 'get';
	const DELETE = 'delete';

    public function __construct( Endpoint $endpoint, Request_Payload $body = null ){

    	$this->rest_config = new Config;

    	$token = apply_filters( 'epmp_me_api_token', $this->rest_config->get_token(), $endpoint, $body );

    	$this->headers = [
    		'Content-Type'  => 'application/json',
    		'Accept'        => 'application/json',
    		'Authorization' => sprintf( 'Bearer %s', $token ),
    		'User-Agent'    => base64_decode( 'QXJ0LWkgTWFya2V0cGxhY2UgTWVsaG9yIEVudmlvIDxsdWlzLmJyYXNjaGlAYXJ0LWlkZXNlbnZvbHZpbWVudG8uY29tLmJyPg==' ),
    	];

    	$this->body = $body;
    	$this->endpoint = $endpoint;
    }

    private function get_full_url(){
    	return sprintf( '%s%s', $this->rest_config->get_request_uri(), $this->endpoint->get_formatted_endpoint() );
    }

    public function get( $url, $params = [] ){

    	$params = wp_parse_args(
    		$params,
    		[
    			'headers' => $this->headers,
    			'timeout' => 10,
    			'query_string' => []
    		]
    	);

    	$url = $url . '?' . http_build_query( $params['query_string'] );

    	return json_decode(
    	    wp_remote_retrieve_body(
    	        wp_remote_get( rtrim( $url, '?' ), array_filter( $params ) )
    	    )
    	);
    }

    public function post( $url, $params = [] ){

    	if( is_null( $this->body ) ){

    		$this->body = new class {
    			public function to_array(){
    				return [];
    			}
    		};

    		throw new \Exception( 'Post requests must have bodies' );
    	}

    	$params = wp_parse_args(
    		$params,
    		[
    			'headers' => $this->headers,
    			'timeout' => 10,
    			'body'    => json_encode( $this->body->to_array() )
    		]
    	);

    	return json_decode(
    	    wp_remote_retrieve_body(
    	        wp_remote_post( $url, array_filter( $params ) )
    	    )
    	);
    }


    public function delete( $url, $params = [] ){

    	$params = wp_parse_args(
    		$params,
    		[
    			'headers' => $this->headers,
    			'timeout' => 10,
    			'method'  => 'DELETE',
    			'value'   => '',
    		]
    	);

    	$url = stripslashes( $url ) . '/' . $params['value'];

    	return json_decode(
    	    wp_remote_retrieve_body(
    	        wp_remote_request( $url, array_filter( $params ) )
    	    )
    	);
    }

    public function send( $method = 'get', $params = [] ){
    	return $this->{$method}( $this->get_full_url(), $params );
    }

}
