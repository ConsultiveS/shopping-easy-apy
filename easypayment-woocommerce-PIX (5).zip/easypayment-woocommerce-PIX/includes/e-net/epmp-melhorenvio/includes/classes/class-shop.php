<?php
namespace Epmp\ME;

class Shop {

}
