<?php

namespace Epmp\ME\Payload;
use \Epmp\ME\Abstracts\Request_Payload;

class Shipping_Payload extends Request_Payload {

	protected $from_postcode = '';
	protected $to_postcode = '';
	protected $options = [];
	protected $services = '';

	protected $products = [];

	/**
	 * Get destination post code
	 *
	 * @return string
	 */
	public function get_products() {
		return $this->products;
	}

	/**
	 * Set destination postcode
	 *
	 * @param array $products
	 */
	public function set_products( $products ) {
		$this->products = $products;
	}

	/**
	 * Get origin post code
	 *
	 * @return string
	 */
	public function get_from_postcode() {
		return $this->from_postcode;
	}

	/**
	 * Set origin postcode
	 *
	 * @param string $from_postcode
	 */
	public function set_from_postcode( $from_postcode ) {
		$this->from_postcode = $from_postcode;
	}

	/**
	 * Get destination post code
	 *
	 * @return string
	 */
	public function get_to_postcode() {
		return $this->to_postcode;
	}

	/**
	 * Set destination postcode
	 *
	 * @param string $newfrom_postcode
	 */
	public function set_to_postcode( $to_postcode ) {
		$this->to_postcode = $to_postcode;
	}

	/**
	 * Get services as a string of ints separated by comma
	 *
	 * @return string
	 */
	public function get_services() {
		return $this->services;
	}

	/**
	 * Set destination postcode
	 *
	 * @param string $services
	 */
	public function set_services( $services ) {
		$this->services = $services;
	}

	/**
	 * Get options.
	 *
	 * @return string
	 */
	public function get_options() {
		return $this->options;
	}

	/**
	 * Set options.
	 *
	 * @param array $options
	 */
	public function set_options( Options $options ) {
		$this->options = $options;
	}


	public function to_array(){
		$array = [
			'from'     => [ 'postal_code' => $this->from_postcode ],
			'to'       => [ 'postal_code' => $this->to_postcode ],
			'options'  => $this->options->to_array(),
			'services' => $this->services,
			'products' => $this->products,
		];

		return $array;
	}

}
