<?php

namespace Epmp\ME\Payload\Constants;

const SHIPPING = 'shipping';
const SERVICES = 'services';
const LABELS   = 'labels';
const OPTIONS  = 'options';
const CHECKOUT = 'checkout';
const ADDRESS  = 'address';
