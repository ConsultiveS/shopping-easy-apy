<?php

namespace Epmp\ME\Payload;


class Payload_File_Not_Found_Exception extends \Exception {}
