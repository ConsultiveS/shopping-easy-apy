<?php
namespace Epmp\ME\Payload;


class FromInfo {

	private $name;
	private $phone;
	private $email;
	private $document;
	private $company_document;
	private $state_register;
	private $address;
	private $complement;
	private $number;
	private $district;
	private $city;
	private $country_id;
	private $postal_code;
	private $note = '';

	public function get_name(){
		return $this->name;
	}

	public function set_name($name){
		$this->name = $name;
	}

	public function get_phone(){
		return $this->phone;
	}

	public function set_phone($phone){
		$this->phone = $phone;
	}

	public function get_email(){
		return $this->email;
	}

	public function set_email($email){
		$this->email = $email;
	}

	public function get_document(){
		return $this->document;
	}

	public function set_document($document){
		$this->document = $document;
	}

	public function get_company_document(){
		return $this->company_document;
	}

	public function set_company_document($company_document){
		$this->company_document = $company_document;
	}

	public function get_state_register(){
		return $this->state_register;
	}

	public function set_state_register($state_register){
		$this->state_register = $state_register;
	}

	public function get_address(){
		return $this->address;
	}

	public function set_address($address){
		$this->address = $address;
	}

	public function get_complement(){
		return $this->complement;
	}

	public function set_complement($complement){
		$this->complement = $complement;
	}

	public function get_number(){
		return $this->number;
	}

	public function set_number($number){
		$this->number = $number;
	}

	public function get_district(){
		return $this->district;
	}

	public function set_district($district){
		$this->district = $district;
	}

	public function get_city(){
		return $this->city;
	}

	public function set_city($city){
		$this->city = $city;
	}

	public function get_country_id(){
		return $this->country_id;
	}

	public function set_country_id($country_id){
		$this->country_id = $country_id;
	}

	public function get_postal_code(){
		return $this->postal_code;
	}

	public function set_postal_code($postal_code){
		$this->postal_code = $postal_code;
	}

	public function get_note(){
		return $this->note;
	}

	public function set_note($note){
		$this->note = $note;
	}

	public function to_array(){
		return [
			'name' => $this->name,
			'phone' => $this->phone,
			'email' => $this->email,
			'document' => $this->document,
			'company_document' => $this->company_document,
			'state_register' => $this->state_register,
			'address' => $this->address,
			'complement' => $this->complement,
			'number' => $this->number,
			'district' => $this->district,
			'city' => $this->city,
			'country_id' => $this->country_id,
			'postal_code' => $this->postal_code,
			'note' => $this->note,
		];
	}
}
