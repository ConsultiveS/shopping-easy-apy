<?php

namespace Epmp\ME\Payload;
use \Epmp\ME\Abstracts\Request_Payload;

class Labels_Payload extends Request_Payload {

	protected $from_info = '';
	protected $to_info = '';
	protected $options;
	protected $agency_id = '';
	protected $service_ids  = '';

	protected $products = [];
	protected $volumes  = [];

	/**
	 * Get destination info
	 *
	 * @return string
	 */
	public function get_products() {
		return $this->products;
	}

	/**
	 * Set destination postcode
	 *
	 * @param array $products
	 */
	public function set_products( $products ) {
		$this->products = $products;
	}

	/**
	 * Get destination info
	 *
	 * @return string
	 */
	public function get_volumes() {
		return $this->volumes;
	}

	/**
	 * Set destination postcode
	 *
	 * @param array $volumes
	 */
	public function set_volumes( $volumes ) {
		$this->volumes = $volumes;
	}

	/**
	 * Get origin info
	 *
	 * @return User_Info
	 */
	public function get_from_info() {
		return $this->from_info;
	}

	/**
	 * Set origin postcode
	 *
	 * @param User_Info $from_info
	 */
	public function set_from_info( User_Info $from_info ) {
		$this->from_info = $from_info;
	}

	/**
	 * Get destination info
	 *
	 * @return ToInfo
	 */
	public function get_to_info() {
		return $this->to_info;
	}

	/**
	 * Set destination info
	 *
	 * @param User_Info $to_info
	 */
	public function set_to_info( User_Info $to_info ) {
		$this->to_info = $to_info;
	}

	/**
	 * The chosen service as a string|int
	 *
	 * @return string|int
	 */
	public function get_service_ids() {
		return $this->service_ids;
	}

	/**
	 * Set destination postcode
	 *
	 * @param string|int $service
	 */
	public function set_service_ids( $service_ids ) {
		$this->service_ids = $service_ids;
	}

	/**
	 * The chosen service as a string|int
	 *
	 * @return string|int
	 */
	public function get_agency_id() {
		return $this->agency_id;
	}

	/**
	 * Set destination postcode
	 *
	 * @param string|int $service
	 */
	public function set_agency_id( $agency_id ) {
		$this->agency_id = $agency_id;
	}

	/**
	 * Get options.
	 *
	 * @return Options
	 */
	public function get_options() {
		return $this->options;
	}

	/**
	 * Set options.
	 *
	 * @param Options $options
	 */
	public function set_options( Options $options ) {
		$this->options = $options;
	}

	public function to_array(){
		$array = [
			'agency'   => $this->agency_id,
			'service'  => $this->service_ids,
			'from'     => $this->from_info->to_array(),
			'to'       => $this->to_info->to_array(),
			'options'  => $this->options->to_array(),
			'products' => $this->products,
			'volumes'  => $this->volumes,
		];

		return $array;
	}

}
