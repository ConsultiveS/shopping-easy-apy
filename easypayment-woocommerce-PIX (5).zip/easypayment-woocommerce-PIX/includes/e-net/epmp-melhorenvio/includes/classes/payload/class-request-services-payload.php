<?php

namespace Epmp\ME\Payload;
use \Epmp\ME\Abstracts\Request_Payload;

class Services_Payload extends Request_Payload {
	public function to_array(){
		return [];
	}
}
