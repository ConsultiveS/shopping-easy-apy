<?php
namespace Epmp\ME\Payload;
use \Epmp\ME\Abstracts\Request_Payload;

class Options extends Request_Payload {

	private $insurance_value;

	/**
	 * Delivery to receiver only?
	 * @var bool
	 */
	private $own_hand = false;

	/**
	 * Send delivery receipt?
	 * @var bool
	 */
	private $receipt = false;
	private $collect;
	private $reverse;
	private $non_commercial = true;
	/**
	 * The name of the platform
	 * @var string
	 */
	private $platform;

	private $invoice_key;

	/**
	 * Array of Tag objects
	 * @var Tag[]
	 */
	private $tags;

	public function get_insurance_value(){
		return $this->insurance_value;
	}
	public function set_insurance_value( $insurance_value ){
		$this->insurance_value = $insurance_value ;
	}

	public function get_collect(){
		return $this->collect;
	}
	public function set_collect( $collect ){
		$this->collect = $collect ;
	}

	public function get_receipt(){
		return $this->receipt;
	}
	public function set_receipt( $receipt ){
		$this->receipt = $receipt ;
	}

	public function get_own_hand(){
		return $this->own_hand;
	}
	public function set_own_hand( $own_hand ){
		$this->own_hand = $own_hand ;
	}

	public function get_reverse(){
		return $this->reverse;
	}
	public function set_reverse( $reverse ){
		$this->reverse = $reverse ;
	}

	public function get_non_commercial(){
		return $this->non_commercial;
	}
	public function set_non_commercial( $non_commercial ){
		$this->non_commercial = $non_commercial ;
	}

	public function get_invoice_key(){
		return $this->invoice_key;
	}
	public function set_invoice_key( $invoice_key ){
		$this->invoice_key = $invoice_key ;
	}

	public function get_platform(){
		return $this->platform;
	}
	public function set_platform( $platform ){
		$this->platform = $platform ;
	}

	public function get_tags(){
		return $this->tags;
	}
	public function set_tags( $tags ){
		$this->tags = $tags ;
	}

	public function to_array(){

		$array = [
			'insurance_value' => $this->insurance_value,
			'receipt' 		  => $this->receipt,
			'collect' 		  => $this->collect,
			'own_hand' 		  => $this->own_hand,
			'reverse' 		  => $this->reverse,
			'non_commercial'  => $this->non_commercial,
			'platform'        => $this->platform,
			'invoice'         => [ 'key' => $this->invoice_key ],
			'tags'        	  => $this->tags,
		];

		return array_filter( $array, function( $el ){
			return !is_null( $el ) && '' !== $el ;
		} );

	}

}
