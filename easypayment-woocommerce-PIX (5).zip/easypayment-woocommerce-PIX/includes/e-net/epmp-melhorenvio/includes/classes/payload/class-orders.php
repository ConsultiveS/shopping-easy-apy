<?php

namespace Epmp\ME\Payload;
use \Epmp\ME\Abstracts\Request_Payload;

class Orders extends Request_Payload {

	protected $orders;

	public function set_orders( array $orders ){
		$this->orders = $orders;
	}

	public function to_array(){
		return [
			'orders' => $this->orders
		];
	}
}
