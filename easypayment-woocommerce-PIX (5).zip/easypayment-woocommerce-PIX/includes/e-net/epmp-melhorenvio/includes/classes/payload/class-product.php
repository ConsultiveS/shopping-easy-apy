<?php

namespace Epmp\ME\Payload;

class Product {

	protected $id;
	protected $insurance_value;
	protected $quantity;
	protected $width;
	protected $height;
	protected $length;
	protected $weight;
	protected $price;


	public function set_id( $id ){
		$this->id = $id;
	}
	public function get_id(){
		return $this->id;
	}

	public function set_insurance_value( $insurance_value ){
		$this->insurance_value = $insurance_value;
	}
	public function get_insurance_value(){
		return $this->insurance_value;
	}

	public function set_quantity( $quantity ){
		$this->quantity = $quantity;
	}
	public function get_quantity(){
		return $this->quantity;
	}

	public function set_width( $width ){
		$this->width = $width;
	}
	public function get_width(){
		return $this->width;
	}

	public function set_height( $height ){
		$this->height = $height;
	}
	public function get_height(){
		return $this->height;
	}

	public function set_length( $length ){
		$this->length = $length;
	}
	public function get_length(){
		return $this->length;
	}

	public function set_weight( $weight ){
		$this->weight = $weight;
	}
	public function get_weight(){
		return $this->weight;
	}

	public function set_price( $price ){
		$this->price = $price;
	}
	public function get_price(){
		return $this->price;
	}

}
