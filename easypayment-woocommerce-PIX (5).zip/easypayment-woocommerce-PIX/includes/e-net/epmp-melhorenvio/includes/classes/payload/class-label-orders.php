<?php

namespace Epmp\ME\Payload;
use \Epmp\ME\Abstracts\Request_Payload;

class Label_Orders extends Request_Payload {

	protected $orders;

	public function set_orders( array $orders ){
		$this->orders = $orders;
	}

	public function to_array(){
		return [
			'mode'   => 'public',
			'orders' => $this->orders
		];
	}
}
