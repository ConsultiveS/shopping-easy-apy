<?php

namespace Epmp\ME\Abstracts;

use Epmp\ME\Payload\Options;

abstract class Request_Payload {
	public function set_options( Options $options ){
		$this->options = $options;
	}
	abstract public function to_array();
}
