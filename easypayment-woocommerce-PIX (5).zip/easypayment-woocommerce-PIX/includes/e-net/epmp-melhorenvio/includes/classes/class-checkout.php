<?php
namespace Epmp\ME;

use Epmp\ME\Payload\Label_Orders;
use Epmp\ME\Payload\Orders;
use Epmp\ME\Rest_API\Config;
use Epmp\ME\Rest_API\Endpoint;
use Epmp\ME\Rest_API\Request;
use Exception;
use WC_Order_Item_Shipping;
use const Epmp\ME\Payload\Constants\{LABELS};
use const Epmp\ME\constants\CORREIOS_COMPANY_ID;
use function Epmp\ME\functions\request_payload_factory;

class Checkout {

	private $debug;

	public function __construct(){

		$this->debug = wc_string_to_bool( (new Config)->get_option( 'debug' ) );

		add_action( 'wp_ajax_buy-labels-for-order', [ $this, 'create_labels_for_order' ] ); // rename all "create"s
		add_action( 'wp_ajax_buy-labels-for-item', [ $this, 'create_labels_for_item' ] ); // rename all "create"s

		add_action( 'wp_ajax_generate-labels-for-item', [ $this, 'generate_labels_for_item' ] );

		add_action( 'wp_ajax_reset-labels-for-item', [ $this, 'reset_labels_for_item' ] );

		add_action( 'admin_notices', function(){
			if( isset( $_GET['item_reset'] ) ){
				delete_option( 'woocommerce_admin_notice_epmp_me_item_reset_' . intval( $_GET['item_reset'] ) );
			}
		}, 50 );

	}

	public function create_labels_for_order(){

		if(
			!(
				current_user_can( 'edit_others_shop_orders' ) &&
				check_admin_referer( 'epmp-me-buy-labels-for-order' )
			) &&
			!isset( $_GET['order_id'] )
		){
			wp_send_json_error( 'no_order_id' );
			wp_die();
		}

		$order_id = (int) $_GET['order_id'];
		$order = wc_get_order( $order_id );

		do_action( 'epmp_me_before_buy_labels_for_order', $order );

		$errors = [];

		foreach( $order->get_shipping_methods() as $shipping_item ){
			if( !$this->create_label_for_shipping_item( $shipping_item, $order ) ){
				$errors[] = $shipping_item->get_id();
			}
		}

		$items_with_error = [];

		if( !empty( $errors ) ){
			$items_with_error = [
				'items_with_error' => join( ',', $errors )
			];
		}

		do_action( 'epmp_me_after_buy_labels_for_order', $order );

		wp_safe_redirect( add_query_arg(
			$items_with_error,
			admin_url( 'edit.php?post_type=shop_order' )
		) );
		exit;

	}

	public function create_labels_for_item(){

		if(
			!(
				current_user_can( 'edit_shop_orders' ) && // make it a little more open so vendors can use it
				check_admin_referer( 'epmp-me-buy-labels-for-item' )
			) &&
			!isset( $_GET['item_id'] ) ||
			!wp_get_referer()
		){
			wp_send_json_error( 'not_authorized' );
			wp_die();
		}

		$item_id = (int) $_GET['item_id'];

		$shipping_item = new WC_Order_Item_Shipping( $item_id );

		$order = wc_get_order( $shipping_item->get_order_id() );

		$item_with_error = [];

		if( !$this->create_label_for_shipping_item( $shipping_item, $order ) ){
			$item_with_error = [
				'items_with_error' => $item_id
			];
		}

		wp_safe_redirect( add_query_arg(
			$item_with_error,
			wp_get_referer()
		) );
		die;

	}

	protected function create_label_for_shipping_item( $shipping_item, $order ){

		$me_packages = json_decode( $shipping_item->get_meta( '_packages' ) );

		/**
		 * @todo Make this a decent object
		 */
		$me_label_data = [
			'preview' => true,
			'orders'  => [],
		];

		if(  (int) CORREIOS_COMPANY_ID === (int) $shipping_item->get_meta( '_company_id' ) ){

			foreach( $me_packages as $me_package ){
				if( $new_order = $this->create_me_order( $shipping_item, $order, [$me_package]) ){
					// send one request per volume
					$me_label_data['orders'] += $new_order;
				}
			}

		} else {
			// send one requet with all volumes
			if( $new_order = $this->create_me_order( $shipping_item, $order, $me_packages) ){
				$me_label_data['orders'] += $new_order;
			}
		}

		if( array_filter( $me_label_data['orders'] ) ){

			$this->add_label_data_to_item(
				$shipping_item,
				$me_label_data
			);

			return true;

		}

		return false;

	}

	/**
	 * Buy shipping from ME
	 * @param  WC_Order_Item_Shipping $shipping_item
	 * @param  WC_Order $order
	 * @param  stdClass[] $me_volumes
	 * @return array                                    Label data from ME in case of sucess. [error=>bool] on error
	 */
	protected function create_me_order( $shipping_item, $order, $me_volumes ){

		$package = [
			'order' => $order,
			'shipping_item' => $shipping_item,
			'me_volume_products' => $this->get_volume_product_ids( $me_volumes ),
			'me_volumes' => $me_volumes,
		];

		do_action( 'epmp_me_before_buy_labels_for_item', $package );

		try {

			$labels_payload = request_payload_factory( LABELS, $package );

		} catch( Payload_File_Not_Found_Exception $e ){
			$this->debug( $e->getMessage(), EPMP_ME_SLUG . '-file-errors' );
		} catch( Exception $e ){
			$this->debug( $e->getMessage(), EPMP_ME_SLUG . '-general-exception' );
		}

		$response = (new Request( new Endpoint('/cart'), $labels_payload ))->send( Request::POST );

		$item_id = $shipping_item->get_id();

		$this->debug(
			sprintf(__( "Label request for item %s from order %s:\n%s", 'epmp-melhorenvio' ),
				$item_id,
				$order->get_id(),
				json_encode( $labels_payload->to_array(), JSON_PRETTY_PRINT |  JSON_UNESCAPED_UNICODE )
			),
			'labels-payload'
		);
		$this->debug(
			sprintf(__( "Cart response for item %s from order %s:\n%s", 'epmp-melhorenvio' ),
				$item_id,
				$order->get_id(),
				json_encode( $response, JSON_PRETTY_PRINT |  JSON_UNESCAPED_UNICODE )
			),
			'cart-response'
		);

		if( isset( $response->error ) || isset( $response->errors ) || isset( $response->agency ) ){
			$error = $response->error ?? $response->errors ?? $response->agency;

			if( is_array( $error ) || is_object( $error ) ){
				$error_arr = (array) $error;

				$error_str = [];

				foreach( $error_arr as $error_item ){

					$error_item = implode( ' ', $error_item );

					if( 'validation.nfe' === $error_item ){
						$error_item = __( 'Invalid invoice hey. Invoice keys must be 44 digits long.', 'epmp-melhorenvio' );
					}

					$error_str[] = $error_item;
				}

				$error = implode( ' ', $error_str );


			}

			$this->add_notice( $error, 'error', $item_id );

			return false;
		}

		$me_order_id = $response->id;

		$checkout_response = $this->checkout_label( $me_order_id );

		$this->debug( json_encode( $checkout_response, JSON_PRETTY_PRINT |  JSON_UNESCAPED_UNICODE ), 'checkout-response' );

		$this->debug(
			sprintf(__( "Checkout response for item %s from order %s:\n%s", 'epmp-melhorenvio' ),
				$item_id,
				$order->get_id(),
				json_encode( $response, JSON_PRETTY_PRINT |  JSON_UNESCAPED_UNICODE )
			),
			'checkout-response'
		);

		$me_label_data = [];

		$error_message = '';

		if( isset( $checkout_response->error ) ){

			$error_message = sprintf(
				__( '<b>Melhor Envio</b>: %s (order #%s)', 'epmp-melhorenvio' ),
				$checkout_response->error,
				wc_get_order_id_by_order_item_id( $item_id )
			);

			$this->add_notice( $error_message, 'error', $item_id );

		}

		$me_label_data[$me_order_id] = [
			'error'        => $error_message,
			'label_id'     => $me_order_id,
			'preview_link' => $this->get_label_preview_link( $me_order_id ),
		];

		do_action( 'epmp_me_after_buy_labels_for_item', $package );

		return $me_label_data;

	}

	protected function get_volume_product_ids( $me_volumes ){

		$ids = [];

		foreach( wp_list_pluck( $me_volumes, 'products' ) as $me_volume ){
			$ids = array_merge( $ids, wp_list_pluck( $me_volume, 'id' ) );
		}

		return $ids;
	}

	public function generate_labels_for_item(){
		if(
			!(
				current_user_can( 'edit_others_shop_orders' ) &&
				check_admin_referer( 'epmp-me-generate-labels-for-item' )
			) &&
			!isset( $_GET['item_id'] )
		){
			wp_send_json_error( 'no_order_id' );
			wp_die();
		}

		$shipping_item = new WC_Order_Item_Shipping( (int) $_GET['item_id'] );
		$item_id = $shipping_item->get_id();

		do_action( 'epmp_me_before_generate_labels_for_item', [ 'shipping_item' => $shipping_item ] );

		$me_label_data = wc_get_order_item_meta( $item_id, '_epmp_me_label_data', true );

		$me_label_data['preview'] = false;

		$me_order_ids = array_keys( $me_label_data['orders'] );

		$generate_label_response = (array) $this->generate_labels( $me_order_ids );

		if( empty( $generate_label_response ) || isset( $generate_label_response['message'] ) ){

			$error_message = $generate_label_response['message'] ?? __( 'There has been an error trying to generate your label. Try again in a few minutes.', 'epmp-melhorenvio' );

			$error = sprintf(
				__( '<b>Melhor Envio</b>: %s (order #%s)', 'epmp-melhorenvio' ),
				$error_message,
				wc_get_order_id_by_order_item_id( $item_id )
			);

			$this->add_notice( $error, 'error', $item_id );

			wp_safe_redirect( wp_get_referer() );
			die;
		}

		$tracking_codes = (array) $this->get_tracking_codes( $me_order_ids );
		$printable_labels =  $this->get_printable_labels( $me_order_ids );

		$me_label_data['print_link'] = $printable_labels;

		foreach( $me_label_data['orders'] as &$order ){

			$me_order_id = $order['label_id'];

			$order['tracking_code'] = $tracking_codes[$me_order_id];

			if(
				isset( $generate_label_response[$me_order_id]->status ) &&
				false === $generate_label_response[$me_order_id]->status
			){

				$me_label_data['preview'] = true;
				$order['error'] = sprintf(
									__( '<b>Melhor Envio</b>: %s (order #%s)', 'epmp-melhorenvio' ),
									esc_html( $generate_label_response[$me_order_id]->message ),
									wc_get_order_id_by_order_item_id( $item_id )
								);

				$this->add_notice( $order['error'], 'error', $item_id );

				do_action( 'epmp_me_generate_label_error', $order['error'] );

			} else  {
				unset( $order['preview_link'] );
			}

		}

		$this->add_label_data_to_item(
			$shipping_item,
			$me_label_data
		);

		$this->debug(
			sprintf("Generate label for item %s from order %s response:\n%s",
				$item_id,
				wc_get_order_id_by_order_item_id( $item_id ),
				json_encode( $generate_label_response, JSON_PRETTY_PRINT |  JSON_UNESCAPED_UNICODE )
			),
			'generate'
		);

		wp_safe_redirect( wp_get_referer() );
		die;

	}

	protected function get_label_preview_link( $me_order_id ){

		$preview = new Orders;

		$preview->set_orders( [ $me_order_id ] );

		return ( new Request( new Endpoint('/shipment/preview'), $preview ) )->send( Request::POST );
	}

	protected function checkout_label( $me_order_id ){

		$checkout = new Orders;

		$checkout->set_orders( [ $me_order_id ] );

		return ( new Request( new Endpoint('/shipment/checkout'), $checkout ) )->send( Request::POST );
	}

	/**
	 * Generate labels based on list of orders
	 * @param  array $orders
	 * @return object
	 */
	protected function generate_labels( $orders ){

		$generate = new Orders;

		$generate->set_orders( $orders );

		return ( new Request( new Endpoint('/shipment/generate'), $generate ) )->send( Request::POST );
	}

	protected function get_printable_label( $me_order_id ){

		$label = new class extends Orders {
			public function to_array(){
				return [
					'mode'   => 'public',
					'orders' => $this->orders
				];
			}
		};

		$label->set_orders( [ $me_order_id ] );

		return ( new Request( new Endpoint('/shipment/print'), $label ) )->send( Request::POST );
	}

	protected function get_printable_labels( $orders ){

		$label = new Label_Orders();

		$label->set_orders( $orders );

		return ( new Request( new Endpoint('/shipment/print'), $label ) )->send( Request::POST );
	}

	protected function get_tracking_codes( $orders ){

		$label = new Orders;

		$label->set_orders( $orders );

		return ( new Request( new Endpoint('/shipment/tracking'), $label ) )->send( Request::POST );
	}

	protected function add_label_data_to_item( $shipping_item, $me_label_data ){
		wc_update_order_item_meta( $shipping_item->get_id(), '_epmp_me_label_data', $me_label_data );
	}

	public function reset_labels_for_item(){
		if(
			!(
				current_user_can( 'edit_others_shop_orders' ) &&
				check_admin_referer( 'epmp-me-reset-labels-for-item' )
			) &&
			!isset( $_GET['item_id'] )
		){
			wp_send_json_error( 'no_item_id' );
			wp_die();
		}

		$item_id = intval( $_GET['item_id'] );
		$order_id = (new \WC_Order_Item_Shipping( $item_id ) )->get_order_id();
		$label_data = wc_get_order_item_meta( $item_id, '_epmp_me_label_data', true );

		$orders = $label_data['orders'] ?? [];

		foreach( $orders as $order_key => $order ){

			$payload = new class( $order_key ) extends \Epmp\ME\Abstracts\Request_Payload {

				protected $order_key;

				public function __construct( $order_key ){
					$this->order_key = $order_key;
				}

				public function to_array(){
					return  [
						'order' =>
						[
							'id' => $this->order_key,
							'reason_id' => 2,
							'description' => 'Inserção incorreta.',
						]
					];
				}
			};

			// Try to remove it from the cart first.
			( new Request( new Endpoint('/cart') ) )->send( Request::DELETE, [ 'value' => $order_key ] );
			$cancel_response = ( new Request( new Endpoint('/shipment/cancel'), $payload ) )->send( Request::POST );

			$cancel_response = json_encode( $cancel_response, JSON_PRETTY_PRINT |  JSON_UNESCAPED_UNICODE );

			$cancel_debug = sprintf(
				'Cancelling labels for item %s from order %s: %s',
				$item_id,
				$order_id,
				$cancel_response
			);

			$this->debug( $cancel_debug , 'cancel-response' );

		}

		wc_delete_order_item_meta( $item_id, '_epmp_me_label_data' );

		$message = sprintf( __( 'Item for order %d has been reset.', 'epmp-melhorenvio' ), $order_id );

		$this->add_notice( $message, null, $item_id );

		wp_safe_redirect(
			add_query_arg(
				[ 'item_reset' => $item_id ],
				wp_get_referer()
			)
		);
		die;

	}

	protected function debug( $message = '', $handle_sufix = '' ){
		if( $this->debug ){
			wc_get_logger()->add( EPMP_ME_SLUG . ( $handle_sufix ? "-$handle_sufix" : '' ), $message );
		}
	}

	protected function add_notice( $message, $type = 'error', $sufix = '' ){

		if( current_user_can( 'administrator' ) ){
			\WC_Admin_Notices::add_custom_notice( 'epmp_me_item_reset_' . $sufix, $message );
		} else {
			wc_add_notice( $message, $type );
		}

	}

}

return new Checkout;
