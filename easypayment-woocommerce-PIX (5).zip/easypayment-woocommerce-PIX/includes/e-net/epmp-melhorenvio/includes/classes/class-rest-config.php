<?php

namespace Epmp\ME\Rest_API;

class Config extends \WC_Integration {

    protected $request_uri;
    protected $token;
    protected $allowed_statuses;
    protected $debug;
    protected $sandbox;

    const MIN_WIDTH = 0;
    const MIN_HEIGHT = 0;
    const MIN_LENGTH = 0;
    const MIN_WEIGHT = 0;
    const DEFAULT_SHIPPED_STATUS = 'wc-shipped-out';

    public function __construct(){

    	$this->id                 = 'melhorenvio-integration';
    	$this->method_title       = __( 'Art-i Melhor Envio', 'epmp-melhorenvio' );
    	$this->method_description = __( 'Art-i WooCommerce integration with Melhor Envio.', 'epmp-melhorenvio' );

    	$this->init_form_fields();
    	$this->init_settings();

        $this->token   			  = $this->get_option( 'token' );
        $this->allowed_statuses   = $this->get_option( 'allowed_statuses', [] );
        $this->shipped_out_status = $this->get_option( 'shipped_out_status', Config::DEFAULT_SHIPPED_STATUS );
    	$this->debug   			  = $this->get_option( 'debug' );
    	$this->sandbox 			  = $this->get_option( 'sandbox' );

    	$this->min_width  = $this->get_option( 'min_width',  Config::MIN_WIDTH );
    	$this->min_height = $this->get_option( 'min_height', Config::MIN_HEIGHT );
    	$this->min_length = $this->get_option( 'min_length', Config::MIN_LENGTH );
    	$this->min_weight = $this->get_option( 'min_weight', Config::MIN_WEIGHT );

        if( $this->is_sandbox() ){
	        $this->request_uri = 'https://sandbox.melhorenvio.com.br';
        } else {
	        $this->request_uri = 'https://www.melhorenvio.com.br';
        }

		add_action( 'woocommerce_update_options_integration_' . $this->id, [ $this, 'process_admin_options' ] );

    }

    public function get_method_description(){
    	return parent::get_method_description() . $this->show_balance();
    }

    protected function show_balance(){

    	$balance = static::get_balance();

    	$formatted_balance = sprintf( __( 'Your balance is: %s', 'epmp-melhorenvio' ), wc_price( $balance->balance ?? '--' ) );

    	ob_start();
    	?>
    	<div><?php echo $formatted_balance; ?></div>
    	<?php

    	return ob_get_clean();

    }

    /**
     * Retrives the balance from the Melhor Envio account
     * @return StdClass { balance, reserved, debts }
     */
    public static function get_balance(){
    	return ( new Request( new Endpoint( '/balance' ) ) )->send( Request::GET );
    }

    public function set_request_uri( $request_uri ){
    	$this->request_uri = $request_uri;
    }

    public function get_request_uri(){
        return apply_filters( 'epmp_me_request_uri', $this->request_uri );
    }

    public function get_token(){
    	return $this->token;
    }

    public function is_sandbox(){
    	return wc_string_to_bool( $this->sandbox );
    }

    public function init_form_fields() {

    	$shipped_out_statuses = [
    		'wc-shipped-out' => __( 'Use plug-in\'s own status (shipped out)', 'epmp-melhorenvio' )
    	] + wc_get_order_statuses();

    	$this->form_fields = [
    		'token' => [
    			'title'       => __( 'Token', 'epmp-melhorenvio' ),
    			'type'        => 'textarea',
    			'description' => __( 'Enter your token.', 'epmp-melhorenvio' ),
    			'desc_tip'    => true,
    			'default'     => ''
    		],
    		'sandbox' => [
    			'title'       => __( 'Test environment', 'epmp-melhorenvio' ),
    			'type'        => 'checkbox',
    			'label'       => __( 'Enable testing', 'epmp-melhorenvio' ),
    			'default'     => 'no',
    			'description' => __( 'Enable this if you are in a testing environment.', 'epmp-melhorenvio' ),
    		],
    		'allowed_statuses' => [
    			'title'       => __( 'Allowed statuses', 'epmp-melhorenvio' ),
    			'type'        => 'multiselect',
    			'class'       => 'wc-enhanced-select',
    			'description' => __( 'These are the statuses that an order should be in order to allow label management.', 'epmp-melhorenvio' ),
    			'default'     => [ 'wc-completed', 'wc-processing' ],
    			'options'     => wc_get_order_statuses(),
    		],
    		'shipped_out_status' => [
    			'title'       => __( 'Shipped out status', 'epmp-melhorenvio' ),
    			'type'        => 'select',
    			'description' => __( 'Status used by the system as "shipped". When an order is marked with this status, WooCommerce will send an e-mail to notice the customer about it.', 'epmp-melhorenvio' ),
    			'default'     => 'wc-shipped-out',
    			'options'     => $shipped_out_statuses,
    		],
    		'debug' => [
    			'title'       => __( 'Debug Log', 'epmp-melhorenvio' ),
    			'type'        => 'checkbox',
    			'label'       => __( 'Enable logging', 'epmp-melhorenvio' ),
    			'default'     => 'no',
    			'description' => __( 'Log events such as API requests', 'epmp-melhorenvio' ),
    		],
    	];
    }

}
