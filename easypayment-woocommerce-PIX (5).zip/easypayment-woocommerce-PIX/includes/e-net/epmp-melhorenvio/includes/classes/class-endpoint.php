<?php

namespace Epmp\ME\Rest_API;


class Endpoint {

	protected $url_template = '/api/v2/me%s';
	protected $type;

	public function __construct( $type = '/shipment/calculate' ) {
		$this->type = $type;
	}

	public function get_formatted_endpoint(){
		$formatted_endpoint = apply_filters(
			'epmp_me_rest_api_formatted_endpoint',
			sprintf( $this->url_template, $this->type ),
			$this->url_template,
			$this->type
		);
		return $formatted_endpoint;
	}

	public function set_url_template( $url_template ){
		$this->url_template = $url_template;
	}

	public function get_url_template(){
		return $this->url_template;
	}

	public function set_type( $type ){
		$this->type = $type;
	}

	public function get_type(){
		return $this->type;
	}

}
