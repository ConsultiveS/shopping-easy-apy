<?php
namespace Epmp\ME\Emails\functions;

use function Epmp\ME\functions\get_company_name_by_id;
use function Epmp\ME\functions\get_integration;
use function Epmp\ME\functions\remove_order_status_prefix;

defined( 'ABSPATH' ) || exit;

function register_email_classes( $email_classes ){

	$email_classes['Epmp_ME_Emails_Shipped_Out'] = include_once EPMP_ME_PATH . '/includes/emails/class-order-shipped.php';

	return $email_classes;

}

add_filter( 'woocommerce_email_classes', __NAMESPACE__ . '\register_email_classes' );

function send_shipped_out_email( $order_id ){

	$order = wc_get_order( $order_id );

	$emails = WC()->mailer()->get_emails();
	$mailer = $emails['Epmp_ME_Emails_Shipped_Out'];

	foreach( $order->get_shipping_methods() as $shipping_item ){

		$label_data = $shipping_item->get_meta( '_epmp_me_label_data' );

		if( $label_data &&
			!$shipping_item->get_meta( '_epmp_me_shipping_mail_sent' )
		){
			$label_data['company'] = get_company_name_by_id( (int) $shipping_item->get_meta( '_company_id' ) );
			$mailer->trigger( $order_id, $order, $label_data, $shipping_item );
			wc_update_order_item_meta( $shipping_item->get_id(), '_epmp_me_shipping_mail_sent', true );
		}

	}

}

function config_shipped_out_status(){

	$shipped_status = remove_order_status_prefix( get_integration()->get_option( 'shipped_out_status', 'shipped-out' ) );
	add_action( 'woocommerce_order_status_' . $shipped_status , __NAMESPACE__ . '\send_shipped_out_email' );


}

add_action( 'woocommerce_init', __NAMESPACE__ . '\config_shipped_out_status' );
