<?php

class Epmp_ME_Emails_Shipped_Out extends \WC_Email {

	protected $shipping_item;

	/**
	 * Initialize tracking template.
	 */
	public function __construct() {
		$this->id               = 'epmp_melhorenvio_order_shipped';
		$this->title            = __( 'Order shipped out', 'epmp-melhorenvio' );
		$this->customer_email   = true;
		$this->description      = __( 'This email is sent when an order is marked as "shipped out".', 'epmp-melhorenvio' );
		$this->heading          = __( 'Your order has been sent', 'epmp-melhorenvio' );
		$this->subject          = __( '[{site_title}] Your order {order_number} has been shipped out', 'epmp-melhorenvio' );
		$this->message          = __( 'Hello, {customer}. Your recent order on {site_title} has been shipped out.', 'epmp-melhorenvio' )
									. PHP_EOL . ' ' . PHP_EOL
									. __( 'To track your delivery, use the following the tracking code(s): {tracking_code}', 'epmp-melhorenvio' )
									. PHP_EOL . ' ' . PHP_EOL
									. __( 'The delivery service is under the responsibility of {shipping_company}, but if you have any questions, please contact us.', 'epmp-melhorenvio' );
		$this->tracking_message = $this->get_option( 'tracking_message', $this->message );
		$this->template_html    = 'emails/epmp-melhorenvio-order-shipped.php';
		$this->template_plain   = 'emails/plain/epmp-melhorenvio-order-shipped.php';

		// Call parent constructor.
		parent::__construct();

		$this->template_base = EPMP_ME_TEMPLATES_PATH;
	}

	/**
	 * Initialise settings form fields.
	 */
	public function init_form_fields() {
		$this->form_fields = array(
			'enabled' => array(
				'title'   => __( 'Enable/Disable', 'epmp-melhorenvio' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable this email notification', 'epmp-melhorenvio' ),
				'default' => 'yes',
			),
			'subject' => array(
				'title'       => __( 'Subject', 'epmp-melhorenvio' ),
				'type'        => 'text',
				/* translators: %s: Email subject code */
				'description' => sprintf( __( 'This controls the email subject line. Leave blank to use the default subject: <code>%s</code>.', 'epmp-melhorenvio' ), $this->subject ),
				'placeholder' => $this->subject,
				'default'     => '',
				'desc_tip'    => true,
			),
			'heading' => array(
				'title'       => __( 'Email Heading', 'epmp-melhorenvio' ),
				'type'        => 'text',
				/* translators: %s: Email heading code */
				'description' => sprintf( __( 'This controls the main heading contained within the email. Leave blank to use the default heading: <code>%s</code>.', 'epmp-melhorenvio' ), $this->heading ),
				'placeholder' => $this->heading,
				'default'     => '',
				'desc_tip'    => true,
			),
			'tracking_message' => array(
				'title'       => __( 'Email Content', 'epmp-melhorenvio' ),
				'type'        => 'textarea',
				'description' => sprintf( __( 'This controls the initial content of the email. Leave blank to use the default content: <code>%s</code>.', 'epmp-melhorenvio' ), $this->message ),
				'placeholder' => $this->message,
				'default'     => '',
				'desc_tip'    => true,
			),
			'email_type' => array(
				'title'       => __( 'Email type', 'epmp-melhorenvio' ),
				'type'        => 'select',
				'description' => __( 'Choose which format of email to send.', 'epmp-melhorenvio' ),
				'default'     => 'html',
				'class'       => 'email_type wc-enhanced-select',
				'options'     => $this->get_custom_email_type_options(),
				'desc_tip'    => true,
			),
		);
	}

	/**
	 * Email type options.
	 *
	 * @return array
	 */
	protected function get_custom_email_type_options() {
		if ( method_exists( $this, 'get_email_type_options' ) ) {
			return $this->get_email_type_options();
		}

		$types = array( 'plain' => __( 'Plain text', 'epmp-melhorenvio' ) );

		if ( class_exists( 'DOMDocument' ) ) {
			$types['html']      = __( 'HTML', 'epmp-melhorenvio' );
			$types['multipart'] = __( 'Multipart', 'epmp-melhorenvio' );
		}

		return $types;
	}

	/**
	 * Get email tracking message.
	 *
	 * @return string
	 */
	public function get_tracking_message() {
		return apply_filters( 'epmp_me_email_tracking_message', $this->format_string( $this->tracking_message ), $this->object );
	}

	/**
	 * Get tracking code url.
	 *
	 * @param  string $tracking_code Tracking code.
	 *
	 * @return string
	 */
	public function get_tracking_code_url( $tracking_code ) {
		$url = sprintf(
			'<a href="https://www.melhorrastreio.com.br/rastreio/%1$s">%1$s</a>',
			$tracking_code
		);

		return apply_filters( 'epmp_me_email_tracking_core_url', $url, $tracking_code, $this->object );
	}


	/**
	 * Trigger email.
	 *
	 * @param  int      $order_id      Order ID.
	 * @param  WC_Order $order         Order data.
	 * @param  string   $tracking_code Tracking code.
	 */
	public function trigger( $order_id, $order = false, $label_data, $shipping_item ) {
		// Get the order object while resending emails.
		if ( $order_id && ! is_a( $order, 'WC_Order' ) ) {
			$order = wc_get_order( $order_id );
		}

		if ( is_object( $order ) ) {
			$this->object = $order;
			$this->shipping_item = $shipping_item;

			$this->recipient = $order->get_billing_email();

			$this->placeholders['{customer}']         = $order->get_shipping_first_name();
			$this->placeholders['{order_number}']     = $order->get_order_number();
			$this->placeholders['{date}']             = date_i18n( wc_date_format(), time() );
			$this->placeholders['{shipping_company}'] = $label_data['company'];

			$tracking_codes = [];

			foreach( $label_data['orders'] as $me_order ){

				$tracking_code = $me_order['tracking_code']->melhorenvio_tracking;
				$tracking_codes[] = $this->get_tracking_code_url( $tracking_code );

			}

			$this->placeholders['{tracking_code}'] = join( ', ', $tracking_codes );

		}

		if ( ! $this->get_recipient() ) {
			return;
		}

		$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
	}

	/**
	 * Get content HTML.
	 *
	 * @return string
	 */
	public function get_content_html() {
		ob_start();

		wc_get_template( $this->template_html, array(
			'shipping_item'    => $this->shipping_item,
			'order'            => $this->object,
			'email_heading'    => $this->get_heading(),
			'tracking_message' => $this->get_tracking_message(),
			'sent_to_admin'    => false,
			'plain_text'       => false,
			'email'            => $this,
		), '', $this->template_base );

		return ob_get_clean();
	}

	/**
	 * Get content plain text.
	 *
	 * @return string
	 */
	public function get_content_plain() {
		ob_start();

		// Format list.
		$message = $this->get_tracking_message();
		$message = str_replace( '<ul>', "\n", $message );
		$message = str_replace( '<li>', "\n - ", $message );
		$message = str_replace( array( '</ul>', '</li>' ), '', $message );

		wc_get_template( $this->template_plain, array(
			'shipping_item'    => $this->shipping_item,
			'order'            => $this->object,
			'email_heading'    => $this->get_heading(),
			'tracking_message' => $message,
			'sent_to_admin'    => false,
			'plain_text'       => true,
			'email'            => $this,
		), '', $this->template_base );

		return ob_get_clean();
	}
}

return new Epmp_ME_Emails_Shipped_Out();
