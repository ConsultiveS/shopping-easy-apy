<div class="order-invoice" >
	<?php foreach( $this->shipping_items as $item ):?>
		<?php
			$label_data = wc_get_order_item_meta( $item->get_id(), '_epmp_me_label_data', true );

			if( empty( $label_data ) ){
				$label_data = [];
				$label_data['orders'] = [
					[
						'tracking_code' => (object) [ 'melhorenvio_tracking'  => '' ],
					]
				];
			}

			foreach( $label_data['orders'] as $me_order ):
				if( !isset( $me_order['tracking_code'] ) ){
					continue;
				}
				$tracking_code = $me_order['tracking_code']->melhorenvio_tracking;

		?>
		<p>
			<label for="_tracking_code_<?php echo esc_attr( $item->get_id() );?>">
				<?php $label = apply_filters( 'epmp_me_tracking_code_field_label', $item->get_method_title(), $item ); ?>
				<?php echo esc_html( $label );?>
			</label><br>
			<input type="text" id="_tracking_code_<?php echo esc_attr( $item->get_id() );?>" name="_tracking_code[<?php echo esc_attr( $item->get_id() );?>]" value="<?php echo esc_attr( $tracking_code ); ?>" autocomplete="off">
		</p>
		<?php endforeach;?>
	<?php endforeach;?>
	<p>
		<i><?php esc_html_e( 'Add a tracking code regarding each shipping item.', 'epmp-melhorenvio' );?></i>
	</p>
	<p>
		<button type="submit" class="button"><?php esc_html_e( 'Save', 'epmp-melhorenvio' ); ?></button>
	</p>
</div>
