<p>
<?php
woocommerce_wp_text_input(
	[
	    'id'          => '_epmp_me_additional_time',
    	'label'       => __( 'Additional days', 'epmp-melhorenvio' ),
    	'desc_tip'    => true,
    	'description' => __( 'Number of days to add to the delivery time.', 'epmp-melhorenvio' ),
    	'type'        => 'number',
	]
);
?>
</p>
