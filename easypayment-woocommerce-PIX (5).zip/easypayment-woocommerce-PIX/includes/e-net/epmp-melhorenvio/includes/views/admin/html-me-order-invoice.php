<div class="order-invoice" >
	<?php foreach( $this->shipping_items_with_invoice as $item ):?>
		<p>
			<label for="_invoice_number_<?php echo esc_attr( $item->get_id() );?>">
				<?php $label = apply_filters( 'epmp_me_invoice_field_label', $item->get_method_title(), $item ); ?>
				<?php echo esc_html( $label );?>
			</label><br>
			<input type="text" id="_invoice_number_<?php echo esc_attr( $item->get_id() );?>" name="_invoice_number[<?php echo esc_attr( $item->get_id() );?>]" value="<?php echo esc_attr( $item->get_meta( '_invoice_number', true ) ); ?>" autocomplete="off">
		</p>
	<?php endforeach;?>
	<p>
		<i><?php esc_html_e( 'Insert the number of the invoice regarding each shipping item.', 'epmp-melhorenvio' );?></i>
	</p>
	<p>
		<button type="submit" class="button"><?php esc_html_e( 'Save', 'epmp-melhorenvio' ); ?></button>
	</p>
</div>
