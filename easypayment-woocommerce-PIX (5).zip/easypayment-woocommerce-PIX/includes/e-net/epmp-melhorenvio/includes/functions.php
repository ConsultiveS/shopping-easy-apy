<?php
namespace Epmp\ME\functions;

include_once EPMP_ME_PATH . '/includes/classes/class-rest-config.php';
include_once EPMP_ME_PATH . '/includes/classes/class-checkout.php';
include_once EPMP_ME_PATH . '/includes/classes/class-shop.php';
include_once EPMP_ME_PATH . '/includes/classes/class-request.php';
include_once EPMP_ME_PATH . '/includes/classes/class-endpoint.php';
include_once EPMP_ME_PATH . '/includes/classes/abstracts/abstract-request-payload.php';
include_once EPMP_ME_PATH . '/includes/classes/payload/class-orders.php';
include_once EPMP_ME_PATH . '/includes/classes/payload/class-label-orders.php';
include_once EPMP_ME_PATH . '/includes/classes/payload/class-options.php';
include_once EPMP_ME_PATH . '/includes/classes/payload/class-product.php';
include_once EPMP_ME_PATH . '/includes/classes/payload/class-user-info.php';
include_once EPMP_ME_PATH . '/includes/classes/payload/class-payload-file-not-found-exception.php';
include_once EPMP_ME_PATH . '/includes/classes/payload/constants.php';
include_once EPMP_ME_PATH . '/includes/classes/admin/class-orders.php';
include_once EPMP_ME_PATH . '/includes/emails/functions.php';
include_once EPMP_ME_PATH . '/includes/constants.php';

use Epmp\ME\Payload\Options;
use Epmp\ME\Payload\Payload_File_Not_Found_Exception;
use Epmp\ME\Payload\User_Info;
use Epmp\ME\Rest_API\Endpoint;
use Epmp\ME\Rest_API\Request;
use const Epmp\ME\Payload\Constants\{ SERVICES, SHIPPING, LABELS, OPTIONS, CHECKOUT };
use const Epmp\ME\constants\{
	CORREIOS_COMPANY_ID,
	JADLOG_COMPANY_ID,
	VIA_BRASIL_COMPANY_ID,
	LATAM_COMPANY_ID,
	AZUL_COMPANY_ID,
	BUSLOG_COMPANY_ID
};
use const Epmp\ME\constants\{ DOCUMENT_TYPE_CPF, DOCUMENT_TYPE_CNPJ };

/**
 * Add settings link on plugin page
*/
function settings_link( $links ) {
    $url = admin_url( 'admin.php?page=wc-settings&tab=integration&section=melhorenvio-integration' );
    $settings_link = "<a href='$url'>".__('Settings', 'epmp-melhorenvio')."</a>";
    array_unshift( $links, $settings_link );
    return $links;
}

add_filter('plugin_action_links_' . EPMP_ME_BASENAME, 'Epmp\ME\functions\settings_link' );

function add_integration( $integrations ){

	$integrations['epmp-me-rest-config'] = '\Epmp\ME\Rest_API\Config';

	return $integrations;

}

add_filter( 'woocommerce_integrations', 'Epmp\ME\functions\add_integration');

function get_integration(){
	return WC()->integrations->integrations['melhorenvio-integration'];
}

/**
 * Build a request payload that can be based on package info
 * @param  string $type    String id of the payload.
 * @param  array  $package WooCommerce/custom package
 * @return \Epmp\ME\Abstracts\Request_Payload
 */
function request_payload_factory( $type, $package = [] ){

	$type = sanitize_title( $type );

	$file_path = EPMP_ME_PATH . "/includes/classes/payload/class-request-{$type}-payload.php";

	if( file_exists( $file_path ) ){
		include_once $file_path;
	} else {
		throw new Payload_File_Not_Found_Exception( $file_path );
		return;
	}

	$type_to_class = ucfirst( $type );

	$payload_class = "\\Epmp\\ME\\Payload\\{$type_to_class}_Payload";

	$payload = new $payload_class;

	switch( $type ){

		case SHIPPING:

			$payload->set_to_postcode( format_postcode( $package['destination']['postcode'] ) );

			break;
		case CHECKOUT:

			break;
		case LABELS:

			$options = new Options;
			$from_info = new User_Info;
			$to_info = new User_Info;

			$order = $package['order'];
			$shipping_item = $package['shipping_item'];

			$shipping_method_id   = $shipping_item->get_method_id();
			$shipping_instance_id = $shipping_item->get_instance_id();

			$company_id = $shipping_item->get_meta( '_company_id', true );

			$settings_key = sprintf( 'woocommerce_%s_%d_settings', $shipping_method_id, $shipping_instance_id );

			$shop_settings = get_option( $settings_key );

			$document = $shop_settings['shop_document'] ?? '';

			$from_info->set_name( $shop_settings['shop_name'] ?? '' );
			$from_info->set_phone( $shop_settings['shop_phone'] ?? '' );
			$from_info->set_email( $shop_settings['shop_email'] ?? '' );

			if( isset( $shop_settings['shop_document_type'] ) && DOCUMENT_TYPE_CNPJ === (int) $shop_settings['shop_document_type'] ){
				$from_info->set_company_document( $document );
				$from_info->set_economic_activity_code( $shop_settings['shop_cnae'] ?? '' );

				$is_non_commercial = false;

				$item_invoice = $shipping_item->get_meta( '_invoice_number', true );
				$company_can_bypass_invoice = CORREIOS_COMPANY_ID === $company_id || AZUL_COMPANY_ID === $company_id;

				if( empty( $item_invoice ) && $company_can_bypass_invoice ){
					$is_non_commercial = true;
				}

				$options->set_non_commercial( $is_non_commercial );

				$options->set_invoice_key( $item_invoice );

			} else {
				$from_info->set_document( $document );
			}

			$from_info->set_address( $shop_settings['shop_address'] ?? '' );
			$from_info->set_complement( $shop_settings['shop_complement'] ?? '' );
			$from_info->set_number( $shop_settings['shop_number'] ?? '' );
			$from_info->set_district( $shop_settings['shop_district'] ?? '' );
			$from_info->set_city( $shop_settings['shop_city'] ?? '' );
			$from_info->set_state_abbr( $shop_settings['shop_state'] ?? '' );
			$from_info->set_country_id( 'BR' );
			$from_info->set_postal_code( format_postcode( $shop_settings['shop_postal_code'] ?? '' ) );

			$payload->set_from_info( apply_filters( 'epmp_me_set_from_info', $from_info, $package, $order ) );
			if( company_requires_agency( $company_id ) ){
				$payload->set_agency_id( apply_filters( 'epmp_me_set_agency_id', $shop_settings['shop_agency'] ?? '', $package, $order ) );
			}

			$to_info->set_name( $order->get_shipping_first_name() .' '. $order->get_shipping_last_name()  );

			$phone = $order->get_billing_phone();
        	$phone = $phone ? $phone : $order->get_meta( '_billing_cellphone' );

			$to_info->set_phone( $phone );
			$to_info->set_email( $order->get_billing_email() );
			$to_info->set_document( $order->get_meta( '_billing_cpf' ) );
			$to_info->set_company_document( $order->get_meta( '_billing_cnpj' ) );
			$to_info->set_state_register( $order->get_meta( '_billing_ie' ) );
			$to_info->set_address( $order->get_shipping_address_1() );
			$to_info->set_complement( $order->get_shipping_address_2() );
			$to_info->set_number( $order->get_meta( '_shipping_number' ) );
			$to_info->set_district( $order->get_meta( '_shipping_neighborhood' ) );
			$to_info->set_city( $order->get_shipping_city() );
			$to_info->set_state_abbr( $order->get_shipping_state() );
			$to_info->set_country_id( 'BR' );
			$to_info->set_postal_code( format_postcode( $order->get_shipping_postcode() ) );

			$payload->set_to_info( apply_filters( 'epmp_me_set_to_info', $to_info, $package, $order ) );

			$service_id = $shipping_item->get_meta( '_service_id', true );
			$service = apply_filters( 'epmp_me_shipping_service_id', $service_id, $package );

			$payload->set_service_ids( $service );

			$payload_products = [];

			$quantity_by_id = [];

			foreach( wp_list_pluck( $package['me_volumes'], 'products' ) as $me_volume ){
				$quantity_by_id = wp_list_pluck( $me_volume, 'quantity', 'id' );
			}

			foreach( $order->get_items() as $item ){

				$product_id = $item->get_variation_id() > 0 ?
					$item->get_variation_id() :
					$item->get_product_id();

				if(
					!in_array( $product_id, $package['me_volume_products'] )
				){
					continue;
				}

				$payload_products[] = [
					'name'          => $item->get_name(),
					'quantity'      => $quantity_by_id[$product_id],
					'unitary_value' => $order->get_item_subtotal( $item ),
				];

			}

			$payload_products = apply_filters( 'epmp_me_set_products', $payload_products, $package );
			$payload->set_products( $payload_products );

			$payload_volumes = [];

			$options = apply_filters( 'epmp_me_set_options', $options, $package, $order );

			$payload->set_options( $options );

			$volumes = $package['me_volumes'];

			$insurance_value = 0;

			foreach( $volumes as $volume ){
				$payload_volumes[] = [
					'height' => $volume->dimensions->height,
					'width'  => $volume->dimensions->width,
					'length' => $volume->dimensions->length,
					'weight' => $volume->weight,
				];

				$insurance_value += $volume->insurance_value;
			}

			$options->set_insurance_value( $insurance_value );

			$payload->set_volumes( $payload_volumes );

			break;
		case OPTIONS:

			break;
		default:
			throw new \Exception;
			break;
	}


	return $payload;
}

function payload_product_factory( $wc_product ){

	$product = new \Epmp\ME\Payload\Product;
	$config = WC()->integrations->integrations['melhorenvio-integration'];

	$width  = wc_get_dimension( (float) $wc_product->get_width(), 'cm' );
	$height = wc_get_dimension( (float) $wc_product->get_height(), 'cm' );
	$length = wc_get_dimension( (float) $wc_product->get_length(), 'cm' );
	$weight = wc_get_weight( (float) $wc_product->get_weight(), 'kg' );
	$price  = $wc_product->get_price() ? $wc_product->get_price()  : '';

	$product->set_width( $width );
	$product->set_height( $height );
	$product->set_length( $length );
	$product->set_weight( $weight );
	$product->set_price( $price );

	return $product;
}

function format_postcode( $postcode ){
	return preg_replace( '/\D/', '', $postcode );
}

function is_melhorenvio_method( $method_name ){
	return apply_filters(
		'epmp_me_is_melhorenvio_method',
		in_array( $method_name, [ 'epmp-melhorenvio', 'test-melhor-envio' ] ),
		$method_name
	);
}

function shipping_delivery_time( $shipping_method ) {

	$meta_data = $shipping_method->get_meta_data();
	$range     = isset( $meta_data['_delivery_range'] ) ? $meta_data['_delivery_range'] : null;

	if ( $range ) {
		echo '<p><small>' .
			esc_html(
			/* translators: 1: first day in range; 2: last day in range;  */
				sprintf( __( 'Delivery in %1$d to %2$d working days', 'epmp-melhorenvio' ), $range->min, $range->max )
			)
		. '</small></p>';
	}
}

add_action( 'woocommerce_after_shipping_rate', 'Epmp\ME\functions\shipping_delivery_time' );

function add_shipping_method( $methods ){

	include_once EPMP_ME_PATH . '/includes/class-melhorenvio-shipping-method.php';

	$methods['epmp-melhorenvio'] = '\Epmp\ME\Shipping_Method';

	return $methods;
}

add_filter( 'woocommerce_shipping_methods', 'Epmp\ME\functions\add_shipping_method' );

function hide_meta_shipping( $meta ){

	if( !(defined( 'EPMP_ME_TESTING' ) && EPMP_ME_TESTING) ){
		$meta[] = '_delivery_time';
		$meta[] = '_service_id';
		$meta[] = '_company_id';
		$meta[] = '_packages';
	}

	return $meta;
}

add_filter( 'woocommerce_hidden_order_itemmeta', 'Epmp\ME\functions\hide_meta_shipping' );

function get_labels_generation_allowed_statuses(){

	$allowed_statuses = get_integration()->get_option( 'allowed_statuses', [] );
	$allowed_statuses = array_map( __NAMESPACE__ . '\remove_order_status_prefix', $allowed_statuses );
	$allowed_statuses = apply_filters( 'epmp_me_labels_generation_allowed_statuses', $allowed_statuses );

	return $allowed_statuses;

}

function remove_order_status_prefix( $status ){
	return 'wc-' === substr( $status, 0, 3 ) ? substr( $status, 3 ) : $status;
}

function render_label_buttons( $actions, $order ){

	$labels_generation_allowed_statuses = get_labels_generation_allowed_statuses();

	if( !$order->has_status( $labels_generation_allowed_statuses ) || !is_admin() ){
		return $actions;
	}

	$me_actions = [];

    foreach( $order->get_shipping_methods() as $shipping_item ){

    	$item_id = $shipping_item->get_id();

    	if(
    		!is_melhorenvio_method( $shipping_item->get_method_id() ) ||
    		!is_labelling_available_for_item( $item_id )
    	){
    		continue;
    	}

        $label_data = wc_get_order_item_meta( $item_id, '_epmp_me_label_data' );

    	if( empty( $label_data ) && is_invoice_required_for_item( $item_id ) ){

    		$me_actions['add_invoice_' . $item_id] = [
        		'url' => wp_nonce_url(
        			admin_url(
        				'post.php?action=edit&post=' . $order->get_id()
        			),
        			'epmp-me-add-invoice-number'
        		),
        		'name' => __( 'Add invoice number', 'epmp-melhorenvio' ),
        		'action' => 'add-invoice-number'
        	];

        	if( item_can_bypass_invoice( $item_id ) ){
        		$me_actions['buy_labels_' . $item_id] = [
        			'url' => wp_nonce_url(
        				admin_url(
        					'admin-ajax.php?action=buy-labels-for-item&item_id=' . $item_id
        				),
        				'epmp-me-buy-labels-for-item'
        			),
        			'name' => __( 'Buy labels non-commercially', 'epmp-melhorenvio' ),
        			'action' => 'buy-labels'
        		];
        	}

    		continue;
    	}

        if( empty( $label_data ) ){
        	$me_actions['buy_labels_' . $item_id] = [
        		'url' => wp_nonce_url(
        			admin_url(
        				'admin-ajax.php?action=buy-labels-for-item&item_id=' . $item_id
        			),
        			'epmp-me-buy-labels-for-item'
        		),
        		'name' => __( 'Buy labels', 'epmp-melhorenvio' ),
        		'action' => 'buy-labels'
        	];
        } elseif(
        	( isset( $label_data['preview'] ) && $label_data['preview'] )
        	|| isset( $label_data['print_link'], $label_data['print_link']->message)
    		) {

        	$me_actions['generate_labels_' . $item_id] = [
        		'url' => wp_nonce_url(
        			admin_url(
        				'admin-ajax.php?action=generate-labels-for-item&item_id=' . $item_id
        			),
        			'epmp-me-generate-labels-for-item'
        		),
        		'name' => __( 'Generate labels', 'epmp-melhorenvio' ),
        		'action' => 'generate-labels'
        	];

        	foreach( $label_data['orders'] as $key => $me_order ){
        		if( isset( $me_order['preview_link']->url ) ){
        			$me_actions['preview_labels_' . $key] = [
        				'url' => $me_order['preview_link']->url,
        				'name' => __( 'Preview labels', 'epmp-melhorenvio' ),
        				'action' => 'preview-labels',
        			];
        		} elseif( isset( $me_order['preview_link']->error ) ){
        			$me_actions['preview_labels_' . $key] = [
        				'url' => '#',
        				'name' => esc_attr( $me_order['preview_link']->error ),
        				'action' => 'label-error',
        			];
        		}
        	}

        } elseif( isset( $label_data['preview'], $label_data['print_link'], $label_data['print_link']->url ) ) {
        	$me_actions['print_labels_' . $shipping_item->get_id()] = [
        		'url' => $label_data['print_link']->url,
        		'name' => __( 'Print labels', 'epmp-melhorenvio' ),
        		'action' => 'print-labels',
        	];
        }

        if( isset( $label_data['orders'] ) ){
        	$me_actions['reset_labels_' . $item_id] = [
        		'url' => wp_nonce_url(
        			admin_url(
        				'admin-ajax.php?action=reset-labels-for-item&item_id=' . $item_id
        			),
        			'epmp-me-reset-labels-for-item'
        		),
        		'name' => __( 'Reset labels', 'epmp-melhorenvio' ),
        		'action' => 'reset-labels'
        	];
        }

    }

    if( $me_actions ){

    	$group_name = apply_filters(
    		'epmp_me_label_actions_group_name',
    		__( 'Melhor Envio labels', 'epmp-melhorenvio' ),
    		$order->get_id()
    	);

    	$actions[] = [
	    	'group' => '<small>' . $group_name . '</small>',
	    	'actions' => $me_actions,
	    ];
	}
    return $actions;

}

add_filter( 'woocommerce_admin_order_actions', 'Epmp\ME\functions\render_label_buttons', 10, 2 );

function is_invoice_required_for_item( $item_id ){

	if( AZUL_COMPANY_ID === (int) wc_get_order_item_meta( $item_id, '_company_id' ) ){
		return false;
	}

	return ( !wc_get_order_item_meta( $item_id, '_invoice_number' ) &&
		apply_filters( 'epmp_me_use_invoice', true, $item_id ) );

}

function is_labelling_available_for_item( $item_id ){
	return apply_filters( 'epmp_me_is_labelling_available_for_item', true, $item_id );;
}

function item_can_bypass_invoice( $item_id ){
	return apply_filters( 'epmp_me_item_can_bypass_invoice', $item_id );
}

/**
 * Any company other than Correios requires invoice key.
 * @param  int $company_id
 * @return bool
 */
function company_requires_invoice( $company_id ){
	return CORREIOS_COMPANY_ID !== $company_id;
}

function labels_action_buttons_css() {
    ?>
    <style>
    	.column-wc_actions .wc-action-button-label-error,
    	.column-wc_actions .wc-action-button-reset-labels,
    	.column-wc_actions .wc-action-button-generate-labels,
    	.column-wc_actions .wc-action-button-preview-labels,
    	.column-wc_actions .wc-action-button-buy-labels,
    	.column-wc_actions .wc-action-button-add-invoice-number,
    	.column-wc_actions .wc-action-button-print-labels {
    		background-color: #0550a0;
    		color:#f3b331;
    	}
    	.wc-action-button-label-error::after {
    		content: "\f14c" !important;
    	}
    	.wc-action-button-preview-labels::after {
    		content: "\f119" !important;
    	}
    	.wc-action-button-generate-labels::after {
    		content: "\f538" !important;
    	}
    	.wc-action-button-reset-labels::after {
    		content: "\f463" !important;
    	}
    	.wc-action-button-add-invoice-number::after{
    		content: "\f491" !important;
    	}
    	.wc-action-button-buy-labels::after {
    		content: "\f133" !important;
    	}
    	.wc-action-button-print-labels::after {
    		content: "\f509" !important;
    	}
    </style>
    <script>
    	jQuery(function($){
    		$('.wc-action-button-preview-labels,.wc-action-button-print-labels').prop({'target':'_blank','rel':'noopener noreferrer'});
    	});
    </script>
    <?php
}
add_action( 'admin_head', 'Epmp\ME\functions\labels_action_buttons_css' );

function get_agencies_list_by_state( $state ){

	if( empty( $state ) ){
		return [];
	}

	$agency_list = [];

	$force_agency_list_update = apply_filters( 'epmp_me_force_agency_list_update', false );

	if( is_array( get_transient( 'epmp_me_agency_list_' . strtolower( $state ) ) ) && !$force_agency_list_update ){

		$agency_list = get_transient( 'epmp_me_agency_list_' . strtolower( $state ) );

	} else {

		$request = new Request( new Endpoint( '/shipment/agencies' ) );

		$agencies = $request->send( 'get', ['query_string' => [ 'company' => 2, 'state' => strtoupper( $state ) ] ] );
		$agencies = is_null( $agencies ) ? [] : $agencies;

		/**
		 * @todo Move/abstract this.
		 */
		foreach( $agencies as $agency ){
			$agency_list[(int) $agency->id] = sprintf( '%s (%s)', $agency->name, $agency->company_name );
		}

		set_transient( 'epmp_me_agency_list_' . strtolower( $state ), $agency_list, DAY_IN_SECONDS );

	}

	if( empty( $agency_list ) ){
		$agency_list[0] = __( 'There are no agencies for this state', 'epmp-melhorenvio' );
	} else {
		$agency_list[0] = __( 'Select the agency', 'epmp-melhorenvio' );
	}

	ksort( $agency_list );

	return $agency_list;

}


function get_agencies_list( $state, $company_id ){

	if( empty( $state ) || empty( $company_id ) || !company_requires_agency( $company_id )  ){
		return [];
	}

	$agency_list = [];

	$transient_key = 'epmp_me_agency_list_' . strtolower( $state ) . '_' . $company_id;

	$force_agency_list_update = apply_filters( 'epmp_me_force_agency_list_update', false );

	if( is_array( get_transient( $transient_key ) ) && !$force_agency_list_update ){

		$agency_list = get_transient( $transient_key );

	} else {

		$request = new Request( new Endpoint( '/shipment/agencies' ) );

		$agencies = $request->send( 'get', [
				'query_string' => [
					'company' => (int) $company_id,
					'state' => strtoupper( $state )
				]
			]
		);

		$agencies = is_null( $agencies ) ? [] : $agencies;

		/**
		 * @todo Move/abstract this.
		 */
		foreach( $agencies as $agency ){
			$agency_list[(int) $agency->id] = sprintf( '%s (%s)', $agency->name, $agency->company_name );
		}

		set_transient( $transient_key, $agency_list, DAY_IN_SECONDS );

	}

	if( empty( $agency_list ) ){
		$agency_list[0] = __( 'There are no agencies for this state', 'epmp-melhorenvio' );
	} else {
		$agency_list[0] = __( 'Select the agency', 'epmp-melhorenvio' );
	}

	ksort( $agency_list );

	return $agency_list;

}

function get_companies_list(){ // Obsolete.
	 return get_services_list();
}

function get_services_list(){

	$service_list = [];

	$force_service_list_update = apply_filters( 'epmp_me_force_service_list_update', false );

	if( get_transient( 'epmp_me_service_list' ) && !$force_service_list_update ){

		$service_list = get_transient( 'epmp_me_service_list' );

	} else {

		$request = new Request( new Endpoint( '/shipment/companies' ) );

		$company_list = $request->send();

		if( !$company_list ){
			return [];
		}

		/**
		 * @todo Move/abstract this.
		 */
		foreach( $company_list as $company ){
			foreach( $company->services as $service ){
				$service_list[$service->id] = sprintf( '%s %s', $company->name, $service->name );
			}
		}


		set_transient( 'epmp_me_company_list', $company_list, DAY_IN_SECONDS );

		set_transient( 'epmp_me_service_list', $service_list, DAY_IN_SECONDS );

	}

	return apply_filters( 'epmp_me_get_services_list', $service_list );

}

/**
 * @deprecated
 */
add_action( 'wp_ajax_epmp_me_get_agencies_by_state', function(){

	validate_state_abbr( $_GET['state'] ) ;

	if( !isset( $_GET['state'] ) || !validate_state_abbr( $_GET['state'] ) ){
		return wp_send_json_error( 'Invalid state data.' );
	}

	$formatted_list = [];

	foreach( get_agencies_list_by_state( $_GET['state'] ) as $id => $text ){

		$formatted_list[] = [
			'id' => $id,
			'text' => $text
		];
	}

	return wp_send_json_success( $formatted_list );

} );

add_action( 'wp_ajax_epmp_me_get_agencies', function(){


	if( !isset( $_GET['state'] ) || !validate_state_abbr( $_GET['state'] ) ){
		return wp_send_json_error( 'Invalid state data.' );
	}

	$companies = array_unique( $_GET['companies'] ) ?? [];
	$companies = array_intersect( get_companies_with_agencies(), $companies );
	$state = $_GET['state'];

	$formatted_list = [];

	foreach( $companies as $company_id ){
		foreach( get_agencies_list( $state, $company_id ) as $id => $text ){

			$formatted_list[$state][$company_id][] = [
				'id' => $id,
				'text' => $text
			];

		}
	}

	return wp_send_json_success( $formatted_list );

} );

function validate_state_abbr( $state_abbr ){

	$valid_states = array_keys( WC()->countries->get_states( 'BR' ) );

	return ( 2 === strlen( $state_abbr ) && in_array( $state_abbr, $valid_states ) );

}

function format_agency_list( $agencies, $selected_agency_for_company ){

	$agency_list = [];

	foreach( $agencies as $agency_id => $agency_name ){
		$agency_list[] = [
			'id' => $agency_id,
			'description' => $agency_name,
			'selected' => (int) $selected_agency_for_company === (int) $agency_id,
		];
	}

	return apply_filters( 'epmp_me_format_agency_list', $agency_list, $agencies );

}

function add_order_statuses( $order_statuses ) {

	$order_statuses['wc-shipped-out'] = _x( 'Order shipped out', 'WooCommerce Order status', 'epmp-melhorenvio' );
	return $order_statuses;

}
add_filter( 'wc_order_statuses', __NAMESPACE__ . '\add_order_statuses' );

function add_order_is_paid_statuses( $order_statuses ) {

	$order_statuses[] = 'wc-shipped-out';
	return $order_statuses;

}
add_filter( 'woocommerce_order_is_paid_statuses', __NAMESPACE__ . '\add_order_is_paid_statuses' );

function register_post_statuses() {

	register_post_status( 'wc-shipped-out', [
		'label' => _x( 'Order shipped out', 'WooCommerce Order status', 'epmp-melhorenvio' ),
		'public' => true,
		'exclude_from_search' => false,
		'show_in_admin_all_list' => true,
		'show_in_admin_status_list' => true,
		'label_count' => _n_noop(
			/* translators: %s: Number of shipped orders */
			'Shipped <span class="count">(%s)</span>',
			'Shipped <span class="count">(%s)</span>',
			'epmp-melhorenvio'
		)
	] );

}

add_filter( 'init', __NAMESPACE__ . '\register_post_statuses' );

add_filter( 'wcbcf_billing_fields', function( $fields ){

	$fields['billing_cellphone']['required'] = true;

	return $fields;

} );

function add_product_fields(){
	include_once 'views/admin/html-product-shipping-option-fields.php';
}

add_action( 'woocommerce_product_options_shipping', __NAMESPACE__ . '\add_product_fields' );

function save_product_fields( $product_id, $post_data ){

    $addition_time = $post_data['_epmp_me_additional_time'] ?? 0;
    update_post_meta( $product_id, '_epmp_me_additional_time', sanitize_text_field( $addition_time ) );

    $product = wc_get_product( $product_id );

    if( $product->has_child() ) {

        $children = $product->get_children();

        foreach( $children as $child_id ) {
            update_post_meta( $child_id, '_epmp_me_additional_time', sanitize_text_field( $addition_time ) );
        }

    }

}

add_action( 'woocommerce_process_product_meta', function( $product_id ){
	save_product_fields( $product_id, $_POST );
} );


add_filter( 'epmp_me_shipping_additional_time', function( $additional_time, $package ){

	$product_ids = wp_list_pluck( $package['contents'], 'product_id' );

	foreach( $product_ids as $product_id ){
		if( (int) $additional_time < (int) get_post_meta( $product_id, '_epmp_me_additional_time', true ) ){
			$additional_time = get_post_meta( $product_id, '_epmp_me_additional_time', true );
		}
	}

	return $additional_time;

}, 100, 2 );

function get_user_address_list(){
	return ( new Request( new Endpoint('/addresses') ) )->send( Request::GET );
}

function get_companies_with_agencies(){
	return apply_filters( 'epmp_me_get_companies_with_agencies', [ JADLOG_COMPANY_ID, LATAM_COMPANY_ID, BUSLOG_COMPANY_ID ] );
}

function company_requires_agency( $company_id ){
	return apply_filters(
			'epmp_me_company_requires_agency',
			in_array( $company_id, get_companies_with_agencies() ),
			$company_id,
			get_companies_with_agencies()
	);
}

function get_company_list(){
	/**
	 * @todo DRY this
	 */
	$company_list = get_transient( 'epmp_me_company_list' );

	if( !$company_list || apply_filters( 'epmp_me_force_company_list_update', false ) ){
		$request = new Request( new Endpoint( '/shipment/companies' ) );

		$company_list = $request->send();
		set_transient( 'epmp_me_company_list', $company_list, DAY_IN_SECONDS );
	}

	return $company_list;

}

function get_company_to_service_ids_map(){

	$company_to_service = [];
	$company_list = get_company_list();

	foreach( $company_list as $company ){
		$company_to_service[$company->id] = array_column( $company->services, 'id' );
	}

	return $company_to_service;

}

function get_service_to_company_map(){

	$service_to_company = [];
	$company_list = get_company_list();

	foreach( $company_list as $company ){
		foreach( $company->services as $service ){
			$service_to_company[$service->id] = $company->id;
		}
	}

	return $service_to_company;

}

function get_company_by_service_id( $service_id ){

	$service_list = get_service_to_company_map();

    return apply_filters( 'epmp_me_get_company_by_service_id', $service_list[$service_id] ?? false, $service_list );

}

function get_company_name_by_id( $company_id ){

	$companies = [
		CORREIOS_COMPANY_ID => 'Correios',
		JADLOG_COMPANY_ID => 'JadLog',
		VIA_BRASIL_COMPANY_ID => 'Via Brasil',
		LATAM_COMPANY_ID => 'LATAM',
		AZUL_COMPANY_ID => 'Azul Cargo',
		BUSLOG_COMPANY_ID => 'Buslog',
	];

	return $companies[$company_id] ?? '';

}

// Add item ID to the method title to easily identificate it elsewhere.
add_filter( '-woocommerce_order_item_get_method_title', function( $value, $shippig_item ){

    if(
    	is_admin() &&
    	!is_null( get_current_screen() ) &&
    	'shop_order' === get_current_screen()->id ?? '' &&
    	'GET' === $_REQUEST['REQUEST_METHOD']
    ){
    	$value = sprintf( '%1s (#%2s)', $value, $shippig_item->get_id() );
    }

    return $value;

}, 15, 2 );


function add_item_id_to_field_label( $label, $item ){

	$label = $label . " (#{$item->get_id()})";
	return $label;

}

add_filter( 'epmp_me_tracking_code_field_label', __NAMESPACE__ . '\add_item_id_to_field_label' , 10, 2 );
add_filter( 'epmp_me_invoice_field_label', __NAMESPACE__ . '\add_item_id_to_field_label' , 10, 2 );

add_filter( 'woocommerce_order_item_get_formatted_meta_data', function( $formatted_meta, $item ){

	if( $item->get_meta( 'ID' ) || 'shipping' !== $item->get_type() ){
		return $formatted_meta;
	}

	$new_formatted = [];

	$new_formatted[] = (object) [
		'key'           => 'ID',
		'value'         => $item->get_id(),
		'display_key'   => 'ID',
		'display_value' => $item->get_id(),
	];

	return array_merge( $new_formatted, $formatted_meta );

}, 10, 2 );

return true;
