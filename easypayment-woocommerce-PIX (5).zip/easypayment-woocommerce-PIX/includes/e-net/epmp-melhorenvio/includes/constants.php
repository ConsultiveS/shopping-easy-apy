<?php
namespace Epmp\ME\constants;

const CORREIOS_COMPANY_ID 	= 1;
const JADLOG_COMPANY_ID 	= 2;
const VIA_BRASIL_COMPANY_ID = 5;
const LATAM_COMPANY_ID      = 6;
const AZUL_COMPANY_ID       = 9;
const BUSLOG_COMPANY_ID     = 12;

// Types of Brazilian documents
const DOCUMENT_TYPE_CPF     = 0;
const DOCUMENT_TYPE_CNPJ    = 1;