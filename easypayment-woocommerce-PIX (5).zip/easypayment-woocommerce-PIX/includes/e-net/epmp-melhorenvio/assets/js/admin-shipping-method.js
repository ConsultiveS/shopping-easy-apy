jQuery( function($){

	var agencies = {}; // little cache

	var $agency = $( '#woocommerce_epmp-melhorenvio_shop_agency' );

	$( '#mainform' ).on('change', '#woocommerce_epmp-melhorenvio_shop_state', function(){
		var state = $(this).val();

		$agency.html('').prop('disabled', true);

		if( !agencies.hasOwnProperty(state) ){
			$.get(
				woocommerce_admin.ajax_url,
				{ 'state' : state, 'action':'epmp_me_get_agencies_by_state' },
				function( response ){
					if( response.success ){
						agencies[state] = response.data;
						populate_select( $agency, agencies[state] );
					}
				}
			);
		} else {
			populate_select( $agency, agencies[state] );
		}
	});

	function populate_select( select, data ){
		select.select2( {'data':data} ).prop('disabled', false);
	}

} );
