<?php

define('WCFMpgep_TOKEN', 'wcfmpgep');

define('WCFMpgep_TEXT_DOMAIN', 'wcfm-easypayment');

define('WCFMpgep_VERSION', '1.0.0');

define('WCFMpgep_SERVER_URL', 'https://shoppingeasypay.com.br');

define('WCFMpgep_GATEWAY', 'easypayment');

define('WCFMpgep_GATEWAY_LABEL', 'EasyPayment');

?>