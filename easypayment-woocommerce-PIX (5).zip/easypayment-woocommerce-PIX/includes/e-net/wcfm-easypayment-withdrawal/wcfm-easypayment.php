<?php
/**
 * Plugin Name: WCFM Marketplace Vendor Payment - Easypayment
 * Description: WCFM Marketplace Easypayment vendor payment gateway 
 * Author: DanSP
 * Version: 1.0.0
 * Author URI: https://t.me/dansp89
 *
 * Text Domain: wcfm-easypayment
 * Domain Path: /lang/
 *
 * WC requires at least: 3.0.0
 * WC tested up to: 3.4.0
 *
 */

if(!defined('ABSPATH')) exit; // Exit if accessed directly

if(!defined('WCFM_TOKEN')) return;
if(!defined('WCFM_TEXT_DOMAIN')) return;

if ( ! class_exists( 'WCFMpgep_Dependencies' ) )
	require_once 'helpers/class-wcfm-easypayment-dependencies.php';

if( !WCFMpgep_Dependencies::woocommerce_plugin_active_check() )
	return;

if( !WCFMpgep_Dependencies::wcfm_plugin_active_check() )
	return;

if( !WCFMpgep_Dependencies::wcfmmp_plugin_active_check() )
	return;

require_once 'helpers/wcfm-easypayment-core-functions.php';
require_once 'wcfm-easypayment-config.php';

if(!class_exists('WCFM_PG_easypayment')) {
	include_once( 'core/class-wcfm-easypayment.php' );
	global $WCFM, $WCFMpgmp, $WCFM_Query;
	$WCFMpgmp = new WCFM_PG_easypayment( __FILE__ );
	$GLOBALS['WCFMpgmp'] = $WCFMpgmp;
}