<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $WCFM, $wp_query,$typenow;

?>
<style>
/* Style the tab */
.dsp_tab {
  overflow: hidden;
  border: 1px solid #cccccccc26c;
  background-color: #008cff;
  border-radius: 20px 20px 0px 0px;
}

/* Style the buttons inside the tab */
.dsp_tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.dsp_tab button:hover {
    background-color: #1c2b36;
    color: #1bff00;
    font-size: 1.5em;
}

/* Create an active/current tablink class */
.dsp_tab button.active {
  background-color: #0b1d63;
}

/* Style the tab content */
.dsp_tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #cccccc26;
  border-top: none;
}
</style>
<div class="collapse wcfm-collapse" id="wcfm_easypayment_listing">
	
	<div class="wcfm-page-headig">
		<span class="fa fa-cubes"></span>
		<span class="wcfm-page-heading-text"><?php _e( 'EasyPayment', 'wcfm-custom-menus' ); ?></span>
		<?php do_action( 'wcfm_page_heading' ); ?>
	</div>
	<div class="wcfm-collapse-content">
		<div id="wcfm_page_load"></div>
		<?php do_action( 'before_wcfm_easypayment' ); ?>
		
		<div class="wcfm-container wcfm-top-element-container">
			<h2><?php _e('Easypayment', 'wcfm-custom-menus' ); ?></h2>
			<div class="wcfm-clearfix"></div>
	  </div>
	  <div class="wcfm-clearfix"></div><br />
		

		<div class="wcfm-container">
			<div id="wcfm_easypayment_listing_expander" class="wcfm-content">
			
				<!--Begin::Content-->
                <div class="dsp_tab">
                  <button class="dsp_tablinks" onclick="dsp_showtab_ep(event, 'overview')"><?php echo __('Overview', 'woocommerce-easypayment')?></button>
                  <button class="dsp_tablinks" onclick="dsp_showtab_ep(event, 'withdraw')"><?php echo __('Withdraw', 'woocommerce-easypayment')?></button>
                  <button class="dsp_tablinks" onclick="dsp_showtab_ep(event, 'api')"><?php echo __('API', 'woocommerce-easypayment')?></button>
                </div>
                
                <div id="overview" class="dsp_tabcontent">
                  <h3><?php echo __('Overview', 'woocommerce-easypayment')?></h3>
                  <p><?php echo __('See the sales overview with EasyPayment', 'woocommerce-easypayment')?></p>
                  <div>
                      <?php
                      $gateways = WC()->payment_gateways->payment_gateways();
                      echo "<pre>";
                      print_r($gateways['easypayment']);
                      echo "</pre>";
                      ?>
                      
                  </div>
                </div>
                
                <div id="withdraw" class="dsp_tabcontent">
                  <h3><?php echo __('Withdraw', 'woocommerce-easypayment')?></h3>
                  <p><?php echo __('Withdraw your Marketplace balance and transfer it to your Easypayment account or bank account.', 'woocommerce-easypayment')?></p> 
                </div>
                
                <div id="api" class="dsp_tabcontent">
                  <h3><?php echo __('API', 'woocommerce-easypayment')?></h3>
                  <p>T<?php echo __('Use the API and see a world of possibilities with EasyPayment', 'woocommerce-easypayment')?></p>
                </div>
				<!--End::Content-->
			
				<div class="wcfm-clearfix"></div>
			</div>
			<div class="wcfm-clearfix"></div>
		</div>
	
		<div class="wcfm-clearfix"></div>
		<?php
		do_action( 'after_wcfm_easypayment' );
		?>
	</div>
</div>
<script>
function dsp_showtab_ep(evt, tabContendaded) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("dsp_tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("dsp_tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(tabContendaded).style.display = "block";
  if(typeof evt !== 'undefined'){
    evt.currentTarget.className += " active";
  }
}
document.addEventListener('DOMContentLoaded', ()=>{
    document.querySelectorAll('.dsp_tab button')[0].click();
});
</script>