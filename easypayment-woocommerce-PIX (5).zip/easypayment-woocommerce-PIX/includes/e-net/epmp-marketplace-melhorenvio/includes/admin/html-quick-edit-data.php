<div class="hidden epmp_shipping_correios_disabled_inline" id="epmp_shipping_correios_disabled_inline_<?php echo $post_id; ?>">
    <div id="correios_disabled"><?php echo get_post_meta($post_id, '_epmp_shipping_correios_disabled', true ); ?></div>
</div>
