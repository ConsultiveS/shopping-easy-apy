<div class="inline-edit-group">
    <label class="manage_stock">
        <input type="checkbox" name="_epmp_shipping_correios_disabled" value="1">
        <span class="checkbox-title"><?php esc_html_e( 'Disable Correios shipping for this product', 'epmp-marketplace-melhorenvio' ); ?></span>
    </label>
</div>
