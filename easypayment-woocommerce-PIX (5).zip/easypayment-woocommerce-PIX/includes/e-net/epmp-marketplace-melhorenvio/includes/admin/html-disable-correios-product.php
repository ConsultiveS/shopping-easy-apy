<p>
<?php
/**
 * @var $thepostid int the product id
 */
woocommerce_wp_checkbox(array(
    'id'    => '_epmp_shipping_correios_disabled',
    'label' => __('Disable Correios shipping for this product', 'epmp-marketplace-melhorenvio'),
));
?>
</p>
