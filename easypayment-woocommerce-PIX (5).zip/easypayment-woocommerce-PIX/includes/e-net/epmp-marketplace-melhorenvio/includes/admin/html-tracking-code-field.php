<li>
    <label>
        <i><strong><?php _e('Vendor', 'epmp-marketplace-melhorenvio')?></strong>: <?=$field_title?></i><br>
        <?php if(!$is_correios):?>
            <?php _e('URL (with HTTP or HTTPS, ex.: https://mytrackingsite.com/)', 'epmp-marketplace-melhorenvio')?>
            <input type="url" id="epmp_mpme_tracking_url_<?=$package_id?>" name="epmp_mpme_tracking_urls[<?=$package_id?>]" value="<?=$epmp_mpme_tracking_url?>" style="width: 100%;">
        <?php endif?>
        <?php _e('Tracking code:', 'epmp-marketplace-melhorenvio')?>
        <input type="text" id="epmp_mpme_tracking_code_<?=$package_id?>" name="epmp_mpme_tracking_codes[<?=$package_id?>]" value="<?=$epmp_mpme_tracking_code?>" style="width: 100%;">
    </label>
</li>
