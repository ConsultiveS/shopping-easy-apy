<h2><?php esc_html_e( 'Correios Corporate Code', 'epmp-marketplace-melhorenvio' ); ?></h2>
<table class="form-table">
    <tr>
        <th><?php esc_html_e( 'Correios Login', 'epmp-marketplace-melhorenvio' ); ?></th>
        <td>
            <input type="text" name="_correios_login" autocomplete="off" class="regular-text" value="<?php echo esc_attr( $correios_login ) ?>">
        </td>
    </tr>

    <tr>
        <th><?php esc_html_e( 'Correios Password', 'epmp-marketplace-melhorenvio' ); ?></th>
        <td>
            <input type="password" name="_correios_password" class="regular-text" placeholder="<?php echo $password_placeholder;?>">
        </td>
    </tr>
</table>
