<?php

use const Epmp\ME\constants\JADLOG_COMPANY_ID;

class Epmp_MPME_Vendor_Config {

	private $vendor_id;

	public function __construct( $vendor_id ) {
		$this->vendor_id = $vendor_id;
	}

	public function get_token(){
		return get_user_meta( $this->vendor_id, '_me_vendor_token', true );
	}

	public function get_fixed_cost(){
		return get_user_meta( $this->vendor_id, '_me_vendor_fixed_cost', true );
	}

	public function get_shipping_zones(){
		return get_user_meta( $this->vendor_id, '_me_vendor_shipping_zones', true );
	}

	public function get_percent_cost(){
		return get_user_meta( $this->vendor_id, '_me_vendor_percent_cost', true );
	}

	public function get_receiver_only(){
		return get_user_meta( $this->vendor_id, '_me_vendor_receiver_only', true );
	}

	public function get_receipt(){
		return get_user_meta( $this->vendor_id, '_me_vendor_receipt', true );
	}

	public function get_collect(){
		return get_user_meta( $this->vendor_id, '_me_vendor_collect', true );
	}

	public function get_services(){
		return get_user_meta( $this->vendor_id, '_me_vendor_services', true );
	}


	public function get_name(){
		return get_user_meta( $this->vendor_id, '_me_vendor_name', true );
	}
	public function get_phone(){
		return get_user_meta( $this->vendor_id, '_me_vendor_phone', true );
	}
	public function get_email(){
		return get_user_meta( $this->vendor_id, '_me_vendor_email', true );
	}
	public function get_additional_time(){
		return get_user_meta( $this->vendor_id, '_me_vendor_additional_time', true );
	}
	public function get_document_type(){
		return get_user_meta( $this->vendor_id, '_me_vendor_document_type', true );
	}
	public function get_document(){
		return get_user_meta( $this->vendor_id, '_me_vendor_document', true );
	}
	public function get_state_register(){
		return get_user_meta( $this->vendor_id, '_me_vendor_state_register', true );
	}
	public function get_address(){
		return get_user_meta( $this->vendor_id, '_me_vendor_address', true );
	}
	public function get_complement(){
		return get_user_meta( $this->vendor_id, '_me_vendor_complement', true );
	}
	public function get_number(){
		return get_user_meta( $this->vendor_id, '_me_vendor_number', true );
	}
	public function get_district(){
		return get_user_meta( $this->vendor_id, '_me_vendor_district', true );
	}
	public function get_city(){
		return get_user_meta( $this->vendor_id, '_me_vendor_city', true );
	}
	public function get_state(){
		return get_user_meta( $this->vendor_id, '_me_vendor_state', true );
	}
	public function get_postal_code(){
		return get_user_meta( $this->vendor_id, '_me_vendor_postal_code', true );
	}
	public function get_agency(){ // Obsolete.
		return get_user_meta( $this->vendor_id, '_me_vendor_agency', true );
	}
	/**
	 * Gets all vendor's agencies listed by company.
	 * @return array An array in th format [ company_id => agency_id ]
	 */
	public function get_agencies(){

		$agencies = get_user_meta( $this->vendor_id, '_me_vendor_agencies', true );

		$agencies = $agencies ? $agencies : [];

		/**
		 * Legacy compatibility.
		 * @var array
		 */
		if( $jadlog_agency = $this->get_agency() && !isset( $agencies[JADLOG_COMPANY_ID] ) ){
			$agencies[JADLOG_COMPANY_ID] = $jadlog_agency;
		}

		return $agencies ? $agencies : [];
	}

	public function get_cnae(){
		return get_user_meta( $this->vendor_id, '_me_vendor_cnae', true );
	}


}
