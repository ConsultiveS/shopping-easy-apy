<?php

use Epmp\ME\Rest_API\{ Config, Endpoint, Request };
use const Epmp\ME\Constants\{ DOCUMENT_TYPE_CPF, DOCUMENT_TYPE_CNPJ };
use const Epmp\ME\Constants\{ LATAM_COMPANY_ID };
use function Epmp\ME\functions\{
	company_requires_agency,
	format_agency_list,
	get_agencies_list,
	get_company_by_service_id,
	get_services_list
};

/**
* Encapsulates functionalities of a WooCommerce marketplace
*
* @author   Luis Eduardo Braschi <https://art-idesenvolvimento.com.br>
* @package
* @todo     Return array of objects instead of arrays on "{split_packages_per_vendor}"
*/
abstract class Epmp_MPME_Abstract_Vendors_Provider {

	public $is_active = true;
	protected $provider_not_found_message = '';
	protected $vendor_config;

	/**
	 * Check if user is vendor based on user ID
	 * @todo Move to interface
	 * @param  int  $user_id
	 * @return boolean
	 */
	abstract public function is_vendor( $user_id );

	/**
	 * Check if current page is vendor's dashboard
	 * @todo Move to interface
	 * @return boolean
	 */
	abstract public function is_vendor_dashboard();

	/**
	 *
	 * @todo Move to interface
	 * @return string Either "admin" or "vendor"
	 */
	abstract public function get_shipping_recipient();

	public function get_vendor_config( $user_id ){
		/**
		 * @todo Temporary solution to not load everything at anytime.
		 */
		include_once 'class-vendor-config.php';
		return new Epmp_MPME_Vendor_Config( $user_id );

	}

	public function is_me_enabled( $vendor_id ){
		$enabled = get_user_meta( $vendor_id, '_me_vendor_enabled', true );
		$enabled = empty( $enabled ) ? 'no' : $enabled;
		return apply_filters( 'epmp_mpme_is_vendor_me_enabled', $enabled, $vendor_id );
	}

	protected function split_packages_per_vendor( $order_id ){

		/**
		 * @todo Must throw an exception
		 */
		if( !wc_get_order( $order_id ) ) {
			return [];
		}

		$packages = wc_get_order( $order_id )->get_shipping_methods();

		$filtered_packages = [];

		foreach ( $packages as $package_id => $package ) {
			$filtered_packages[$package_id]['id'] = $package_id; // to not need to traverse the array to search for it
			$filtered_packages[$package_id]['vendor_id'] = wc_get_order_item_meta( $package_id, 'vendor_id' );
			$filtered_packages[$package_id]['cost'] = wc_get_order_item_meta( $package_id, 'cost' );
		}

		return $filtered_packages;

	}

	/**
	 * Retrieves vendors shipping amount for the order
	 * @param  int|string $order_id
	 * @param  int|string $vendor_id
	 * @return int            The sum of the shipping costs of all packages from the order
	 */
	public function get_order_shipping_amount_for_vendor( $order_id, $vendor_id ) {

		$packages = $this->get_package_by_vendor( $order_id, $vendor_id );
		$total_amount = array_sum( wp_list_pluck( $packages, 'cost' ) );

		return empty( $total_amount )?0:$total_amount;

	}

	/**
	 * Gets the shipping package sold by the vendor
	 * @param  int $order_id the ID of the order
	 * @return array         the package( s ) from the vendor, if any; empty array otherwise
	 */
	public function get_package_by_vendor( $order_id, $vendor_id ) {

		$vendor_packages = $this->split_packages_per_vendor( $order_id );
		$vendor_packages = array_filter( $vendor_packages, function( $package ) use ( $vendor_id ){
			return (int) $package['vendor_id'] === (int) $vendor_id;
		} );

		return count( $vendor_packages ) ? $vendor_packages : [];

	}

	/**
	 * Gets the comission incremented or decremented by the shipping
	 * @param  int $order_id the ID of the order
	 * @return float         the total
	 */
	abstract public function get_order_comission_by_vendor( $order_id, $vendor_id );

	/**
	 * Making sure the marketplace plugin is active
	 * @return void
	 */
	public function provider_not_found(){

		$message = $this->provider_not_found_message;
		$notice_type = 'warning';

		ob_start();
		include EPMP_MPME_DIR . '/includes/admin/html-notice.php';
		$message_template = ob_get_clean();

		echo apply_filters( 'epmp_mpme_provider_not_found_message', $message_template, $message, $notice_type );

	}

	/**
	 * Render corporate fields accordingly
	 * @param  int $vendor_id
	 * @param  string $template
	 * @return void
	 */
	protected function render_vendor_token_field_html( $vendor_id, $template ){
		if( apply_filters( 'epmp_mpme_allow_vendor_token', true, $vendor_id ) ){

			$vendor_config = $this->get_vendor_config( $vendor_id );
			$vendor_token = $vendor_config->get_token();
			include_once $template;

		}
	}

	/**
	 * Render corporate fields accordingly
	 * @param  int $vendor_id
	 * @param  string $template
	 * @return void
	 */
	protected function render_vendor_address_fields_html( $vendor_id, $template ){

		$services = get_services_list();
		$services = [ 0 => __( 'All', 'epmp-marketplace-melhorenvio' ) ] + $services;

		$enabled  = $this->is_me_enabled( $vendor_id );

		$vendor_config = $this->get_vendor_config( $vendor_id );

		$receiver_only   = $vendor_config->get_receiver_only();
		$receipt         = $vendor_config->get_receipt();
		$collect         = $vendor_config->get_collect();
		$vendor_services = $vendor_config->get_services();
		$vendor_services = empty( $vendor_services ) ? [] : $vendor_services;

		$vendor_name            = $vendor_config->get_name();
		$vendor_phone           = $vendor_config->get_phone();
		$vendor_email           = $vendor_config->get_email();
		$vendor_additional_time = $vendor_config->get_additional_time();
		$vendor_document_type   = $vendor_config->get_document_type();
		$vendor_document        = $vendor_config->get_document();
		$vendor_cnae            = $vendor_config->get_cnae();
		$vendor_state_register  = $vendor_config->get_state_register();
		$vendor_address         = $vendor_config->get_address();
		$vendor_complement      = $vendor_config->get_complement();
		$vendor_number          = $vendor_config->get_number();
		$vendor_district        = $vendor_config->get_district();
		$vendor_city            = $vendor_config->get_city();
		$vendor_state           = $vendor_config->get_state();
		$vendor_postal_code     = $vendor_config->get_postal_code();
		$vendor_agencies        = $vendor_config->get_agencies();
		$vendor_agencies 		= empty( $vendor_agencies ) ? [] : $vendor_agencies;

		/**
		 * List of agencies and their attributes (@see `format_agency_list`) grouped by company ID
		 * @var array
		 */
		$agency_lists = [];

		// 0 means 'all'
		$vendor_services_to_agency = in_array( 0, $vendor_services ) ? array_keys( get_services_list() ) : $vendor_services;

		foreach( $vendor_services_to_agency as $service_id ){

			$company_id = get_company_by_service_id( $service_id );

			if( !company_requires_agency( $company_id ) ){
				continue;
			}

			$agencies = get_agencies_list( $vendor_state, $company_id );
			$vendor_agency_for_company = $vendor_agencies[$company_id] ?? 0;
			$agency_lists[$company_id] = format_agency_list( $agencies, $vendor_agency_for_company );

		}

		$show_cnae_field = DOCUMENT_TYPE_CNPJ === (int) $vendor_document_type && array_key_exists( (string) LATAM_COMPANY_ID, $vendor_agencies );

		include_once $template;

	}


	/**
	 * Helper function to load the address from the store config with Ajax
	 * @return void
	 */
	public abstract function load_address_from_store_config();

	/**
	 * Loads user info and template to be displayed in the front-end
	 * @param  int $vendor_id
	 * @param  string $template
	 * @return void
	 */
	protected function load_me_user_info_template( $vendor_id, $template ){

		if( !apply_filters( 'epmp_mpme_allow_vendor_token', true, $vendor_id ) ){
			return;
		}

		add_filter( 'epmp_me_api_token', function() use ( $vendor_id ){
			return get_user_meta( $vendor_id, '_me_vendor_token', true );
		} );

		$balance = Config::get_balance();

		$formatted_balance = sprintf( __( 'Your Melhor Envio balance is: <strong>%s</strong>', 'epmp-marketplace-melhorenvio' ), wc_price( $balance->balance ?? '--' ) );

		$formatted_token_expiry = epmp_mpme_get_formatted_token_expiry( $vendor_id );

		include_once $template;


	}

}
