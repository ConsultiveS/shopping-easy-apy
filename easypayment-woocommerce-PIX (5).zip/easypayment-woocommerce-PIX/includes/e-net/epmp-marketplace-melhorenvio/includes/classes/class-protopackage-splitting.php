<?php

/**
 * Will split cart items into templates of packages here called "protopackages".
 */
class Epmp_MPME_ProtoPackage_Splitting {

    private static $protopackages = array();

    public static function add_item( $item ){

        $product = $item['data'];
        $product_id = $product->get_id();

        $vendor_provider = Epmp_MPME_Provider_Factory::$current_provider;
        $vendor_id = 0;

        try {

            $vendor_id = $vendor_provider->get_vendor_id_from_product( $product_id );

        } catch ( Exception $e ) {

           epmp_mpme_log( $e->getMessage() );
           epmp_mpme_show_messages_in_cart( $e->getMessage() );

        }

        $context = apply_filters( 'epmp_mpme_protopackage_set_product_context', 'regular', $item, $vendor_id );

        self::split_protopackages_by_context( $vendor_id, $context, $item );

    }

    public static function split_protopackages_by_context( $vendor_id, $context, $item ){

        $product = $item['data'];
        $product_id = $product->get_id();

        $vendor_provider = Epmp_MPME_Provider_Factory::$current_provider;

        $post_code = '';

        try {

            $post_code = $vendor_provider->get_vendor_postcode( $vendor_id );

        } catch ( Exception $e ) {

           epmp_mpme_log( $e->getMessage() );
           epmp_mpme_show_messages_in_cart( $e->getMessage() );

        }

        self::$protopackages[$vendor_id][$context]['items'][$product_id] = $item;
        self::$protopackages[$vendor_id][$context]['vendor_id'] = $vendor_id;
        self::$protopackages[$vendor_id][$context]['vendor_name'] = $vendor_provider->get_vendor_name( $vendor_id );
        self::$protopackages[$vendor_id][$context]['post_code'] = $post_code;

    }

    public static function reset_protopackages(){
        self::$protopackages = array();
    }

    /**
     * Return the protopackages sorted by vendor ID
     * @return array
     */
    public static function get_split_protopackages(){
        ksort( self::$protopackages );
        return apply_filters( 'epmp_mpme_get_split_protopackages', self::$protopackages );
    }

}
