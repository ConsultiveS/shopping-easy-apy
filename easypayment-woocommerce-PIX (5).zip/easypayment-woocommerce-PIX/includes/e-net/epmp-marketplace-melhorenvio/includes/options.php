<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

add_action( 'admin_menu', 'epmp_mpme_add_admin_menu' );
add_action( 'admin_init', 'epmp_mpme_settings_init' );

add_action( 'admin_menu', 'epmp_mpme_get_settings_link');
/**
 * Get settings link
 * @return string The link
 */
function epmp_mpme_get_settings_link(){
    add_filter( 'epmp_mpme_settings_page_url', function(){
        return menu_page_url( EPMP_MPME_SLUG, false );
    });
}

add_filter('plugin_action_links_'.EPMP_MPME_BASENAME, 'epmp_mpme_settings_link' );
/**
 * Add settings link on plugin page
 */
function epmp_mpme_settings_link($links) {
    $url = apply_filters('epmp_mpme_settings_page_url', '');
    $settings_link = "<a href='$url'>".__('Settings', 'epmp-marketplace-melhorenvio')."</a>";
    array_unshift($links, $settings_link);
    return $links;
}


function epmp_mpme_add_admin_menu(){

    add_submenu_page( 'woocommerce',
        'WooCommerce Marketplace/Melhor Envio',
        'WooCommerce Marketplace/Melhor Envio',
        'manage_options',
        EPMP_MPME_SLUG,
        'epmp_mpme_options_page' );

}


function epmp_mpme_settings_init(){

    register_setting( 'epmp_mpme_settings', 'epmp_mpme_vendor_provider' );
    register_setting( 'epmp_mpme_settings', 'epmp_mpme_vendorname_on_calculator' );
    register_setting( 'epmp_mpme_settings', 'epmp_mpme_vendorname_on_calculator_text', 'wp_filter_nohtml_kses' );
    // register_setting( 'epmp_mpme_settings', 'epmp_mpme_corporate_code_disabled' );
    register_setting( 'epmp_mpme_settings', 'epmp_mpme_one_method_allowed' );
    register_setting( 'epmp_mpme_settings', 'epmp_mpme_debug' );

    add_settings_section(
        'epmp_mpme_settings_section',
        'WooCommerce Marketplace/Melhor Envio',
        null,
        'epmp_mpme_settings'
    );

    add_settings_field(
        'epmp_mpme_vendor_provider',
        __( 'Choose the marketplace provider adapter', 'epmp-marketplace-melhorenvio' ),
        'epmp_mpme_vendor_provider',
        'epmp_mpme_settings',
        'epmp_mpme_settings_section',
        array(
            'id' => 'epmp_mpme_vendor_provider',
            'label_for' => 'epmp_mpme_vendor_provider',
            'description' => __( 'This is the name of the marketplace plug-in you are using', 'epmp-marketplace-melhorenvio' )
        )
    );

    add_settings_field(
        'epmp_mpme_vendorname_on_calculator',
        __( 'Display vendors\' info in the calculator', 'epmp-marketplace-melhorenvio' ),
        'epmp_mpme_checkbox_element_callback',
        'epmp_mpme_settings',
        'epmp_mpme_settings_section',
        array(
            'id' => 'epmp_mpme_vendorname_on_calculator',
            'label_for' => 'epmp_mpme_vendorname_on_calculator',
            'label' => __( 'Display info about the vendor of the products in the left column of the shipping calculator.',
                            'epmp-marketplace-melhorenvio' )
        )
    );

    add_settings_field(
        'epmp_mpme_vendorname_on_calculator_text',
        __( 'Text to be displayed in the calculator', 'epmp-marketplace-melhorenvio' ),
        'epmp_mpme_textarea_element_callback',
        'epmp_mpme_settings',
        'epmp_mpme_settings_section',
        array(
            'id' => 'epmp_mpme_vendorname_on_calculator_text',
            'label_for' => 'epmp_mpme_vendorname_on_calculator_text',
            'description' => __( 'You can use these placeholders to add dynamic content to the text: <code>{vendor_name}</code> (the name of the store) and <code>{vendor_postcode}</code> (the post code). EG., the text <code>{vendor_name} ({vendor_postcode})</code> is translated into "Name of the Store (90020-120)". Default is the store name',
                            'epmp-marketplace-melhorenvio' ),
            'default' => '{vendor_name}'
        )
    );

    // add_settings_field(
    //     'epmp_mpme_corporate_code_disabled',
    //     __( 'Disable corporate code for vendors', 'epmp-marketplace-melhorenvio' ),
    //     'epmp_mpme_checkbox_element_callback',
    //     'epmp_mpme_settings',
    //     'epmp_mpme_settings_section',
    //     array(
    //         'id' => 'epmp_mpme_corporate_code_disabled',
    //         'label_for' => 'epmp_mpme_corporate_code_disabled',
    //         'label' => __( 'Vendors won\'t see the Correios login fields in their profile.',
    //                         'epmp-marketplace-melhorenvio' ),
    //     )
    // );

    add_settings_field(
        'epmp_mpme_one_method_allowed',
        __( 'Group all packages in one', 'epmp-marketplace-melhorenvio' ),
        'epmp_mpme_checkbox_element_callback',
        'epmp_mpme_settings',
        'epmp_mpme_settings_section',
        array(
            'id' => 'epmp_mpme_one_method_allowed',
            'label_for' => 'epmp_mpme_one_method_allowed',
            'label' => __( 'Group the packages from all the vendors and sum their totals.', 'epmp-marketplace-melhorenvio' ),
            'description' => __( 'Keep in mind that only methods set globally in the Shipping Zone settings can be used.', 'epmp-marketplace-melhorenvio' ),
            'default' => 'yes'
        )
    );

    $logs_url = esc_url(
                    add_query_arg(
                        'log_file',
                        wc_get_log_file_name( 'epmp-mpme' ),
                        admin_url( 'admin.php?page=wc-status&tab=logs' )
                    )
                );

    $logs_link = sprintf( '<a href="%1$s">%2$s</a>', $logs_url, __( 'Check logs.', 'epmp-marketplace-melhorenvio' ) );

    add_settings_field(
        'epmp_mpme_debug',
        __( 'Debug this extension', 'epmp-marketplace-melhorenvio' ),
        'epmp_mpme_checkbox_element_callback',
        'epmp_mpme_settings',
        'epmp_mpme_settings_section',
        array(
            'id' => 'epmp_mpme_debug',
            'label_for' => 'epmp_mpme_debug',
            'description' => __( 'Logs errors related to Art-i Marketplace/Melhor Envio.',
                                 'epmp-marketplace-melhorenvio' ) . " $logs_link",
            'label' => __( 'Enables plug-in debugging.', 'epmp-marketplace-melhorenvio' ) ,
        )
    );

}

function epmp_mpme_textarea_element_callback( $args ) {

    $id      = $args['id'];
    $option = get_option( $id );

    if ( $option ) {
        $current = $option;
    } else {
        $current = isset( $args['default'] ) ? $args['default'] : '';
    }

    include dirname( __FILE__ ) . '/admin/html-textarea-field.php';

}
function epmp_mpme_checkbox_element_callback( $args ) {
    $id      = $args['id'];
    $option = get_option( $id );

    if ( isset( $option ) ) {
        $current = $option;
    } else {
        $current = isset( $args['default'] ) ? $args['default'] : '0';
    }

    include dirname( __FILE__ ) . '/admin/html-checkbox-field.php';
}

function epmp_mpme_vendor_provider( $args ){

    $providers_list = epmp_mpme_get_providers_list();
    $providers = apply_filters('epmp_mpme_list_providers', $providers_list);

    $vendor_provider = get_option( 'epmp_mpme_vendor_provider' );

    ?>
    <select name='epmp_mpme_vendor_provider'>
        <option value=''><?php _e('Please select an option.', 'epmp-marketplace-melhorenvio')?></option>
    <?php foreach($providers as $provider):?>
        <option value='<?=$provider->get_slug()?>' <?php selected( $vendor_provider, $provider->get_slug() ); ?>>
            <?=$provider->get_name()?>
        </option>
    <?php endforeach?>
    </select>
    <?php if ( isset( $args['description'] ) ) : ?>
        <p class="description"><?php echo wp_kses_post( $args['description'] ); ?></p>
    <?php endif;
}

function epmp_mpme_options_page(){

    ?>
    <form action='options.php' method='post'>

        <?php
            settings_fields( 'epmp_mpme_settings' );
            do_settings_sections( 'epmp_mpme_settings' );
            submit_button();
        ?>

    </form>
    <p><?php
        // translators: %s URL to docs
        printf(
            __( 'Read more about theses settings <a href="%s" target="_blank" rel="noopener noreferrer">here</a>',
                'epmp-marketplace-melhorenvio' ),
            'https://art-idesenvolvimento.com.br/wordpress/plugins/frete-correios-marketplace/manual.html?utm_source=client-admin'
        );?>
    </p>
    <?php

}
