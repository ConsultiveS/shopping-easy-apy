<?php

use const Epmp\ME\Constants\{ DOCUMENT_TYPE_CNPJ, CORREIOS_COMPANY_ID };
use Epmp\ME\Payload\User_Info;
use function Epmp\ME\functions\{
	format_postcode,
	get_company_to_service_ids_map,
	get_company_name_by_id,
	item_can_bypass_invoice
};

if ( ! defined( 'ABSPATH' ) ) {
		exit; // Exit if accessed directly.
}

/**
 * Assigns the vendor's postcode to their package
 * @param  string     $origin_postcode
 * @param  string/int $id
 * @param  string/int $instance_id
 * @param  array      $package
 * @return string
 * @todo  merge with epmp_mpme_vendor_postcode()
 */
function epmp_mpme_get_origin_postcode( $origin_postcode, $package ){

	$origin_postcode = epmp_mpme_vendor_postcode( $origin_postcode, $package );

	return $origin_postcode;

}

add_filter('epmp_me_from_postcode', 'epmp_mpme_get_origin_postcode', 10, 2);

function epmp_mpme_shipping_simulator_package( $package, $product ){

	if( isset( $package['vendor_postcode'] ) && !empty( $package['vendor_postcode'] ) ){
		return $package;
	}

	$vendor_provider = epmp_mpme_current_provider();

	if( is_array( $product ) ){
		$product_id = $product['variation_id'] > 0 ? $product['variation_id'] : $product['product_id'];
		$product = wc_get_product( $product_id );
	}

	$product_id = $product->get_id();

	$post_code = '';

	try {

		$vendor_id = $vendor_provider->get_vendor_id_from_product($product_id);
		$post_code = $vendor_provider->get_vendor_postcode($vendor_id);

	} catch ( Exception $e ) {

		epmp_mpme_log( $e->getMessage(), 'epmp-mpme-wc-simulador' );

	}

	$package['vendor_postcode'] = $post_code;
	$package['vendor_id'] = $vendor_id;

	return $package;

}

add_filter('wc_shipping_simulator_package', 'epmp_mpme_shipping_simulator_package', 30, 2);

/**
 * Show delivery time in product page simulator by Fernando Acosta
 * @param  int $def
 * @param  array $meta_data
 * @return int
 */
function epmp_mpme_shiping_simulator_forecast( $def, $meta_data ){
    return $meta_data['_delivery_time'] ?? $def;
}

add_filter( 'wc_simulador_frete_meta_delivery_time', 'epmp_mpme_shiping_simulator_forecast', 10, 2 );

/**
 * @todo Rename to `epmp_mpme_set_from_info`
 */
function epmp_mpme_set_from_info( $from_info, $package ){

	if( apply_filters( 'epmp_mpme_use_admin_from_info', false, $package ) ){
		return $from_info;
	}

	$vendor_id = $package['shipping_item']->get_meta( 'vendor_id' );

	$vendor_config = epmp_mpme_current_provider()->get_vendor_config( $vendor_id );

	$vendor_name            = $vendor_config->get_name();
	$vendor_phone           = $vendor_config->get_phone();
	$vendor_email           = $vendor_config->get_email();
	$vendor_additional_time = $vendor_config->get_additional_time();
	$vendor_document_type   = $vendor_config->get_document_type();
	$vendor_document        = $vendor_config->get_document();
	$vendor_cnae            = $vendor_config->get_cnae();
	$vendor_state_register  = $vendor_config->get_state_register();
	$vendor_address         = $vendor_config->get_address();
	$vendor_complement      = $vendor_config->get_complement();
	$vendor_number          = $vendor_config->get_number();
	$vendor_district        = $vendor_config->get_district();
	$vendor_city            = $vendor_config->get_city();
	$vendor_state           = $vendor_config->get_state();
	$vendor_postal_code     = $vendor_config->get_postal_code();

	$from_info = new User_Info;

	$from_info->set_name(  $vendor_name );
	$from_info->set_phone( $vendor_phone );
	$from_info->set_email( $vendor_email );

	if( DOCUMENT_TYPE_CNPJ === (int) get_user_meta( $vendor_id, '_me_vendor_document_type', true ) ){
		$from_info->set_company_document( $vendor_document );
		$from_info->set_state_register( $vendor_state_register );
		$from_info->set_economic_activity_code( $vendor_cnae );
	} else {
		$from_info->set_document( $vendor_document );
	}

	$from_info->set_address(    $vendor_address );
	$from_info->set_complement( $vendor_complement );
	$from_info->set_number(     $vendor_number );
	$from_info->set_district(   $vendor_district );
	$from_info->set_city(       $vendor_city );
	$from_info->set_state_abbr( $vendor_state );
	$from_info->set_country_id( 'BR' );
	$from_info->set_postal_code( format_postcode( $vendor_postal_code ) );

	return $from_info;

}

add_filter( 'epmp_me_set_from_info', 'epmp_mpme_set_from_info', 10, 2 );

function epmp_mpme_set_to_info( $to_info, $package, $order ){

    if( $parent_order_id = $order->get_parent_id() ){

        $parent_order = wc_get_order( $parent_order_id );

        $phone = $parent_order->get_billing_phone();
        $phone = $phone ? $phone : $parent_order->get_meta( '_billing_cellphone' );

        $to_info->set_phone( $phone );
        $to_info->set_document( $parent_order->get_meta( '_billing_cpf' ) );
        $to_info->set_company_document( $parent_order->get_meta( '_billing_cnpj' ) );
		$to_info->set_state_register( $order->get_meta( '_billing_ie' ) );
        $to_info->set_number( $parent_order->get_meta( '_shipping_number' ) );
        $to_info->set_district( $parent_order->get_meta( '_shipping_neighborhood' ) );

    }

    return $to_info;
}

add_filter( 'epmp_me_set_to_info', 'epmp_mpme_set_to_info', 10, 3 );

function epmp_mpme_set_options( $options, $package ){

	$shipping_item = $package['shipping_item'];
	$vendor_id = $shipping_item->get_meta( 'vendor_id' );

	if( $vendor_id ){

		if( DOCUMENT_TYPE_CNPJ === (int) get_user_meta( $vendor_id, '_me_vendor_document_type', true ) ){

			$item_invoice = $shipping_item->get_meta( '_invoice_number', true );

			$company_id = $shipping_item->get_meta( '_company_id', true );
			$is_non_commercial = false;
			$item_can_bypass_invoice = item_can_bypass_invoice( $shipping_item->get_id() );

			if( empty( $item_invoice ) && $item_can_bypass_invoice ){
				$is_non_commercial = true;
			}

			if( empty( $item_invoice ) && !$item_can_bypass_invoice ){
				/* translators: 1: Shipping item ID 2: Vendor ID */
				$log_message = __( 'Missing invoice number to shipping item %d from vendor with ID %d', 'epmp-marketplace-melhorenvio' );
				epmp_mpme_log( sprintf( $log_message, $shipping_item->get_id(), $vendor_id ) );
			}

			$options->set_non_commercial( $is_non_commercial );

			$options->set_invoice_key( $item_invoice );

		}

		$vendor_config = epmp_mpme_current_provider()->get_vendor_config( $vendor_id );

		$options->set_own_hand( wc_string_to_bool( $vendor_config->get_receiver_only() ) );
		$options->set_receipt( wc_string_to_bool( $vendor_config->get_receipt() ) );
		$options->set_collect( wc_string_to_bool( $vendor_config->get_collect() ) );

	}

	return $options;
}

add_filter( 'epmp_me_set_options', 'epmp_mpme_set_options', 10, 3 );

function epmp_mpme_add_vendor_agency_id( $vendor_agency, $package ){

	$vendor_id = $package['shipping_item']->get_meta( 'vendor_id' );

	$use_admin_info = apply_filters( 'epmp_mpme_use_admin_from_info', false, $package );

	$vendor_config = epmp_mpme_current_provider()->get_vendor_config( $vendor_id );

	if( !$use_admin_info && ( $agencies = $vendor_config->get_agencies() ) ){

		$shipping_item = $package['shipping_item'];
		$company_id = $shipping_item->get_meta( '_company_id', true );

		$vendor_agency = $agencies[$company_id];

	}

	return (string) $vendor_agency;

}

add_filter( 'epmp_me_set_agency_id', 'epmp_mpme_add_vendor_agency_id', 10, 2 );

function epmp_mpme_get_vendor_available_services( $services, $package ){

	if( empty( get_user_meta( $package['vendor_id'] ?? '', '_me_vendor_agency', true ) ) ){
		$services = array_diff( $services, [3, 4] );
	}

	return $services;
}

add_filter( 'epmp_me_available_services', 'epmp_mpme_get_vendor_available_services', 10, 2 );

function epmp_mpme_get_vendor_receiver_only( $receiver_only, $package ){

	$receiver_only = get_user_meta( $package['vendor_id'] ?? 0, '_me_vendor_receiver_only', true );

	return wc_string_to_bool( $receiver_only );

}

add_filter( 'epmp_me_receiver_only', 'epmp_mpme_get_vendor_receiver_only', 10, 2 );

function epmp_mpme_get_vendor_receipt( $receipt, $package ){

	$receipt = get_user_meta( $package['vendor_id'] ?? 0, '_me_vendor_receipt', true );

	return wc_string_to_bool( $receipt );

}

add_filter( 'epmp_me_receipt', 'epmp_mpme_get_vendor_receipt', 10, 2 );

function epmp_mpme_get_vendor_collect( $collect, $package ){

	$collect = get_user_meta( $package['vendor_id'] ?? 0, '_me_vendor_collect', true );

	return wc_string_to_bool( $collect );

}

add_filter( 'epmp_me_collect', 'epmp_mpme_get_vendor_collect', 10, 2 );

function epmp_mpme_get_vendor_non_commercial( $non_commercial, $package ){

	$vendor_id = $package['vendor_id'] ?? 0;

	$non_commercial = DOCUMENT_TYPE_CNPJ !== (int) get_user_meta( $vendor_id, '_me_vendor_document_type', true );

	return $non_commercial;

}

add_filter( 'epmp_me_non_commercial', 'epmp_mpme_get_vendor_non_commercial', 10, 2 );

function epmp_mpme_remove_services_if_no_agency_selected( $services, $package ){

	$vendor_config = epmp_mpme_current_provider()->get_vendor_config( $package['vendor_id'] ?? 0 );

	$vendor_agencies = $vendor_config->get_agencies();

	$company_services_map = get_company_to_service_ids_map();

	foreach( $vendor_agencies as $company_id => $vendor_agency ) {
		if( !$vendor_agency ){

			$services_with_no_agency = $company_services_map[$company_id] ?? [];
			$services = array_diff( $services, $services_with_no_agency );

			/* translators: 1: vendor ID 2: company name */
			$message = __(
				'Vendor with ID %1$s has no agency assigned to company %2$s', 'epmp-marketplace-melhorenvio'
			);

			epmp_mpme_log( sprintf( $message, $package['vendor_id'] ?? 0, get_company_name_by_id( $company_id ) ) );
		}
	}

	return $services;

}

add_filter( 'epmp_me_available_services', 'epmp_mpme_remove_services_if_no_agency_selected', 30, 2 );

function epmp_mpme_add_integration_fields( $fields ){

	$current_settings_translation = [
		'vendor' => _x( 'vendor', 'shipping goes to', 'epmp-marketplace-melhorenvio' ),
		'admin' => _x( 'admin', 'shipping goes to', 'epmp-marketplace-melhorenvio' ),
	];

    $current_settings = epmp_mpme_current_provider()->get_shipping_recipient();

    $label = sprintf(
    	/* translators: %s: shipping goes to */
        __( 'Use the shipping settings from the marketplace. Current settings are: shipping goes to %s.', 'epmp-marketplace-melhorenvio' ),
        $current_settings_translation[$current_settings]
    );

    $fields['use_marketplace_shipping_settings'] = [
        'title'             => __( 'Use marketplace shipping setting', 'epmp-marketplace-melhorenvio' ),
        'type'              => 'checkbox',
        'label'             => $label,
        'default'           => 'no',
        'description'       => __( 'If the shipping is set to go to the admin, the "token" field will not be displayed in the vendor dashboard.', 'epmp-marketplace-melhorenvio' ),
    ];


    $fields['use_admin_token_as_fallback'] = [
        'title'             => __( 'Use admin\'s token as fallback', 'epmp-marketplace-melhorenvio' ),
        'type'              => 'checkbox',
        'label'             => '&nbsp;',
        'default'           => 'no',
        'description'       => __( "The vendors will use the admin's token to generate their labels if they don't provide their token in their panels.", 'epmp-marketplace-melhorenvio' ),
    ];

    return $fields;
}

add_filter( 'woocommerce_settings_api_form_fields_melhorenvio-integration', 'epmp_mpme_add_integration_fields' );
