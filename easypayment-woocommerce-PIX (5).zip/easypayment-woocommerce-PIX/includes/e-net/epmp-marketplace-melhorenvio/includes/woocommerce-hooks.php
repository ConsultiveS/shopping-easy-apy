<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * Add vendors' names to the shipping list
 * @param  string $name    The name providade by the API
 * @param  int|string $i   The index of the shipping package
 * @param  array $package  The shipping package
 * @return string
 */
function epmp_mpme_show_vendor_info_in_shipping_calculator( $name, $i, $package ){

	if( get_option( 'epmp_mpme_vendorname_on_calculator' ) ){

		$provider = epmp_mpme_current_provider();
		$vendor_name = $provider->get_vendor_name( $package['vendor_id'] );
		$vendor_postcode = '';

		try{

			$vendor_postcode = $provider->get_vendor_postcode( $package['vendor_id'] );

		} catch ( Exception $e ) {

			epmp_mpme_log( $e->getMessage() );

		}

		$template = get_option( 'epmp_mpme_vendorname_on_calculator_text' );

		$replacements = apply_filters( 'epmp_mpme_vendor_info_in_calculator',
			array(
				'{vendor_name}' => $vendor_name,
				'{vendor_postcode}' => $vendor_postcode
			),
			$package
		);

		$name = str_replace(
			array_keys( $replacements ),
			array_values( $replacements ),
			$template
		);

	}

	return esc_html( $name );

}

add_filter( 'woocommerce_shipping_package_name', 'epmp_mpme_show_vendor_info_in_shipping_calculator', 11, 3 );


/**
 * Adding our own templates
 */
function epmp_mpme_template_base_path() {
	/**
	 * Plugin authors will be able to override this to their own plugin path
	 * @var string
	 */
	$epmp_mpme_template_base_path = apply_filters(
		'epmp_mpme_template_base_path',
		untrailingslashit( plugin_dir_path( __FILE__ ) ) . '/woocommerce/'
	);
	return $epmp_mpme_template_base_path;
}

add_filter( 'woocommerce_locate_template', 'epmp_mpme_woocommerce_locate_template', 10, 3 );
