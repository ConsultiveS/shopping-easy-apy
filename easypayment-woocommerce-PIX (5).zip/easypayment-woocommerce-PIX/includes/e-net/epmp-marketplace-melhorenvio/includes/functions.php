<?php

use Epmp\ME\Payload\User_Info;
use Epmp\ME\Rest_API\Config;
use const Epmp\ME\Constants\{ DOCUMENT_TYPE_CPF, DOCUMENT_TYPE_CNPJ };
use const Epmp\ME\Constants\LATAM_COMPANY_ID;
use function Epmp\ME\functions\{ get_company_name_by_id, get_service_to_company_map, format_postcode, is_melhorenvio_method };
/**
 * Marketplace plugins that this plugin supports
 * @return array List of marketplace functionality providers
 */
function epmp_mpme_get_providers_list(){

	$providers_list = [
		'wcfm' 			 => new Epmp_MPME_Provider_Config( 'WCFM', 'wcfm', 'MEWCFM' ),
		'wc-marketplace' => new Epmp_MPME_Provider_Config( 'WC Marketplace Multivendors', 'wc-marketplace','ME_WC_Marketplace'),
		'dokan'          => new Epmp_MPME_Provider_Config( 'Dokan', 'dokan', 'ME_Dokan' ),

	];

	return apply_filters('epmp_mpme_list_providers', $providers_list);
}

/**
 * Returns the global provider loaded
 * @return Epmp_MPME_Shipping_Processor
 */
function epmp_mpme_current_provider(){
	return Epmp_MPME_Provider_Factory::$current_provider;
}

function epmp_mpme_enqueue_scripts() {

	wp_register_script( 'epmp-mpme-dashboard', EPMP_MPME_JS . '/dashboard-functions.js' , [ 'jquery' ], '1.4.6' );
	wp_localize_script(
		'epmp-mpme-dashboard',
		'epmp_me_params',
		array(
			'service_to_company_map' => get_service_to_company_map(),
			'LATAM_COMPANY_ID'    	 => LATAM_COMPANY_ID,
			'DOCUMENT_TYPE_CNPJ'	 => DOCUMENT_TYPE_CNPJ,
		)
	);
}

add_action('wp_enqueue_scripts', 'epmp_mpme_enqueue_scripts');
add_action('admin_enqueue_scripts', 'epmp_mpme_enqueue_scripts');

function epmp_mpme_woocommerce_locate_template($template, $template_name, $template_path = null) {

	global $woocommerce;
	$_template = $template;

	if (! $template_path) {
		$template_path = $woocommerce->template_url;
	}

	$template_base_path = epmp_mpme_template_base_path();

	$template = locate_template(
		[
			$template_path . $template_name,
			$template_name
		   ]
	   );

	$template_relative_path = $template_base_path . $template_path . $template_name;

	if (! $template && file_exists($template_relative_path)){
		$template = $template_relative_path;
	}
	if (! $template) {
		$template = $_template;
	}

	return $template;

}

/**
 * Convert currrent origin postcode into vendor postcode if it exists
 * @param  string $current_postcode
 * @param  array $package
 * @return string
 */
function epmp_mpme_vendor_postcode($origin_postcode, $package) {
	$origin_postcode = isset($package['vendor_postcode'])
					&& !empty($package['vendor_postcode']) ? $package['vendor_postcode'] : $origin_postcode;

	return $origin_postcode;
}

/**
 * Lists all active shipping methods system-wide
 * @return array Array containing the shipping methods in the format ['method-id' => 'Method Title']
 */
function epmp_mpme_list_active_shipping_methods(){
	$active_methods = [];

	$zones = WC_Shipping_Zones::get_zones();
	$methods_in_zones = [];

	foreach ($zones as $zone) {
		$active_methods_in_zone = epmp_mpme_filter_active_methods($zone['shipping_methods']);
		$methods_in_zones = array_merge($methods_in_zones, $active_methods_in_zone);
	}

	$global_shipping_methods = epmp_mpme_filter_active_methods(WC()->shipping->load_shipping_methods());

	$all_active_methods = array_merge($global_shipping_methods, $methods_in_zones);

	return epmp_mpme_methods_to_list($all_active_methods);
}

/**
 * Filters only active methods
 * @param  array $methods
 * @return array
 */
function epmp_mpme_filter_active_methods($methods){
	foreach ($methods as $id => $shipping_method) {
		if ($shipping_method->is_enabled()) {
			$active_methods[$shipping_method->id] = $shipping_method;
		}
	}

	return apply_filters('epmp_mpme_filter_active_methods', $active_methods);
}

/**
 * Creates a ['method-id' => 'Method Title'] list to populate comboboxes etc.
 * @param  array $methods
 * @return array The formatted list
 */
function epmp_mpme_methods_to_list( $methods ){

	$methods_list = [];

	foreach( $methods as $id => $shipping_method ) {
		$method_title = $shipping_method->method_title;
		$methods_list[$shipping_method->id] = $method_title;
	}

	return apply_filters('epmp_mpme_methods_to_list', $methods_list);

}

/**
 * WooCommerce package abstraction
 * @param  array $package_array The data to be inserted in the packacge
 * @return array
 */
function epmp_mpme_default_package($package_array){

	$customer = WC()->customer;

	$defaults = [
			'contents' => [],
			'contents_cost'   => 0,
			'applied_coupons' => WC()->cart->applied_coupons,
			'user'            => ['ID' => $customer->get_id()],
			'destination'     => [
				'country'       => $customer->get_shipping_country(),
				'state'         => $customer->get_shipping_state(),
				'postcode'      => $customer->get_shipping_postcode(),
				'city'          => $customer->get_shipping_city(),
				'address'       => $customer->get_shipping_address(),
				'address_2'     => $customer->get_shipping_address_2()
		   ]
	   ];

	$package_array = wp_parse_args( $package_array, $defaults );

	return $package_array;

}

function epmp_mpme_register_scripts(){
	$min = defined( 'SCRIPT_DEBUG' ) && defined( 'SCRIPT_DEBUG' ) ? '' : '.min';
	$jquery_format_decimals = EPMP_MPME_JS . '/jquery.maskDecimals' . $min . '.js';
	wp_register_script( 'jquery-mask-decimals', $jquery_format_decimals, ['jquery'], true );
}
add_action( 'wp_loaded', 'epmp_mpme_register_scripts' );

/**
 * Helper to check whether method is one from Correios
 * @param  string $method_label
 * @return bool
 */
function epmp_mpme_is_correios_method($method_label){
	return in_array($method_label, epmp_mpme_list_shipping_methods());
}

function epmp_mpme_update_user_meta( $vendor_id, $post_data = null ){

	if( !$post_data ){
		$post_data = $_POST;
	}

	$fields_to_save = apply_filters( 'epmp_mpme_vendor_fields_to_save', [
		'_me_vendor_enabled',
		'_me_vendor_fixed_cost',
		'_me_vendor_percent_cost',
		'_me_vendor_token',
		'_me_vendor_name',
		'_me_vendor_receiver_only',
		'_me_vendor_receipt',
		'_me_vendor_collect',
		'_me_vendor_phone',
		'_me_vendor_email',
		'_me_vendor_additional_time',
		'_me_vendor_document_type',
		'_me_vendor_document',
		'_me_vendor_cnae',
		'_me_vendor_state_register',
		'_me_vendor_address',
		'_me_vendor_complement',
		'_me_vendor_number',
		'_me_vendor_district',
		'_me_vendor_city',
		'_me_vendor_state',
		'_me_vendor_postal_code',
		'_me_vendor_agency',
	] );

	/**
	 * Saving array fields
	 * @todo Abstract this.
	 */
	update_user_meta( $vendor_id, '_me_vendor_agencies', $post_data['_me_vendor_agencies'] ?? [] );
	update_user_meta( $vendor_id, '_me_vendor_shipping_zones', $post_data['_me_vendor_shipping_zones'] ?? [] );
	update_user_meta( $vendor_id, '_me_vendor_services', $post_data['_me_vendor_services'] ?? null );

	$post_data = array_intersect_key( $post_data, array_flip( $fields_to_save ) );

	$post_data = array_map( 'sanitize_text_field', $post_data );
	// Saving unchecked boxes
	$post_data = $post_data + [
		'_me_vendor_enabled' => 'no',
		'_me_vendor_receiver_only' => '',
		'_me_vendor_receipt' => '',
		'_me_vendor_collect' => '',
	];

	array_walk( $post_data, 'epmp_mpme_update_user_meta_field', $vendor_id );

}

function epmp_mpme_update_user_meta_field( $value, $key, $vendor_id ){

	/**
	 * @todo You know what to do.
	 */
	if( '_me_vendor_fixed_cost' === $key ){
		$value = wc_format_decimal( $value );
	}

	update_user_meta( $vendor_id, $key, $value );
}

/**
 * Validate vendor posted data
 * @param  array $post_data Data directly from $_POST or abstracted
 * @return array            List of errors; field names as keys
 */
function epmp_mpme_validate_vendor_fields( $post_data = null ){

	$errors = [];

	if( !$post_data ){
		$post_data = $_POST;
	}

	if( isset( $post_data['_me_vendor_document'] ) ){

		$validation = true;

		if( DOCUMENT_TYPE_CPF === (int) $post_data['_me_vendor_document_type'] ){
			$validation = Extra_Checkout_Fields_For_Brazil_Formatting::is_cpf( $post_data['_me_vendor_document'] );
		} else {
			$validation = Extra_Checkout_Fields_For_Brazil_Formatting::is_cnpj( $post_data['_me_vendor_document'] );
		}

		if( !$validation ){
			$errors['_me_vendor_document'] = __( 'Invalid value for document field', 'epmp-marketplace-melhorenvio' );
		}

	}

	if( isset( $post_data['_me_vendor_postal_code'] ) ){
		if( !WC_Validation::is_postcode( $post_data['_me_vendor_postal_code'], 'BR' ) ){
			$errors['_me_vendor_postal_code'] = __( 'Invalid value for postcode field', 'epmp-marketplace-melhorenvio' );
		}
	} else {
		$errors['_me_vendor_postal_code'] = __( 'Postcode field is mandatory', 'epmp-marketplace-melhorenvio' );
	}

	return apply_filters( 'epmp_mpme_validate_vendor_fields', $errors, $post_data );
}

function epmp_mpme_append_me_suffix_to_error_messages( $errors ){

	foreach( $errors as &$error ){
		$error = "<strong>Melhor Envio:</strong> $error";
	}

	return $errors;
}

add_filter( 'epmp_mpme_validate_vendor_fields', 'epmp_mpme_append_me_suffix_to_error_messages' );

function epmp_mpme_use_vendor_token( $package ){

	$vendor_id = $package['shipping_item']->get_meta( 'vendor_id' );

	if( apply_filters( 'epmp_mpme_allow_vendor_token', true, $vendor_id ) ){

		/**
		 * @todo Throw an error here?
		 */
		$vendor_token = get_user_meta( $vendor_id, '_me_vendor_token', true );

		add_filter( 'epmp_me_api_token', function( $store_token ) use ( $vendor_token ) {

			$fallback_token = '';

			if( wc_string_to_bool( (new Config)->get_option( 'use_admin_token_as_fallback' ) ) ){
				$fallback_token = $store_token;
			}

			return !empty( $vendor_token ) ? $vendor_token : $fallback_token;

		} );

	}
}

add_action( 'epmp_me_before_buy_labels_for_item', 'epmp_mpme_use_vendor_token' );
add_action( 'epmp_me_before_generate_labels_for_item', 'epmp_mpme_use_vendor_token' );

function epmp_mpme_get_available_shipping_zones(){

    $zones = WC_Shipping_Zones::get_zones();

    $available_zones = [];

    foreach( $zones as $zone_id => $zone ){

        $zone_object = new WC_Shipping_Zone( $zone_id );

        $methods = $zone_object->get_shipping_methods( true );

        foreach( $methods as $instance_id => $method ){
            if( is_melhorenvio_method( $method->id ) ){
                $available_zones[$zone_id] = $zone_object->get_zone_name();
            }
        }

    }

    return $available_zones;

}

add_filter( 'epmp_me_is_shipping_available', function( $is_available, $package ){

	$vendor_id = $package['vendor_id'] ?? 0;
	$zone_ids = get_user_meta( $vendor_id, '_me_vendor_shipping_zones', true );

	if( !wc_string_to_bool( epmp_mpme_current_provider()->is_me_enabled( $vendor_id ) ) ){
		return false;
	}

	// If it was already false, will return false anyway.
	if( !empty( $zone_ids ) && $is_available ){
		$shipping_zone = WC_Shipping_Zones::get_zone_matching_package( $package );
		$is_available = in_array( $shipping_zone->get_id() , (array) $zone_ids );
	}

	return $is_available;

}, 10, 2 );

add_filter( 'epmp_me_shipping_additional_time', function( $additional_time, $package ){

	$vendor_id = $package['vendor_id'] ?? 0;

	if( $vendor_additional_time = (int) get_user_meta( $vendor_id, '_me_vendor_additional_time', true ) ){
		return max( $vendor_additional_time, $additional_time );
	}

	return $additional_time;

}, 50, 2 ); // 50 because product additional time (priority 100) has precendence

function epmp_mpme_shipping_rate( $rate, $package ){

	$vendor_id = $package['vendor_id'] ?? 0;

	if( !$vendor_id ){
		return $rate;
	}

	$vendor_config = epmp_mpme_current_provider()->get_vendor_config( $vendor_id );

	$current_cost = $rate['cost'];

	/**
	 * @todo Abstract each one one of these.
	 */
	$fixed_cost = floatval( $vendor_config->get_fixed_cost() );
	$percent_cost = floatval( $vendor_config->get_percent_cost() );
	$percent_extra = ( $current_cost / 100 ) * $percent_cost;
	$current_cost += $percent_extra + $fixed_cost;

	$rate['cost'] = $current_cost;

	return $rate;

}
add_filter( 'epmp_me_shipping_rate', 'epmp_mpme_shipping_rate', 15, 2 );

function epmp_mpme_get_tracking_code_list( $label_data ){

	$tracking_code_info = array_column( $label_data['orders'], 'tracking_code' );
	$tracking_code_list = array_column( $tracking_code_info, 'melhorenvio_tracking' );

	return array_map( 'epmp_mpme_get_tracking_code_link', $tracking_code_list );

}

function epmp_mpme_get_tracking_code_link( $tracking_code ){

	$url = sprintf(
	    '<a target="_blank" rel="noopener noreferrer" href="https://www.melhorrastreio.com.br/rastreio/%1$s">%1$s</a>',
	    $tracking_code
	);

	return apply_filters( 'epmp_mpme_get_tracking_code_link', $url, $tracking_code );
}

/**
 * Return the DateTime object containing the expiry date for the token
 * @param  int|string $vendor_id
 * @return DateTime
 */
function epmp_mpme_get_token_expiry( $vendor_id = null ){

	$vendor_id = $vendor_id ?? get_current_user_id();

	$token = get_user_meta( $vendor_id, '_me_vendor_token', true );

	if( empty( $token ) ){
		return false;
	}

	$token_parts = explode( '.', $token );

	$token_payload = json_decode( base64_decode( $token_parts[1] ) );

	$token_expiration_datetime = date_create( "@{$token_payload->exp}" );

	return $token_expiration_datetime;

}

/**
 * Get the ETA for expiry
 * @param  DateTime $token_expiration_datetime
 * @return DateInterval
 */
function epmp_mpme_get_token_expiry_eta( $token_expiration_datetime ){
	return ( new DateTime( 'now' ) )->diff( $token_expiration_datetime );
}

function epmp_mpme_get_formatted_token_expiry( $vendor_id = null ){

	$token_expiry = epmp_mpme_get_token_expiry( $vendor_id );

	if( !$token_expiry ){
		return '';
	}

	$token_expiry_eta = epmp_mpme_get_token_expiry_eta( $token_expiry );

	$formatted_token_expiry = sprintf(
		__(
			'Your token expires in <strong>%s</strong> (<strong>%d</strong> days remaining)',
			'epmp-marketplace-melhorenvio'
		),
		date_i18n( get_option( 'date_format' ), $token_expiry->format( 'U' ) ),
		$token_expiry_eta->days
	);

	return $formatted_token_expiry;
}

/**
 * These fields will be handled by the vendors
 * @param  array $fields
 * @return array
 */
function epmp_mpme_hide_method_fields( $fields ){

    unset(
        $fields['receipt'],
        $fields['receiver_only'],
        $fields['additional_time'],
        $fields['shipping_class_ids'],
        $fields['shop_name'],
        $fields['shop_phone'],
        $fields['shop_email'],
        $fields['shop_document_type'],
        $fields['shop_document'],
        $fields['shop_cnae'],
        $fields['shop_address'],
        $fields['shop_complement'],
        $fields['shop_number'],
        $fields['shop_district'],
        $fields['shop_city'],
        $fields['shop_postal_code'],
        $fields['shop_agency']
    );

    $fields['shop_state'] = [];
    $fields['shop_state']['type'] = 'remove'; // this is for stopping nagging about unset field
    $fields['shop_state']['default'] = [];

    return $fields;

}

add_filter( 'woocommerce_shipping_instance_form_fields_epmp-melhorenvio', 'epmp_mpme_hide_method_fields' );

function epmp_mpme_get_vendor_services( $services, $package, $method ){

	$services = get_user_meta( $package['vendor_id'] ?? 0, '_me_vendor_services', true );

	// Empty array means ALL.
	return empty( $services ) ? [] : $services;

}

add_filter( 'epmp_me_available_services', 'epmp_mpme_get_vendor_services', 20, 3 );

function epmp_mpme_is_invoice_required_for_vendor( $vendor_id ){

	$is_required = DOCUMENT_TYPE_CNPJ === (int) get_user_meta( $vendor_id, '_me_vendor_document_type', true );

	return apply_filters( 'epmp_mpme_is_invoice_required_for_vendor', $is_required, $vendor_id );

}

function epmp_mpme_can_user_manage_me( $user_id = null ){
	return apply_filters(
		'epmp_mpme_user_can_manage_me',
		current_user_can( 'administrator' ),
		get_current_user_id(),
		$user_id
	);
}

function epmp_mpme_vendor_can_generate_labels( $user_id ){
	return apply_filters(
		'epmp_mpme_vendor_can_generate_labels',
		epmp_mpme_current_provider()->is_vendor( $user_id ),
		$user_id
	);
}

function epmp_mpme_allow_vendor_token( $allow ){

    if( wc_string_to_bool( (new Config)->get_option( 'use_marketplace_shipping_settings' ) ) ){
        return 'vendor' === epmp_mpme_current_provider()->get_shipping_recipient();
    }

    return $allow;

}

add_filter( 'epmp_mpme_allow_vendor_token', 'epmp_mpme_allow_vendor_token' );

/**
 * Removing metaboxes for parent orders.
 * This is because the shipping items in the parent orders are not the same as in their children.
 * Except for WCFM, whcih doesn't have parent/children orders.
 */
add_action( 'add_meta_boxes_shop_order', function( $post ){

	$order = wc_get_order( $post->ID );

	if( apply_filters( 'epmp_mpme_remove_parent_orders_meta_boxes', false, $order ) ){
		remove_meta_box( 'epmp_me_invoice', 'shop_order', 'side' );
		remove_meta_box( 'epmp_me_tracking_code', 'shop_order', 'side' );
	}

} );

add_filter( 'epmp_me_use_invoice', function( $use_invoice, $item_id ){

	$vendor_id = wc_get_order_item_meta( $item_id, 'vendor_id' );
	return epmp_mpme_is_invoice_required_for_vendor( $vendor_id );

}, 10, 2 );

add_filter( 'epmp_me_label_actions_group_name', function( $group_name, $order_id ){
	return sprintf( __( 'Labels for order %d', 'epmp-marketplace-melhorenvio' ), $order_id ) . '<br>';
}, 10, 2 );

/**
 * Helper to add logs to WC Logs
 * @param  string $message
 * @param  string $handle
 * @return void
 */
function epmp_mpme_log( $message, $handle = 'epmp-mpme' ){

	$debug = (bool) get_option( 'epmp_mpme_debug', false );

	if( $debug ) {
		wc_get_logger()->add( $handle, $message );
	}

}
/**
 * Helper to add logs to cart calculator
 * @param  string $message
 * @return void
 */
function epmp_mpme_show_messages_in_cart( $message ){
	if( apply_filters( 'epmp_mpme_show_messages_in_cart', false ) && current_user_can( 'administrator' ) ){
		add_action( 'woocommerce_before_shipping_calculator', function() use ( $message ) {
			echo '<p>' . esc_html( json_encode( $message, JSON_PRETTY_PRINT |  JSON_UNESCAPED_UNICODE ) ) . '</p>';
		} );
	}
}
