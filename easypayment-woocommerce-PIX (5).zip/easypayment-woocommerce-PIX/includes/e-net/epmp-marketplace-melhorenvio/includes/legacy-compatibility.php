<?php
defined( 'ABSPATH' ) || exit;

/**
 * [LEGACY v1.2.3] Transition to vendor based service handling
 */
function epmp_mpme_get_vendor_services_legacy( $services, $package, $method ){

	$services = get_user_meta( $package['vendor_id'] ?? 0, '_me_vendor_services', true );

	// This is for compatibility in case not all vendors have come up with their service list.
	if( is_null( $services ) ){
		$services = $method->get_option( 'services', [] );
	}

	return empty( $services ) ? [] : $services;

}

remove_filter( 'epmp_me_available_services', 'epmp_mpme_get_vendor_services', 20, 3 );
add_filter( 'epmp_me_available_services', 'epmp_mpme_get_vendor_services_legacy', 20, 3 );
add_filter( 'default_user_metadata', function( $value, $object_id, $meta_key ){
	return '_me_vendor_services' === $meta_key ? null : $value;
}, 10, 3 );

add_action( 'template_redirect', function(){

	if( defined( 'DOING_AJAX' ) ||
		!epmp_mpme_current_provider()->is_vendor( get_current_user_id() ) ||
		current_user_can( 'administrator' ) ){
		return;
	}

	$services = get_user_meta( get_current_user_id() ?? 0, '_me_vendor_services', true );
	$enabled = wc_string_to_bool( get_user_meta( get_current_user_id() ?? 0, '_me_vendor_enabled', true ) );

	if( $enabled && is_null( $services ) && epmp_mpme_current_provider()->is_vendor_dashboard() ){
		$message = __( 'You haven\'t provided a list of Melhor Envio shipping services (Correios, JadLog etc) that you cover yet, so the list provided by the administrator will be used instead. Please, refer to your panel and select it from the new "Services" field.', 'epmp-marketplace-melhorenvio' );

		if( !wc_has_notice( $message, 'notice' ) ){
			wc_add_notice( $message, 'notice' );
		}

	}

}, 20 );

/**
 * [END LEGACY v1.2.3]
 */

/**
 * [LEGACY v1.5.0] Transition to vendor based service handling
 */
function epmp_mpme_remove_jadlog_if_no_agency_selected( $services, $package ){
	return epmp_mpme_remove_services_if_no_agency_selected( $services, $package );
}

add_filter( 'epmp_me_available_services', 'epmp_mpme_remove_jadlog_if_no_agency_selected', 30, 2 );
/**
 * [END LEGACY v1.5.0]
 */
