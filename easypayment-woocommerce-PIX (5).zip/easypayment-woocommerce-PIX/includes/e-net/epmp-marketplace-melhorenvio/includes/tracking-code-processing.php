<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
/**
 * @author  Luis Eduardo Braschi <http://art-idesenvolvimento.com.br>
 */

/**
 * Hiding meta info from client
 * @param  array $items list of meta items to hide
 * @return array        list of meta items to hide
 */
function epmp_mpme_hide_meta_shipping( $items ){

    $items[] = 'epmp_mpme_tracking_code';
    $items[] = 'epmp_mpme_tracking_url';
    $items[] = 'method_label';
    $items[] = 'vendor_id';
    $items[] = 'vendor_name';
    $items[] = 'seller_id';

    if( defined('EPMP_ME_TESTING') && EPMP_ME_TESTING ){
    	return $items;
    }

    $items[] = '_delivery_time';
    $items[] = '_service_id';
    $items[] = '_company_id';
    $items[] = '_packages';
    $items[] = '_vendor_order_shipping_item_id';
    $items[] = '_invoice_number';
    $items[] = 'package_qty';

    return $items;
}
add_filter( 'woocommerce_hidden_order_itemmeta', 'epmp_mpme_hide_meta_shipping' );

