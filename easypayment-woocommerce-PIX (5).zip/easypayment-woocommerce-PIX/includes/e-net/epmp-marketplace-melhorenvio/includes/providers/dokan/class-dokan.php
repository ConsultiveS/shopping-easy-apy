<?php
use WeDevs\Dokan\Vendor\Vendor;
use function Epmp\ME\functions\get_labels_generation_allowed_statuses;
use function Epmp\ME\functions\is_invoice_required_for_item;
use function Epmp\ME\functions\is_labelling_available_for_item;
use function Epmp\ME\functions\is_melhorenvio_method;
use function Epmp\ME\functions\item_can_bypass_invoice;
use function Epmp\ME\functions\save_product_fields;

/**
* Encapsulates functionalities of Dokan marketplace
*
* @author  Luis Eduardo Braschi <http://art-idesenvolvimento.com.br>
*/

class Epmp_ME_Dokan_Provider extends Epmp_MPME_Abstract_Vendors_Provider implements Epmp_MPME_Shipping_Processor {

	private $me_actions = [];

	public function __construct() {

		if( !class_exists( 'WeDevs_Dokan' ) ) {

			$this->provider_not_found_message = __( 'The plugin "Dokan" could not be found. Please, install and activate it before registering this adapter.', 'epmp-marketplace-melhorenvio' );
			$this->is_active = false;

			add_action( 'admin_notices', [ $this, 'provider_not_found' ] );

		} else {

			add_action( 'woocommerce_order_status_processing', [ $this, 'process_shipping_due' ], 11, 1 );
			add_action( 'woocommerce_order_status_completed', [ $this, 'process_shipping_due' ], 11, 1 );
			add_action( 'epmp_mpme_provider_dokan_loaded', [ $this, 'hooks' ], 11, 1 );
			add_action( 'woocommerce_package_rates',  [ $this, 'remove_dokan_shipping_rate' ], 10, 2 );

			add_action( 'epmp_mpme_add_tracking_code_to_package', [ $this, 'after_adding_tracking_info' ], 10, 4 );

			add_filter( 'dokan_get_seller_amount_from_order_array', [ $this, 'seller_shipping_amount_from_order' ], 10, 3 );

			add_action( 'wp_ajax_mark-item-shipped', [ $this, 'mark_item_shipped' ] );

			// Settings
			add_action( 'dokan_render_settings_content', [ $this, 'get_settings_page' ] );
			add_filter( 'dokan_get_dashboard_settings_nav', [ $this, 'add_settings_nav' ], 20 );
			add_filter( 'dokan_dashboard_settings_heading_title', [ $this, 'get_settings_header' ], 11, 2 );

			// Admin settings
			add_action( 'show_user_profile', [ $this, 'add_admin_vendor_fields' ], 20 );
			add_action( 'edit_user_profile', [ $this, 'add_admin_vendor_fields' ], 20 );

       		add_action( 'personal_options_update', [ $this, 'save_vendor_fields' ] );
	        add_action( 'edit_user_profile_update', [ $this, 'save_vendor_fields' ] );

			add_action( 'wp_ajax_epmp_mpme_dokan_settings', [ $this, 'ajax_settings' ] );

			add_action( 'template_redirect', [ $this, 'save_invoice_number' ] );

			if( !is_admin() ){
				add_action( 'woocommerce_admin_order_actions_end', [ $this, 'add_label_actions' ] );
			} else {
			}
			add_filter( 'woocommerce_admin_order_actions', [ $this, 'remove_label_actions' ], 10, 2 );

			add_action( 'wp_ajax_load-vendor-address', [ $this, 'load_address_from_store_config' ] );

			add_action( 'dokan_product_options_shipping', [ $this, 'add_product_shipping_fields' ] );
			add_action( 'dokan_product_updated', [ $this, 'handle_product_update' ], 10, 2 );

			add_action( 'dokan_dashboard_left_widgets', [ $this, 'show_me_api_info' ] );

			add_action( 'wp_head', [ $this, 'label_actions_css' ] );

			add_action( 'dokan_order_detail_after_order_general_details', [ $this, 'add_order_tracking_fields' ] );

		}

	}

	public function is_vendor( $user_id ){
		return dokan_is_user_seller( $user_id );
	}

	public function is_vendor_dashboard(){
		return wc_post_content_has_shortcode( 'dokan-dashboard' );
	}

	public function get_shipping_recipient(){
		$fee_recipient = dokan_get_option( 'shipping_fee_recipient', 'dokan_selling', 'seller' );
		return $fee_recipient === 'seller' ? 'vendor' : 'admin';
	}

	public function get_vendor_postcode( $vendor_id ){

		$postcode = get_user_meta( $vendor_id, '_me_vendor_postal_code', true );

		if( !$postcode ) {
			// translators: %d: ID of the vendor that doesn't have post code
			$message = sprintf( __( 'Vendor with id %d has no post code.', 'epmp-marketplace-melhorenvio' ), $vendor_id );
			throw new Exception( $message );
		}

		return $postcode;

	}

	public function get_vendor_id_from_product( $id ) {

		$vendor = get_post_field( 'post_author', $id );

		if( !$vendor || !$this->is_vendor( $vendor ) ) {
			// translators: %d: ID of the product that doesn't have a vendor assigned
			$message = sprintf( __( 'Product with id %d has no vendor assigned to it.', 'epmp-marketplace-melhorenvio' ), $id );
			throw new Exception( $message );
		}

		return $vendor;
	}

	public function get_vendor_name( $id ) {

		$vendor = new Vendor( $id );

		$vendor_name = $vendor->get_shop_name();

		if( empty( $vendor_name ) ){
			$vendor_name = get_the_author_meta( 'display_name', $id );
		}

		return $vendor_name;
	}

	public function mark_as_shipped( $order_id, $vendor_id = null, $package_id = null ){

		$shippers = ( array ) get_post_meta( $order_id, 'dokan_shipped', true );
		$vendor_id = !is_null( $vendor_id )?$vendor_id:get_current_user_id();

		if( !in_array( $vendor_id, $shippers ) ) {

			$shippers[] = $vendor_id;
			$shippers = array_unique( array_filter( $shippers ) );
			update_post_meta( $order_id, 'dokan_shipped', $shippers );

		}

		$this->add_mark_as_shipped_note( $order_id, $vendor_id, $package_id );

	}

	private function add_mark_as_shipped_note( $order_id, $vendor_id, $package_id ){

		$order = wc_get_order( $order_id );
		$shippers[] = $vendor_id;
		$vendor_name = $this->get_vendor_name( $vendor_id );

		// translators: %s: Name of the vendor
		$message = sprintf( __( '%s added shipping info.', 'epmp-marketplace-melhorenvio' ), $vendor_name );

		$label_data = wc_get_order_item_meta( $package_id, '_epmp_me_label_data' );

		$tracking_codes = [];

		foreach( $label_data['orders'] as $me_order ){

			$tracking_code = $me_order['tracking_code']->melhorenvio_tracking;
			$tracking_codes[] = $this->get_tracking_code_url( $tracking_code );

		}

		$tracking_code = join( ', ', $tracking_codes );

		ob_start();
		include_once 'views/html-order-shipping-note.php';
		$html = ob_get_clean();

		$order->add_order_note( $html, true );

	}

	/**
	 * Get tracking code url.
	 *
	 * @param  string $tracking_code Tracking code.
	 *
	 * @return string
	 */
	public function get_tracking_code_url( $tracking_code ) {
		$url = sprintf(
			'<a href="https://www.melhorrastreio.com.br/rastreio/%1$s">%1$s</a>',
			$tracking_code
		);

		return $url;
	}

	/**
	 * Distributes the shipping dues accourding to their vendors
	 * @param  int $order_id the id of the WooCommerce order
	 * @return void
	 */
	public function process_shipping_due( $order_id ){

	}

	public function get_order_comission_by_vendor( $order_id, $vendor_id ){
		return 0;
	}

	public function hooks(){

		add_filter( 'dokan_shipping_method', function( $ret ){

			remove_filter( 'woocommerce_package_rates', 'epmp_hide_shipping_methods' );

			return $ret;
		} );

		if( current_user_can( 'dokan_manage_order_note' ) ) {
			add_action( 'wp_ajax_dokan_add_shipping_tracking_info', 'epmp_mpme_save_vendor_tracking_code' );
		}

		add_filter( 'epmp_mpme_cart_shipping_packages', [ $this, 'add_vendor_info_to_package' ], 10 );

		add_filter( 'wc_shipping_simulator_package', [ $this, 'add_vendor_info_to_shipping_simulator_package' ], 9, 2 );

	}

	/**
	 * Adds Art-i's vendor info to the package
	 * @param array $packages
	 */
	public function add_vendor_info_to_package( $packages ){

		$new_packages = [];

		foreach( $packages as $package ){

			$vendor_id = $package['vendor_id'];

			$package['seller_id'] = $vendor_id;
			$package['user'] = [ 'ID' => get_current_user_id() ];

			$new_packages[] = $package;

		}

		return $new_packages;

	}

	public function add_vendor_info_to_shipping_simulator_package( $package, $product ){

		if( is_array( $product ) ){
			$product_id = $product['variation_id'] > 0 ? $product['variation_id'] : $product['product_id'];
			$product = wc_get_product( $product_id );
		}

		$product_id = $product->get_id();

		try {

			$package['seller_id'] = $this->get_vendor_id_from_product( $product_id );

		} catch ( Exception $e ) {

			epmp_mpme_log( $e->getMessage(), 'epmp-mpme-wc-simulador' );

		}

		return $package;
	}

	public function remove_dokan_shipping_rate( $package_rates, $package ){

		$seller_id = $package['seller_id'];

		if( class_exists( 'Dokan_WC_Shipping' )
			&& !Dokan_WC_Shipping::is_shipping_enabled_for_seller( $seller_id )
			&& isset( $package_rates['dokan_product_shipping'] ) ){

			unset( $package_rates['dokan_product_shipping'] );

		}

		return $package_rates;

	}

	public function after_adding_tracking_info( $updated, $order_id, $vendor_id, $package_id ){
		if( !is_admin() ){
			$url = wp_nonce_url( add_query_arg( [ 'order_id' => $order_id ], dokan_get_navigation_url( 'orders' ) ), 'dokan_view_order' );
			wp_safe_redirect( html_entity_decode( $url ) );
			exit();
		}
	}

	/**
	 * Corrects shipping amount in Dokan pro
	 * @param  array $net_amount
	 * @param  WC_Order $order
	 * @param  int|string $seller_id
	 * @return array $net_amount
	 */
	public function seller_shipping_amount_from_order( $net_amount, $order, $seller_id ){

		$commission_recipient = dokan_get_option( 'extra_fee_recipient', 'dokan_general', 'seller' );
		if ( 'seller' == $commission_recipient ) {
			$net_amount['shipping'] = $this->get_order_shipping_amount_for_vendor( $order->get_id(), $seller_id );
		}
		return $net_amount;

	}

	/**
	 * Will add fields to user dashboard in the font-end
	 * @return void
	 */
	public function add_vendor_fields(){
		$vendor_id = dokan_get_current_user_id();
		include_once EPMP_MEDOKAN_DIR . '/views/html-vendor-fields-wrapper.php';
	}

	public function get_settings_page( $query_vars ){

		if ( isset( $query_vars['settings'] ) && $query_vars['settings'] == 'melhorenvio' ) {
			 if ( ! current_user_can( 'dokan_view_store_shipping_menu' ) ) {
				dokan_get_template_part('global/dokan-error', '', [ 'deleted' => false, 'message' => __( 'You have no permission to view this page', 'dokan' ) ] );
			} else {
				$disable_woo_shipping  = get_option( 'woocommerce_ship_to_countries' );

				if ( 'disabled' == $disable_woo_shipping ) {
					dokan_get_template_part('global/dokan-error', '', [ 'deleted' => false, 'message' => __( 'Shipping functionality is currentlly disabled by site owner', 'dokan' ) ] );
				} else {
					$this->add_vendor_fields();
				}
			}
		}

	}

	public function add_settings_nav( $sub_settings ){

		$sub_settings['melhorenvio'] = [
			'title'      => __( 'Melhor Envio', 'epmp-marketplace-melhorenvio' ),
			'icon'       => '<i class="fa fa-thumbs-up"></i>',
			'url'        => dokan_get_navigation_url( 'settings/melhorenvio' ),
			'pos'        => 200,
			'permission' => 'dokan_view_store_shipping_menu'
		];

		return $sub_settings;

	}

	public function get_settings_header( $header, $query_vars ) {
		if ( $query_vars === 'melhorenvio' ) {
			$header = __( 'Melhor Envio', 'epmp-marketplace-melhorenvio' );
		}

		return $header;
	}

	public function add_admin_vendor_fields( $user ){
        if ( !current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        if ( !user_can( $user, 'dokandar' ) ) {
            return;
        }

    	$vendor_id = $user->ID;
    	include_once EPMP_MEDOKAN_DIR . '/views/admin/html-admin-address-fields-wrapper.php';

	}

	/**
	 * Save the corporate info
	 * @param  int|string $vendor_id
	 * @return void
	 */
	public function save_vendor_fields( $vendor_id ){
		epmp_mpme_update_user_meta( $vendor_id );
	}

	public function ajax_settings(){

		if( 'epmp-me-store-form' === $_POST['form_id'] ){
			if ( ! $this->is_vendor( get_current_user_id() ) ) {
				wp_send_json_error( __( 'Are you cheating?', 'epmp-marketplace-melhorenvio' ) );
			}

			if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'epmp_me_store_settings_nonce' ) ) {
				wp_send_json_error( __( 'Are you cheating?', 'epmp-marketplace-melhorenvio' ) );
			}

			$vendor_id = dokan_get_current_user_id();

			$this->save_vendor_fields( $vendor_id );

			$success_msg = __( 'Your information has been saved successfully', 'epmp-marketplace-melhorenvio' );
			$errors = epmp_mpme_validate_vendor_fields();

			$data = apply_filters( 'epmp_me_dokan_ajax_settings_response', [
				'msg' => $success_msg,
				'errors' => $errors,
			] );

			wp_send_json_success( $data );

		}

	}

	public function remove_label_actions( $actions, $order ){

		$is_parent_order = $order->get_meta( 'has_sub_order' );

		foreach( $order->get_shipping_methods() as $shipping_item ){

			$item_id = $shipping_item->get_id();
			// Removing action from the parent order in wp-admin
			if( is_admin() && $is_parent_order ){
				unset(
					$actions['buy_labels_' . $item_id],
					$actions['generate_labels_' . $item_id],
					$actions['print_labels_' . $item_id],
					$actions['mark_shipped_' . $item_id]
				);
			}

		}

		return $actions;
	}

	public function add_label_actions( $order ){

		$labels_generation_allowed_statuses = get_labels_generation_allowed_statuses();

		if(
			!$order->has_status( $labels_generation_allowed_statuses ) ||
			!epmp_mpme_vendor_can_generate_labels( (int) get_current_user_id() )
		){
			return;
		}

		$me_actions = [];

		$vendor_id = dokan_get_current_user_id();

		foreach( $order->get_shipping_methods() as $shipping_item ){

			$item_id = $shipping_item->get_id();

			if(
				!is_melhorenvio_method( $shipping_item->get_method_id() ) ||
				(int) wc_get_order_item_meta( $item_id, 'vendor_id' ) !== (int) $vendor_id ||
				!is_labelling_available_for_item( $item_id )
			){
				continue;
			}

			$label_data = wc_get_order_item_meta( $item_id, '_epmp_me_label_data' );

			if(
				empty( $label_data ) &&
				epmp_mpme_is_invoice_required_for_vendor( $vendor_id ) &&
				is_invoice_required_for_item( $item_id )
			){

				$me_actions['add_invoice_' . $item_id] = [
					'url' => wp_nonce_url(
								add_query_arg(
									[ 'order_id' => dokan_get_prop( $order, 'id' ) ],
									dokan_get_navigation_url( 'orders' )
								),
								'dokan_view_order'
							) . '#epmp-me-order-invoices',
					'name' => __( 'Add invoice number', 'epmp-marketplace-melhorenvio' ),
					'icon' => '<i class="fa fa-file-text">&nbsp;</i>',
					'external' => false,
				];

				if( item_can_bypass_invoice( $item_id ) ){
					$me_actions['buy_labels_' . $item_id] = [
						'url' => wp_nonce_url(
							admin_url(
								'admin-ajax.php?action=buy-labels-for-item&item_id=' . $item_id
							),
							'epmp-me-buy-labels-for-item'
						),
						'name' => __( 'Buy labels non-commercially', 'epmp-melhorenvio' ),
						'icon' => '<i class="fa fa-cart-plus">&nbsp;</i>',
						'external' => false,
					];
				}

				continue;
			}

			if( empty( $label_data ) ){
				$me_actions['buy_labels_' . $item_id] = [
					'url' => wp_nonce_url(
						admin_url(
							'admin-ajax.php?action=buy-labels-for-item&item_id=' . $item_id
						),
						'epmp-me-buy-labels-for-item'
					),
					'name' => __( 'Buy labels', 'epmp-melhorenvio' ),
					'icon' => '<i class="fa fa-cart-plus">&nbsp;</i>',
					'external' => false,
				];
			} elseif(
				( isset( $label_data['preview'] ) && $label_data['preview'] )
				|| isset( $label_data['print_link'], $label_data['print_link']->message)
				) {

				$me_actions['generate_labels_' . $item_id] = [
					'url' => wp_nonce_url(
						admin_url(
							'admin-ajax.php?action=generate-labels-for-item&item_id=' . $item_id
						),
						'epmp-me-generate-labels-for-item'
					),
					'name' => __( 'Generate labels', 'epmp-marketplace-melhorenvio' ),
					'icon' => '<i class="fa fa-check-square">&nbsp;</i>',
					'external' => false,
				];

				foreach( $label_data['orders'] as $key => $me_order ){
					if( isset( $me_order['preview_link']->url ) ){
						$me_actions['preview_labels_' . $key] = [
							'url' => $me_order['preview_link']->url,
							'name' => __( 'Preview labels', 'epmp-melhorenvio' ),
							'icon' => '<i class="fa fa-pencil">&nbsp;</i>',
							'external' => true,
						];
					} elseif( isset( $me_order['error'] ) || isset( $me_order['preview_link']->error ) ){

						$error = $me_order['error'] ?? $me_order['preview_link']->error;

						$me_actions['generate_labels_' . $item_id]['name'] = wp_strip_all_tags( $error );
						$me_actions['generate_labels_' . $item_id]['class'] = ' has-error';

					}
				}

			} elseif( isset( $label_data['preview'], $label_data['print_link'], $label_data['print_link']->url ) ) {

				$me_actions['mark_shipped_' . $item_id ] = [
					'url' => wp_nonce_url(
						admin_url(
							'admin-ajax.php?action=mark-item-shipped&item_id=' . $item_id
						),
						'epmp-me-mark-item-shipped'
					),
					'name' => __( 'Mark as shipped', 'epmp-marketplace-melhorenvio' ),
					'icon' => '<i class="fa fa-truck">&nbsp;</i>',
					'external' => false,
				];

				$me_actions['print_labels_' . $item_id] = [
					'url' => $label_data['print_link']->url,
					'name' => __( 'Print labels', 'epmp-marketplace-melhorenvio' ),
					'icon' => '<i class="fa fa-print">&nbsp;</i>',
					'external' => true,
				];

			}

		}

		echo '<br>';

		foreach( $me_actions as $action ) {
			$external =	isset( $action['external'] ) && $action['external'] ? 'target="_blank" rel="noopener noreferrer"' : '';

			printf(
				'<a class="me-action dokan-btn dokan-btn-sm %s tips" href="%s" data-toggle="tooltip" data-placement="top" title="%s" %s>%s</a> ',
				esc_attr( $action['class'] ?? '' ),
				esc_url( $action['url'] ),
				esc_attr( $action['name'] ),
				$external,
				$action['icon'] ?? ''
			);
		}

	}

	public function label_actions_css(){
		?>
		<style>
			.dokan-btn.me-action {
				background-color: #0550a0 !important;
				color: #f3b331 !important;
			}
			.me-action.has-error i {
				position: relative;
			}
			.me-action.has-error i:after{
			    content: "\f06a";
			    display: block;
			    position: absolute;
			    color:red;
			    left:100%;
			    border-radius: 50%;
			    background-color: #fff;
			}
		</style>
		<?php
	}

	public function mark_item_shipped(){

		if ( !is_admin() ) {
			die;
		}

		if ( !current_user_can( 'dokandar' ) || 'on' != dokan_get_option( 'order_status_change', 'dokan_selling', 'on' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'dokan-lite' ) );
		}

		if ( !check_admin_referer( 'epmp-me-mark-item-shipped' ) ) {
			wp_die( esc_html__( 'You have taken too long. Please go back and retry.', 'dokan-lite' ) );
		}

		$item_id = !empty( $_GET['item_id'] ) ? (int) $_GET['item_id'] : 0;

		if ( !$item_id ) {
			die;
		}

		$shipping_item = new \WC_Order_Item_Shipping( $item_id );

		$vendor_id = (int) $shipping_item->get_meta( 'vendor_id' );

		if ( $vendor_id !== (int) dokan_get_current_user_id() ) {
			wp_die( esc_html__( 'You do not have permission to change this order', 'dokan-lite' ) );
		}

		$order = wc_get_order( $shipping_item->get_order_id() );
		$order->update_status( 'shipped-out' );

		$this->mark_as_shipped( $order->get_id(), $vendor_id, $item_id );

		wp_safe_redirect( wp_get_referer() );
		die;

	}

	public function save_invoice_number(){

		if( wp_verify_nonce( $_POST['invoice-number-field'] ?? '', 'add-invoice-number' ) ){
			Epmp\ME\Admin\Orders::save();
		}

	}

	public function load_address_from_store_config(){

		if(
			// !is_user_wcmp_vendor( get_current_user_id() ) ||
			!wp_verify_nonce( $_GET['load-vendor-address-field'], 'load-vendor-address' )
		){
			wp_send_json_error();
			wp_die();
		}

		$vendor_id = get_current_user_id();
		$vendor = new Vendor( $vendor_id );

		$address = $vendor->get_address();

		$address = apply_filters(
			'epmp_mpme_load_vendor_address',
			[
				'_me_vendor_name'          => $vendor->get_name(),
				'_me_vendor_phone'         => $vendor->get_phone(),
				'_me_vendor_email'         => $vendor->get_email(),
				'_me_vendor_address'       => $address['street_1'],
				'_me_vendor_complement'    => $address['street_2'],
				'_me_vendor_city'          => $address['city'],
				'_me_vendor_state'         => $address['state'],
				'_me_vendor_postal_code'   => $address['zip'],
			],
			$vendor_id
		);

		wp_send_json_success( $address );
		wp_die();
	}

	public function add_product_shipping_fields(){
		global $post;
		$additional_time = get_post_meta( $post->ID, '_epmp_me_additional_time', true );
		include_once 'views/html-product-shipping-option-field.php';
	}

	public function handle_product_update( $post_id, $post_data ){
		save_product_fields( $post_id, $post_data );
	}

	public function show_me_api_info(){
		$this->load_me_user_info_template( get_current_user_id(), EPMP_MEDOKAN_DIR . '/views/html-me-api-info.php' );
	}

	public function add_order_tracking_fields( $order ){

		$invoice_items = array_filter( $order->get_shipping_methods(), function( $item ){

			$vendor_id = dokan_get_current_user_id();
			$item_id = $item->get_id();

			return epmp_mpme_is_invoice_required_for_vendor( $vendor_id );

		} );

		if( count( $invoice_items ) ){
			include_once EPMP_MEDOKAN_DIR . '/views/html-order-details.php';
		}
	}

}
