<h2 class="dokan-text-left">
    <?php _e( 'Melhor Envio Token', 'epmp-marketplace-melhorenvio' );?>
</h2>
<?php do_action( 'epmp_mpme_before_dokan_token_field', $vendor_token ); ?>
<div class="dokan-form-group">
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label" for="_vendor_token"><?php _e( 'Token', 'epmp-marketplace-melhorenvio' ); ?></label>
        <div class="dokan-w7 dokan-text-left">
            <textarea id="_vendor_token" name="_me_vendor_token" class="dokan-form-control input-md" type="text"><?php echo esc_attr( $vendor_token ); ?></textarea>
        </div>
    </div>
</div>
<?php do_action( 'epmp_mpme_after_dokan_token_field', $vendor_token ); ?>
