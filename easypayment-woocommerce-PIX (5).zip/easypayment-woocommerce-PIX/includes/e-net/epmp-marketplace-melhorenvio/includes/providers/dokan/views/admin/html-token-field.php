<tr>
	<th>
	    <?php _e( 'Melhor Envio Token', 'epmp-marketplace-melhorenvio' );?>
	</th>
</tr>
<tr>
	<th>
		<label for="_vendor_token">
			<?php _e( 'Token', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
		<textarea id="_vendor_token" name="_me_vendor_token" type="text"><?php echo esc_attr( $vendor_token ); ?></textarea>
	</td>
</tr>
