;jQuery(function($){

	if( !$('#epmp-me-store-form').length ){
		return;
	}

	$('#_me_vendor_shipping_zones, #_me_vendor_services, .agency-list').select2({
	    width: '100%'
	});

	/**
	 * Agency list cache in the format:
	 *
	 * {
	 * 		state_abbr: {
	 * 			company_id1: [ agency1, agency2, ... ],
	 * 			company_id2: [ agency1, agency2, ... ]
	 * 		}
	 * 	}
	 *
	 * @type {Object}
	 */
	var agencies = {};

	function load_agency_list(){

		var state = $('#_me_vendor_state').val();

		if( '0' == state  ){
			return;
		}

		if( !agencies.hasOwnProperty(state) ){

			$('.dokan-dashboard-content').block({
				message: null,
				overlayCSS: {
					background: '#fff',
					opacity: 0.6
				}
			});

			$.get(
				woocommerce_params.ajax_url,
				{
					'state':state,
					'companies':epmp_mpme.all_companies,
					'action':'epmp_me_get_agencies'
				},
				function( response ){
					if( response.success ){
						agencies[state] = response.data[state];
						epmp_mpme.populate_select( agencies[state] );
					}

					$('.dokan-dashboard-content').unblock();

				}
			);
		} else {
			epmp_mpme.populate_select( agencies[state] );
		}

	}

	epmp_mpme.show_agency_lists = function ( company_ids ){

		$( '.company-container,.no-agencies' ).hide();
		$( '.company-container' ).children('select').attr('disabled', 'disabled');

		var $company_containers = $(company_ids.map( company_id => '#_me_company_container_' + company_id ).join(','));

		$company_containers.show();
		$company_containers.children('select').removeAttr('disabled');

		if( !$('.company-container:visible').length ){
			$('.no-agencies').show();
		}

	}

	$('#_me_vendor_services').on( 'select2:unselect', function( e ){
		epmp_mpme.show_agency_lists(epmp_mpme.get_selected_companies())
	});

	$('#_me_vendor_services').on( 'select2:select', function( e ){

		var selected_value = parseInt(e.params.data.id);

		if( $('#_me_vendor_services [value="0"]').is(':selected') ){

			if( 1 < $('#_me_vendor_services :selected').length ) {
				$('#_me_vendor_services').val( [0] ).trigger('change');
			}

			if( 0 !== selected_value ) {
				$('#_me_vendor_services').val( [selected_value] ).trigger('change');
			}

		}

		load_agency_list();

	} );

	epmp_mpme.show_cnae_field();

	$( 'form' ).on('change', '#_me_vendor_services, [name="_me_vendor_document_type"]', function(){
		epmp_mpme.show_cnae_field();
	});
	$( 'form' ).on('change', '#_me_vendor_state', function(){
		epmp_mpme.force_select_update = true;
		load_agency_list();
	});

	// Form submition.
	$('#epmp-me-store-form').submit(function(e){
		e.preventDefault();

		var self = $( this ),
			form_data = self.serialize() + '&action=epmp_mpme_dokan_settings&form_id=epmp-me-store-form';

		self.find('.ajax_prev').append('<span class="dokan-loading"> </span>');
		$.post(dokan.ajaxurl, form_data, function(resp) {

			self.find('span.dokan-loading').remove();
			$('html,body').animate({scrollTop:100});

		   if ( resp.success ) {
				// Harcoded Customization for template-settings function
				$('.dokan-ajax-response').html( $('<div/>', {
					'class': 'dokan-alert dokan-alert-success',
					'html': '<p>' + resp.data.msg + '</p>',
				}) );

				$.each( resp.data.errors, function( i, el ){
					$('.dokan-ajax-response').append( $('<div/>', {
						'class': 'dokan-alert dokan-alert-danger',
						'html': '<p>' + el + '</p>',
					}) );
				} );

				$('.dokan-ajax-response').append(resp.data.progress);

			} else {
				$('.dokan-ajax-response').html( $('<div/>', {
					'class': 'dokan-alert dokan-alert-danger',
					'html': '<p>' + resp.data + '</p>'
				}) );
			}
		});
	});

	$('#_me_vendor_fixed_cost').maskDecimals();

});

jQuery(function ($) {

	var me_required_fields = $('[id^="_me_vendor"][required]');
	var $me_vendor_enabled = $('#_me_vendor_enabled');

	$me_vendor_enabled.change( is_me_enabled );
	is_me_enabled();

	function is_me_enabled() {
		if( $me_vendor_enabled.is(':checked') ){
			me_required_fields.attr('required', 'required');
		} else {
			me_required_fields.removeAttr('required');
		}
	}

	$( '#load-vendor-address' ).click( function(){

		$('.dokan-dashboard-content').block({
			message: null,
			overlayCSS: {
				background: '#fff',
				opacity: 0.6
			}
		});

		var nonce = $( '#load-vendor-address-field' ).val();
		$.get( woocommerce_params.ajax_url, {
			'load-vendor-address-field': nonce,
			'action': 'load-vendor-address'
		}, function( response ){
			if( response.success ){
				var fields = response.data;
				for( var field_id in response.data ){
					var value = fields[field_id];
					$( '#' + field_id ).val( value );
				}
			}
			$('.dokan-dashboard-content').unblock();
		} );
	} );
});
