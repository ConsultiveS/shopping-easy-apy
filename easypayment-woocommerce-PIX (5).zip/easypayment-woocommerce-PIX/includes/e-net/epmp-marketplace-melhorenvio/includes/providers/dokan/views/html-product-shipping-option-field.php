<div class="dokan-form-group dokan-shipping-dimention-options">
    <label class="form-label"><?php _e( 'Additional time', 'epmp-marketplace-melhorenvio' ); ?></label>
    <input name="_epmp_me_additional_time" value="<?php echo esc_attr( $additional_time );?>" class="dokan-form-control" type="number" size="30">
	<div class="dokan-clearfix"></div>
</div>
