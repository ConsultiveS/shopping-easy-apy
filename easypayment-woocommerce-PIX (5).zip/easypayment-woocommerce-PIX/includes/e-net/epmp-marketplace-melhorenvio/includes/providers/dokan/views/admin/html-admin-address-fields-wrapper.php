<?php
$enabled = $this->is_me_enabled( $vendor_id );
?>
<h2><?php esc_html_e( 'Melhor Envio', 'epmp-marketplace-melhorenvio' ); ?></h2>
<table id="epmp-melhorenvio" class="form-table">
	<tr>
		<th>
			<label for="_me_vendor_enabled">
				<?php esc_html_e( 'Enable Melhor Envio', 'epmp-marketplace-melhorenvio' ); ?>
			</label>
		</th>
		<td>
			<input type="checkbox" id="_me_vendor_enabled" name="_me_vendor_enabled" value="yes"<?php checked( $enabled, 'yes' ); ?>>
		</td>
	</tr>
<?php
	$this->render_vendor_token_field_html( $vendor_id, EPMP_MEDOKAN_DIR . '/views/admin/html-token-field.php' );
	$this->render_vendor_address_fields_html( $vendor_id, EPMP_MEDOKAN_DIR . '/views/admin/html-address-fields.php' );
?>
</table>
