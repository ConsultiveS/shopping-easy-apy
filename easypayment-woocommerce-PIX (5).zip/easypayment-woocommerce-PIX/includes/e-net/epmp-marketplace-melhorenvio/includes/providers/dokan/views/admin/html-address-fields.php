<?php
$vendor_shipping_zones = get_user_meta( $vendor_id, '_me_vendor_shipping_zones', true );
$vendor_shipping_zones = !empty( $vendor_shipping_zones ) ? $vendor_shipping_zones : [];
use const Epmp\ME\Constants\{ DOCUMENT_TYPE_CPF, DOCUMENT_TYPE_CNPJ };
use function Epmp\ME\Functions\{ get_companies_with_agencies, get_company_name_by_id };

$vendor_config = $this->get_vendor_config( $vendor_id );

$vendor_fixed_cost = $vendor_config->get_fixed_cost();
$vendor_percent_cost = $vendor_config->get_percent_cost();
?>
<tr>
	<th>
		<h3><?php esc_html_e( 'Shipping settings', 'epmp-marketplace-melhorenvio' ); ?></h3>
	</th>
</tr>
<tr>
	<th>
		<label for="_me_vendor_shipping_zones">
			<?php esc_html_e( 'Shipping zones', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
		<select class="wc-enhanced-select" id="_me_vendor_shipping_zones" name="_me_vendor_shipping_zones[]" multiple="multiple" style="width: 25em;">
			<?php foreach( epmp_mpme_get_available_shipping_zones() as $zone_id => $zone ):?>
				<option <?php echo in_array( $zone_id, $vendor_shipping_zones ) ? 'selected':''; ?> value=<?php echo esc_attr( $zone_id );?>>
					<?php echo esc_html( $zone ); ?>
				</option>
			<?php endforeach;?>
		</select>
	</td>
</tr>
<tr>
	<th>
		<label for="_me_vendor_services">
			<?php esc_html_e( 'Services', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
		<select class="wc-enhanced-select" id="_me_vendor_services" name="_me_vendor_services[]" multiple="multiple" style="width: 25em;">
			<?php foreach( $services as $service_id => $service ):?>
				<option <?php echo in_array( $service_id, $vendor_services ) ? 'selected':''; ?> value=<?php echo esc_attr( $service_id );?>>
					<?php echo esc_html( $service ); ?>
				</option>
			<?php endforeach;?>
		</select>
	</td>
</tr>
<tr>
	<th>
		<label for="_me_vendor_fixed_cost">
			<?php esc_html_e( 'Additional fixed cost', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
		R$
		<input id="_me_vendor_fixed_cost" value="<?php echo esc_attr( $vendor_fixed_cost ); ?>" name="_me_vendor_fixed_cost" type="number" min=0 lang="pt-br">
	</td>
</tr>
<tr>
	<th>
		<label for="_me_vendor_percent_cost">
			<?php esc_html_e( 'Additional percent cost', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
		<input id="_me_vendor_percent_cost" value="<?php echo esc_attr( $vendor_percent_cost ); ?>" name="_me_vendor_percent_cost" type="number" min=0 lang="pt-br"> %
	</td>
</tr>
<tr>
	<th>
		<label for="_me_vendor_additional_time">
			<?php esc_html_e( 'Additional time', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
		<input id="_me_vendor_additional_time" value="<?php echo esc_attr( $vendor_additional_time ); ?>" name="_me_vendor_additional_time" type="number" min=0>
	</td>
</tr>
<tr>
	<th>
		<label for="_me_vendor_receiver_only">
			<?php esc_html_e( 'Receiver only', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
		<input type="checkbox" name="_me_vendor_receiver_only" value="yes"<?php checked( $receiver_only, 'yes' ); ?>>
	</td>
</tr>

<tr>
	<th>
		<label for="_me_vendor_receipt">
			<?php esc_html_e( 'Receipt', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
		<input type="checkbox" name="_me_vendor_receipt" value="yes"<?php checked( $receipt, 'yes' ); ?>>
	</td>
</tr>
<tr>
	<th>
		<h3><?php esc_html_e( 'Melhor Envio Address', 'epmp-marketplace-melhorenvio' ); ?></h3>
	</th>
</tr>
<tr>
	<th>
		<label for="_me_vendor_name">
			<?php esc_html_e( 'Name', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
		<input id="_me_vendor_name" value="<?php echo esc_attr( $vendor_name ); ?>" name="_me_vendor_name" type="text">
	</td>
</tr>
<tr>
	<th>
		<label for="_me_vendor_phone">
			<?php esc_html_e( 'Phone', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
		<input id="_me_vendor_phone" value="<?php echo esc_attr( $vendor_phone ); ?>" name="_me_vendor_phone" type="text">
	</td>
</tr>
	<th>
		<label for="_me_vendor_email">
			<?php esc_html_e( 'Email', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
		<input id="_me_vendor_email" value="<?php echo esc_attr( $vendor_email ); ?>" name="_me_vendor_email" type="text">
	</td>
</tr>
<tr>
	<th>
    	<label for="_me_vendor_document_type">
    		<?php esc_html_e( 'Document type', 'epmp-marketplace-melhorenvio' ); ?>
    	</label>
	</th>
	<td>
		<select name="_me_vendor_document_type">
			<option value="<?php echo esc_attr( DOCUMENT_TYPE_CPF ); ?>" <?php selected( (string) DOCUMENT_TYPE_CPF, $vendor_document_type );?> >
				<?php esc_html_e( 'Natural person', 'epmp-marketplace-melhorenvio' ) ?>
			</option>
			<option value="<?php echo esc_attr( DOCUMENT_TYPE_CNPJ ); ?>" <?php selected( (string) DOCUMENT_TYPE_CNPJ, $vendor_document_type );?> >
				<?php esc_html_e( 'Legal person', 'epmp-marketplace-melhorenvio' ) ?>
			</option>
		</select>
	</td>
</tr>

<tr>
	<th>
		<label for="_me_vendor_document">
			<?php esc_html_e( 'Document', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
        <input id="_me_vendor_document" value="<?php echo esc_attr( $vendor_document ); ?>" name="_me_vendor_document" type="text">
	</td>
</tr>

<tr class="_me_vendor_cnae_wrapper" <?php echo $show_cnae_field ? '' : 'style="display:none;"' ;?>>
	<th>
		<label for="_me_vendor_cnae">
			<?php esc_html_e( 'CNAE', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
        <input id="_me_vendor_cnae" value="<?php echo esc_attr( $vendor_cnae ); ?>" name="_me_vendor_cnae" type="text">
	</td>
</tr>

<tr>
	<th>
		<label for="_me_vendor_address">
			<?php esc_html_e( 'Address', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
        <input id="_me_vendor_address" value="<?php echo esc_attr( $vendor_address ); ?>" name="_me_vendor_address" type="text">
	</td>
</tr>

<tr>
	<th>
		<label for="_me_vendor_complement">
			<?php esc_html_e( 'Complement', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
        <input id="_me_vendor_complement" value="<?php echo esc_attr( $vendor_complement ); ?>" name="_me_vendor_complement" type="text">
	</td>
</tr>

<tr>
	<th>
		<label for="_me_vendor_number">
			<?php esc_html_e( 'Number', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
        <input id="_me_vendor_number" value="<?php echo esc_attr( $vendor_number ); ?>" name="_me_vendor_number" type="text">
	</td>
</tr>

<tr>
	<th>
		<label for="_me_vendor_neighborhood">
			<?php esc_html_e( 'Neighborhood', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
        <input id="_me_vendor_neighborhood" value="<?php echo esc_attr( $vendor_district ); ?>" name="_me_vendor_neighborhood" type="text">
	</td>
</tr>

<tr>
	<th>
		<label for="_me_vendor_city">
			<?php esc_html_e( 'City', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
        <input id="_me_vendor_city" value="<?php echo esc_attr( $vendor_city ); ?>" name="_me_vendor_city" type="text">
	</td>
</tr>

<tr>

<tr>
	<th>
		<label for="_me_vendor_state">
			<?php esc_html_e( 'State', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
		<select id="_me_vendor_state" name="_me_vendor_state">
		    <option><?php esc_html_e( 'Choose state', 'epmp-marketplace-melhorenvio' );?></option>
		    <?php foreach( WC()->countries->get_states( 'BR' ) as $abbr => $state ):?>
		        <option <?php echo ( $abbr === $vendor_state ) ? 'selected' : ''; ?> value=<?php echo esc_attr( $abbr );?>>
		            <?php echo esc_html( $state ); ?>
		        </option>
		    <?php endforeach;?>
		</select>
	</td>
</tr>

<tr>
	<th>
		<label for="_me_vendor_postal_code">
			<?php esc_html_e( 'Postcode', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
        <input id="_me_vendor_postal_code" value="<?php echo esc_attr( $vendor_postal_code ); ?>" name="_me_vendor_postal_code" type="text">
	</td>
</tr>

<tr>
	<th>
		<label for="_me_vendor_agency">
			<?php esc_html_e( 'Agency', 'epmp-marketplace-melhorenvio' ); ?>
		</label>
	</th>
	<td>
    	<div class="no-agencies <?php echo count( $agency_lists ) ? 'dokan-hide' : ''; ?>">
            <p>
            	<?php esc_html_e( 'No agency required', 'epmp-marketplace-melhorenvio' );?>
        	</p>
    	</div>

        <?php foreach( get_companies_with_agencies() as $company_id ):

        	$agency_list = $agency_lists[$company_id] ?? [];
        	$no_agency = empty( $agency_list );
        	$company_name = get_company_name_by_id( $company_id );

        ?>
        <div id="_me_company_container_<?php echo esc_attr( $company_id );?>" class="company-container" <?php echo $no_agency ? 'style="display:none;"' : '' ;?>">
        	<div><?php echo esc_html( $company_name );?></div>
            <select id="_me_company_<?php echo esc_attr( $company_id );?>" name="_me_vendor_agencies[<?php echo esc_attr( $company_id );?>]" <?php echo $no_agency ? 'disabled' : '' ;?> class="wc-enhanced-select agency-list">
                <?php foreach( $agency_list as $agency ):?>
                    <option <?php echo ( isset( $agency['selected'] ) && $agency['selected'] ) ? 'selected' : ''; ?> value=<?php echo esc_attr( $agency['id'] );?>>
                        <?php echo esc_html( $agency['description'] ); ?>
                    </option>
                <?php endforeach;?>
            </select>
            <p>
            	<?php echo esc_html(
            		sprintf(
            			__( 'Select the %s agency from which you will send your packages.', 'epmp-marketplace-melhorenvio' ),
            			$company_name
            		)
            	);?>
            </p>
        </div>
	    <?php endforeach;?>


	</td>
</tr>
