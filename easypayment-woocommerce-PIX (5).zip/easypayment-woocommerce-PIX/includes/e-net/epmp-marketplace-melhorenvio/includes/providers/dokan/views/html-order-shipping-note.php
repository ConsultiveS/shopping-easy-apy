<?php echo $message; ?>
<?php if(!empty($tracking_url)):?>
<p><strong><?php _e('Tracking URL', 'epmp-marketplace-melhorenvio')?></strong>: <?php echo $tracking_url?></p>
<?php endif; ?>
<p><strong><?php _e('Tracking code', 'epmp-marketplace-melhorenvio')?></strong>: <?php echo $tracking_code?></p>
