<?php
$enabled = $this->is_me_enabled( get_current_user_id() );
?>
<form method="post" id="epmp-me-store-form"  action="" class="dokan-form-horizontal">
    <?php wp_nonce_field( 'epmp_me_store_settings_nonce' ); ?>
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label" for="_me_vendor_enabled">
        	<?php esc_html_e( 'Enabled', 'epmp-marketplace-melhorenvio' ); ?>
        </label>
        <div class="dokan-w5 dokan-text-left">
            <div class="checkbox">
                <label>
                    <input type="checkbox" id="_me_vendor_enabled" name="_me_vendor_enabled" value="yes"<?php checked( $enabled, 'yes' ); ?>>
                </label>
                <p class="dokan-page-help">
	                <?php esc_html_e( 'Check if you want to use Melhor Envio shipping.', 'epmp-marketplace-melhorenvio' ); ?>
	            </p>
            </div>
        </div>
    </div>
    <?php
        $this->render_vendor_token_field_html( $vendor_id, EPMP_MEDOKAN_DIR . '/views/html-token-field.php' );
        $this->render_vendor_address_fields_html( $vendor_id, EPMP_MEDOKAN_DIR . '/views/html-address-fields.php' );
    ?>
    <div class="dokan-form-group">
        <div class="dokan-w4 ajax_prev dokan-text-left" style="margin-left:24%;">
            <input type="submit" name="dokan_update_store_settings" class="dokan-btn dokan-btn-danger dokan-btn-theme" value="<?php esc_attr_e( 'Update Settings', 'epmp-marketplace-melhorenvio' ); ?>">
        </div>
    </div>
</form>
