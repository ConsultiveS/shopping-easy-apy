<div class="dashboard-widget">
    <div class="dokan-panel-body">
    	<p><?php echo $formatted_balance;?></p>
    	<?php if( $formatted_token_expiry ):?>
    	<p><?php echo $formatted_token_expiry;?></p>
    	<?php endif; ?>
    </div>
</div>
