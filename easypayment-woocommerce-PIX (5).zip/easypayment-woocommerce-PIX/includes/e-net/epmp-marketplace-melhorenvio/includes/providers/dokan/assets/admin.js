jQuery(function( $ ){

	var agencies = {}; // little cache

	function load_agency_list(){

		var state = $('#_me_vendor_state').val();

		if( '0' == state  ){
			return;
		}

		if( !agencies.hasOwnProperty(state) ){
			$.get(
				woocommerce_admin.ajax_url,
				{
					'state':state,
					'companies':epmp_mpme.all_companies,
					'action':'epmp_me_get_agencies'
				},
				function( response ){
					if( response.success ){
						agencies[state] = response.data[state];
						epmp_mpme.populate_select( agencies[state] );
					}
				}
			);
		} else {
			epmp_mpme.populate_select( agencies[state] );
		}

	}

	epmp_mpme.show_agency_lists = function ( company_ids ){

		$( '.company-container,.no-agencies' ).hide();
		$( '.company-container' ).children('select').attr('disabled', 'disabled');

		var $company_containers = $(company_ids.map( company_id => '#_me_company_container_' + company_id ).join(','));

		$company_containers.show();
		$company_containers.children('select').removeAttr('disabled');

		if( !$('.company-container:visible').length ){
			$('.no-agencies').show();
		}

	}

	$('#_me_vendor_services').on( 'select2:unselect', function( e ){
		epmp_mpme.show_agency_lists(epmp_mpme.get_selected_companies())
	});

	$('#_me_vendor_services').on( 'select2:select', function( e ){

		var selected_value = parseInt(e.params.data.id);

		if( $('#_me_vendor_services [value="0"]').is(':selected') ){

			if( 1 < $('#_me_vendor_services :selected').length ) {
				$('#_me_vendor_services').val( [0] ).trigger('change');
			}

			if( 0 !== selected_value ) {
				$('#_me_vendor_services').val( [selected_value] ).trigger('change');
			}

		}

		load_agency_list();

	} );

	$( 'form' ).on('change', '#_me_vendor_services, [name="_me_vendor_document_type"]', function(){
		epmp_mpme.show_cnae_field('._me_vendor_cnae_wrapper');
	});
	$( 'form' ).on('change', '#_me_vendor_state', function(){
		epmp_mpme.force_select_update = true;
		load_agency_list();
	});

	$('#_me_vendor_fixed_cost').maskDecimals();

});
