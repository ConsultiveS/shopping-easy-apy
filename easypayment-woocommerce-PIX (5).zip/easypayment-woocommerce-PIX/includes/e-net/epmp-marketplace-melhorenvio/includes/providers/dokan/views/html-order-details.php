<div style="width:100%">
    <div class="dokan-panel dokan-panel-default">
        <div class="dokan-panel-heading"><strong><?php esc_html_e( 'Invoice numbers', 'epmp-marketplace-melhorenvio' ); ?></strong></div>
    	<div class="dokan-panel-body" id="epmp-me-order-invoices">
    		<form method="post">
        		<?php foreach( $invoice_items as $item ): ?>
        			<p>
        				<label for="_invoice_number_<?php echo esc_attr( $item->get_id() );?>">
        					<?php $label = apply_filters( 'epmp_me_invoice_field_label', $item->get_method_title(), $item ); ?>
        					<?php echo esc_html( $label );?>
        				</label>
        				<input type="text" id="_invoice_number_<?php echo esc_attr( $item->get_id() );?>" name="_invoice_number[<?php echo esc_attr( $item->get_id() );?>]" value="<?php echo esc_attr( wc_get_order_item_meta( $item->get_id(), '_invoice_number', true ) ); ?>" autocomplete="off">
        			</p>
        		<?php endforeach;?>
                <!-- <input type="hidden" name="security" value="<?php echo esc_attr( wp_create_nonce( 'add-order-note' ) ); ?>"> -->
                <?php wp_nonce_field( 'add-invoice-number', 'invoice-number-field' );?>
                <input type="hidden" name="action" value="epmp_mpme_add_invoice_number">
                <input type="submit" class="dokan-btn dokan-btn-success dokan-btn-sm" value="<?php esc_attr_e( 'Save', 'epmp-marketplace-melhorenvio' )?>">
    		</form>
    	</div>
	</div>
</div>
<style>
	#epmp-me-order-invoices:target {
		box-shadow: 0 0 13px 5px rgba(0, 0, 0, 0.2);
	}
</style>
