<?php

use function Epmp\ME\functions\get_service_to_company_map;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

define( 'EPMP_MEDOKAN_DIR', dirname( __FILE__ ));

function epmp_mpme_dokan_scripts(){
    if( epmp_mpme_current_provider()->is_vendor_dashboard() ){
        $package_url = plugin_dir_url( __FILE__ );
        $suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
        $dashboard_scripts = $package_url . 'assets/dashboard' . $suffix . '.js';

        wp_enqueue_script( 'selectWoo' );
        wp_enqueue_style( 'select2' );
        wp_enqueue_script( 'epmp-mpme-dashboard' );
        wp_enqueue_script( 'jquery-mask-decimals' );

        wp_enqueue_script( 'epmp-me-dokan-dashboard', $dashboard_scripts, ['jquery', 'wp-util','epmp-mpme-dashboard'], '1.4.4' );
    }

}
add_action('wp_enqueue_scripts', 'epmp_mpme_dokan_scripts');


add_action( 'admin_enqueue_scripts', function(){

	if( 'user-edit' === get_current_screen()->id ){
        $package_url = plugin_dir_url( __FILE__ );
        $admin_script = $package_url . 'assets/admin.js';

        wp_enqueue_script( 'epmp-mpme-dashboard' );
        wp_enqueue_script( 'jquery-mask-decimals' );

        wp_enqueue_script( 'epmp-me-dokan-admin', $admin_script, ['jquery'], '1.4.4' );

	}

}, 10 );

include_once 'dokan-functions.php';
include_once 'class-dokan.php';
