<?php
$vendor_shipping_zones = get_user_meta( $vendor_id, '_me_vendor_shipping_zones', true );
$vendor_shipping_zones = !empty( $vendor_shipping_zones ) ? $vendor_shipping_zones : [];
use const Epmp\ME\Constants\{ DOCUMENT_TYPE_CPF, DOCUMENT_TYPE_CNPJ };
use function Epmp\ME\functions\{ get_companies_with_agencies, get_company_name_by_id };

$vendor_config = $this->get_vendor_config( $vendor_id );

?>
<h2 class="dokan-text-left">
    <?php esc_html_e( 'Shipping settings', 'epmp-marketplace-melhorenvio' );?>
</h2>
<div class="dokan-form-group">
	<div class="dokan-form-group">
	    <label class="dokan-w3 dokan-control-label" for="_me_vendor_shipping_zones">
	    	<?php esc_html_e( 'Shipping zones', 'epmp-marketplace-melhorenvio' ); ?>
	    </label>
		<?php do_action( 'epmp_mpme_before_dokan_shipping_fields', $vendor_id ); ?>
	    <div class="dokan-w5 dokan-text-left">
	        <select class="dokan-form-control" id="_me_vendor_shipping_zones" name="_me_vendor_shipping_zones[]" multiple="multiple">
	            <?php foreach( epmp_mpme_get_available_shipping_zones() as $zone_id => $zone ):?>
	                <option <?php echo in_array( $zone_id, $vendor_shipping_zones ) ? 'selected':''; ?> value=<?php echo esc_attr( $zone_id );?>>
	                    <?php echo esc_html( $zone ); ?>
	                </option>
	            <?php endforeach;?>
	        </select>
	        <p class="dokan-page-help">
	        	<?php esc_html_e( 'Select the shipping zones you want to cover. Leave it blank to use all available shipping zones.', 'epmp-marketplace-melhorenvio' );?>
	        </p>
	    </div>
	</div>
	<div class="dokan-form-group">
	    <label class="dokan-w3 dokan-control-label" for="_me_vendor_services">
	    	<?php esc_html_e( 'Services', 'epmp-marketplace-melhorenvio' ); ?>
	    </label>
	    <div class="dokan-w5 dokan-text-left">
	        <select class="dokan-form-control" id="_me_vendor_services" name="_me_vendor_services[]" multiple="multiple">
	            <?php foreach( $services as $service_id => $service ):?>
	                <option <?php echo in_array( $service_id, $vendor_services ) ? 'selected':''; ?> value=<?php echo esc_attr( $service_id );?>>
	                    <?php echo esc_html( $service ); ?>
	                </option>
	            <?php endforeach;?>
	        </select>
	        <p class="dokan-page-help">
	        	<?php esc_html_e( 'Select the services you want to use for shipping.', 'epmp-marketplace-melhorenvio' );?>
	        </p>
	    </div>
	</div>

	<div class="dokan-form-group">
	    <label class="dokan-w3 dokan-control-label" for="_me_vendor_fixed_cost">
	    	<?php esc_html_e( 'Additional fixed cost', 'epmp-marketplace-melhorenvio' ); ?>
	    </label>
	    <div class="dokan-w5 dokan-text-left">
	    	<div class="dokan-input-group">
	    		<span class="dokan-input-group-addon">R$</span>
	        	<input id="_me_vendor_fixed_cost" value="<?php echo esc_attr( $vendor_config->get_fixed_cost() ); ?>" name="_me_vendor_fixed_cost" autocomplete="off" class="dokan-form-control" type="number" min=0 lang="pt-br">
	        </div>
	        <p class="dokan-page-help">
	        	<?php esc_html_e( 'Cost to be added to the final shipping rate.', 'epmp-marketplace-melhorenvio' );?>
	        </p>
	    </div>
	</div>
	<div class="dokan-form-group">
	    <label class="dokan-w3 dokan-control-label" for="_me_vendor_percent_cost">
	    	<?php esc_html_e( 'Additional percent cost', 'epmp-marketplace-melhorenvio' ); ?>
	    </label>
	    <div class="dokan-w5 dokan-text-left">
	    	<div class="dokan-input-group">
	        	<input id="_me_vendor_percent_cost" value="<?php echo esc_attr( $vendor_config->get_percent_cost() ); ?>" name="_me_vendor_percent_cost" autocomplete="off" class="dokan-form-control" type="number" min=0 lang="pt-br">
	        	<span class="dokan-input-group-addon">%</span>
	    	</div>
	        <p class="dokan-page-help">
	        	<?php esc_html_e( 'Percentage to be added to the final shipping rate.', 'epmp-marketplace-melhorenvio' );?>
	        </p>
	    </div>
	</div>
	<div class="dokan-form-group">
	    <label class="dokan-w3 dokan-control-label" for="_me_vendor_additional_time">
	    	<?php esc_html_e( 'Additional time', 'epmp-marketplace-melhorenvio' ); ?>
	    </label>
	    <div class="dokan-w5 dokan-text-left">
	        <input id="_me_vendor_additional_time" value="<?php echo esc_attr( $vendor_additional_time ); ?>" name="_me_vendor_additional_time" autocomplete="off" class="dokan-form-control" type="number" min=0>
	        <p class="dokan-page-help">
	        	<?php esc_html_e( 'Time in days to add to the delivery estimate.', 'epmp-marketplace-melhorenvio' );?>
	        </p>
	    </div>
	</div>
	<div class="dokan-form-group">
	    <label class="dokan-w3 dokan-control-label" for="_me_vendor_receiver_only">
	    	<?php esc_html_e( 'Receiver only', 'epmp-marketplace-melhorenvio' ); ?>
	    </label>
	    <div class="dokan-w5 dokan-text-left">
	        <div class="checkbox">
	            <label>
	                <input type="checkbox" name="_me_vendor_receiver_only" value="yes"<?php checked( $receiver_only, 'yes' ); ?>>
	                <p class="dokan-page-help">
		                <?php esc_html_e( 'Check if you want the parcel to be delivered to the receiver.', 'epmp-marketplace-melhorenvio' ); ?>
		            </p>
	            </label>
	        </div>
	    </div>
	</div>
	<div class="dokan-form-group">
	    <label class="dokan-w3 dokan-control-label" for="_me_vendor_receipt">
	    	<?php esc_html_e( 'Receipt', 'epmp-marketplace-melhorenvio' ); ?>
	    </label>
	    <div class="dokan-w5 dokan-text-left">
	        <div class="checkbox">
	            <label>
	                <input type="checkbox" name="_me_vendor_receipt" value="yes"<?php checked( $receipt, 'yes' ); ?>>
                    <p class="dokan-page-help">
                    	<?php esc_html_e( 'Check if you want to be notified when the parcel is delivered.', 'epmp-marketplace-melhorenvio' ); ?>
                	</p>
	            </label>
	        </div>
	    </div>
	</div>
	<div class="dokan-form-group">
	    <label class="dokan-w3 dokan-control-label" for="_me_vendor_receipt">
	    	<?php esc_html_e( 'Collect', 'epmp-marketplace-melhorenvio' ); ?>
	    </label>
	    <div class="dokan-w5 dokan-text-left">
	        <div class="checkbox">
	            <label>
	                <input type="checkbox" name="_me_vendor_collect" value="yes"<?php checked( $collect, 'yes' ); ?>>
                    <p class="dokan-page-help">
                    	<?php esc_html_e( 'Check if you want your packages to be collected.', 'epmp-marketplace-melhorenvio' ); ?>
                	</p>
	            </label>
	        </div>
	    </div>
	</div>
	<?php do_action( 'epmp_mpme_after_dokan_shipping_fields', $vendor_id ); ?>
</div>
<h2 class="dokan-text-left">
    <?php esc_html_e( 'Melhor Envio Address', 'epmp-marketplace-melhorenvio' );?>
</h2>
<div class="dokan-form-group">
	<div class="dokan-form-group">
		<div class="dokan-w5 dokan-text-left">
			<p>
				<button type="button" id="load-vendor-address" class="alt">
					<?php esc_html_e( 'Load address from config', 'epmp-marketplace-melhorenvio' ); ?>
				</button>
				<?php wp_nonce_field( 'load-vendor-address', 'load-vendor-address-field' ); ?>
			</p>
		</div>
	</div>
	<?php do_action( 'epmp_mpme_before_dokan_address_fields', $vendor_id ); ?>
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label" for="_me_vendor_name">
        	<?php esc_html_e( 'Name', 'epmp-marketplace-melhorenvio' ); ?> <span class="required">*</span>
        </label>
        <div class="dokan-w5 dokan-text-left">
            <input id="_me_vendor_name" value="<?php echo esc_attr( $vendor_name ); ?>" name="_me_vendor_name" autocomplete="off" class="dokan-form-control" type="text" required>
        </div>
    </div>
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label" for="_me_vendor_phone">
        	<?php esc_html_e( 'Phone', 'epmp-marketplace-melhorenvio' ); ?>  <span class="required">*</span>
        </label>
        <div class="dokan-w5 dokan-text-left">
            <input id="_me_vendor_phone" value="<?php echo esc_attr( $vendor_phone ); ?>" name="_me_vendor_phone" autocomplete="off" class="dokan-form-control" type="text" required>
        </div>
    </div>
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label" for="_me_vendor_email">
        	<?php esc_html_e( 'Email', 'epmp-marketplace-melhorenvio' ); ?> <span class="required">*</span>
        </label>
        <div class="dokan-w5 dokan-text-left">
            <input id="_me_vendor_email" value="<?php echo esc_attr( $vendor_email ); ?>" name="_me_vendor_email" autocomplete="off" class="dokan-form-control" type="email" required>
        </div>
    </div>
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label" for="_me_vendor_document">
        	<?php esc_html_e( 'Document type', 'epmp-marketplace-melhorenvio' ); ?> <span class="required">*</span>
        </label>
        <div class="dokan-w6">
        	<div class="dokan-w6 dokan-text-left">
        	    <input id="_me_vendor_document_type_<?php echo esc_attr( DOCUMENT_TYPE_CPF );?>" value="<?php echo esc_attr( DOCUMENT_TYPE_CPF ); ?>" name="_me_vendor_document_type" type="radio" required <?php checked( (string) DOCUMENT_TYPE_CPF, $vendor_document_type );?>> <label for="_me_vendor_document_type_<?php echo esc_attr( DOCUMENT_TYPE_CPF );?>"><?php esc_html_e( 'Natural person', 'epmp-marketplace-melhorenvio' ) ?></label>
        	</div>
        	<div class="dokan-w6 dokan-text-left">
        	    <input id="_me_vendor_document_type_<?php echo esc_attr( DOCUMENT_TYPE_CNPJ );?>" value="<?php echo esc_attr( DOCUMENT_TYPE_CNPJ ); ?>" name="_me_vendor_document_type" type="radio" required <?php checked( (string) DOCUMENT_TYPE_CNPJ, $vendor_document_type );?>> <label for="_me_vendor_document_type_<?php echo esc_attr( DOCUMENT_TYPE_CNPJ );?>"><?php esc_html_e( 'Legal person', 'epmp-marketplace-melhorenvio' ) ?></label>
        	</div>
	        <p class="dokan-page-help dokan-text-left">
	        	<?php esc_html_e( 'Type of document of the sender', 'epmp-marketplace-melhorenvio' );?>
	        </p>
        </div>
    </div>
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label" for="_me_vendor_document">
        	<?php esc_html_e( 'Document', 'epmp-marketplace-melhorenvio' ); ?> <span class="required">*</span>
        </label>
        <div class="dokan-w5 dokan-text-left">
            <input id="_me_vendor_document" value="<?php echo esc_attr( $vendor_document ); ?>" name="_me_vendor_document" autocomplete="off" class="dokan-form-control" type="text" required>
	        <p class="dokan-page-help">
	        	<?php esc_html_e( 'Document of the sender; CPF if natural, CNPJ if legal', 'epmp-marketplace-melhorenvio' );?>
	        </p>
        </div>
    </div>
    <div id="cnae-container" class="dokan-form-group <?php echo $show_cnae_field ? '' : 'dokan-hide' ;?>">
        <label class="dokan-w3 dokan-control-label" for="_me_vendor_cnae">
        	<?php esc_html_e( 'CNAE', 'epmp-marketplace-melhorenvio' ); ?>
        </label>
        <div class="dokan-w5 dokan-text-left">
            <input id="_me_vendor_cnae" value="<?php echo esc_attr( $vendor_cnae ); ?>" name="_me_vendor_cnae" autocomplete="off" class="dokan-form-control" type="text" <?php echo $show_cnae_field ? 'required' : '' ;?>>
	        <p class="dokan-page-help">
	        	<?php esc_html_e( 'The CNAE code is used by LATAM when you send using CNPJ.', 'epmp-marketplace-melhorenvio' );?>
	        </p>
        </div>
    </div>
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label" for="_me_vendor_state_register">
        	<?php esc_html_e( 'State Register', 'epmp-marketplace-melhorenvio' ); ?>
        </label>
        <div class="dokan-w5 dokan-text-left">
            <input id="_me_vendor_state_register" value="<?php echo esc_attr( $vendor_state_register ); ?>" name="_me_vendor_state_register" autocomplete="off" class="dokan-form-control" type="text">
	        <p class="dokan-page-help">
	        	<?php esc_html_e( '', 'epmp-marketplace-melhorenvio' );?>
	        </p>
        </div>
    </div>
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label" for="_me_vendor_address">
        	<?php esc_html_e( 'Address', 'epmp-marketplace-melhorenvio' ); ?> <span class="required">*</span>
        </label>
        <div class="dokan-w5 dokan-text-left">
            <input id="_me_vendor_address" value="<?php echo esc_attr( $vendor_address ); ?>" name="_me_vendor_address" autocomplete="off" class="dokan-form-control" type="text" required>
        </div>
    </div>
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label" for="_me_vendor_complement">
        	<?php esc_html_e( 'Complement', 'epmp-marketplace-melhorenvio' ); ?>
        </label>
        <div class="dokan-w5 dokan-text-left">
            <input id="_me_vendor_complement" value="<?php echo esc_attr( $vendor_complement ); ?>" name="_me_vendor_complement" autocomplete="off" class="dokan-form-control" type="text">
        </div>
    </div>
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label" for="_me_vendor_number">
        	<?php esc_html_e( 'Number', 'epmp-marketplace-melhorenvio' ); ?> <span class="required">*</span>
        </label>
        <div class="dokan-w5 dokan-text-left">
            <input id="_me_vendor_number" value="<?php echo esc_attr( $vendor_number ); ?>" name="_me_vendor_number" autocomplete="off" class="dokan-form-control" type="text" required>
        </div>
    </div>
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label" for="_me_vendor_district">
        	<?php esc_html_e( 'Neighborhood', 'epmp-marketplace-melhorenvio' ); ?> <span class="required">*</span>
        </label>
        <div class="dokan-w5 dokan-text-left">
            <input id="_me_vendor_district" value="<?php echo esc_attr( $vendor_district ); ?>" name="_me_vendor_district" autocomplete="off" class="dokan-form-control" type="text" required>
        </div>
    </div>
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label" for="_me_vendor_city">
        	<?php esc_html_e( 'City', 'epmp-marketplace-melhorenvio' ); ?> <span class="required">*</span>
        </label>
        <div class="dokan-w5 dokan-text-left">
            <input id="_me_vendor_city" value="<?php echo esc_attr( $vendor_city ); ?>" name="_me_vendor_city" autocomplete="off" class="dokan-form-control" type="text" required>
        </div>
    </div>
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label" for="_me_vendor_city">
        	<?php esc_html_e( 'State', 'epmp-marketplace-melhorenvio' ); ?> <span class="required">*</span>
        </label>
        <div class="dokan-w7 dokan-text-left">
            <select id="_me_vendor_state" name="_me_vendor_state" required>
                <option value="0"><?php esc_html_e( 'Choose state', 'epmp-marketplace-melhorenvio' );?></option>
                <?php foreach( WC()->countries->get_states( 'BR' ) as $abbr => $state ):?>
                    <option <?php echo ( $abbr === $vendor_state ) ? 'selected' : ''; ?> value=<?php echo esc_attr( $abbr );?>>
                        <?php echo esc_html( $state ); ?>
                    </option>
                <?php endforeach;?>
            </select>
        </div>
    </div>
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label" for="vendor_postal_code">
        	<?php esc_html_e( 'Postcode', 'epmp-marketplace-melhorenvio' ); ?> <span class="required">*</span>
        </label>
        <div class="dokan-w5 dokan-text-left">
            <input id="_me_vendor_postal_code" value="<?php echo esc_attr( $vendor_postal_code ); ?>" name="_me_vendor_postal_code" autocomplete="off" class="dokan-form-control" type="text" required>
        </div>
    </div>
    <div class="dokan-form-group">
        <label class="dokan-w3 dokan-control-label">
        	<?php esc_html_e( 'Agencies', 'epmp-marketplace-melhorenvio' ); ?>
        </label>

        <div class="dokan-w7 dokan-text-left">
        	<div class="no-agencies <?php echo count( $agency_lists ) ? 'dokan-hide' : ''; ?>">
	            <p class="dokan-page-help">
	            	<?php esc_html_e( 'No agency required', 'epmp-marketplace-melhorenvio' );?>
	        	</p>
        	</div>

	        <?php foreach( get_companies_with_agencies() as $company_id ):?>
	        <?php
	        	$agency_list = $agency_lists[$company_id] ?? [];
	        	$no_agency = empty( $agency_list );
	        	$company_name = get_company_name_by_id( $company_id );
	        ?>
	        <div id="_me_company_container_<?php echo esc_attr( $company_id );?>" class="company-container dokan-text-left <?php echo $no_agency ? 'dokan-hide' : '' ;?>">
	        	<div><?php echo esc_html( $company_name );?></div>
	            <select id="_me_company_<?php echo esc_attr( $company_id );?>" name="_me_vendor_agencies[<?php echo esc_attr( $company_id );?>]" <?php echo $no_agency ? 'disabled' : '' ;?> class="agency-list">
	                <?php foreach( $agency_list as $agency ):?>
	                    <option <?php echo ( isset( $agency['selected'] ) && $agency['selected'] ) ? 'selected' : ''; ?> value=<?php echo esc_attr( $agency['id'] );?>>
	                        <?php echo esc_html( $agency['description'] ); ?>
	                    </option>
	                <?php endforeach;?>
	            </select>
	            <p class="dokan-page-help">
	            	<?php echo esc_html(
	            		sprintf(
	            			__( 'Select the %s agency from which you will send your packages.', 'epmp-marketplace-melhorenvio' ),
	            			$company_name
	            		)
	            	);?>
	            </p>
	        </div>
		    <?php endforeach;?>
        </div>
    </div>
	<?php do_action( 'epmp_mpme_after_dokan_address_fields', $vendor_id ); ?>
</div>
