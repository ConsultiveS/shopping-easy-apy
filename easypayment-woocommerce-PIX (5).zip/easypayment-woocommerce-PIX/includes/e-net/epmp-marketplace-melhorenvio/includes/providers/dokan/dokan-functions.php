<?php

use function Epmp\ME\functions\render_label_buttons;

if ( ! defined( 'ABSPATH' ) ) {
exit; // Exit if accessed directly.
}

function epmp_mpme_dokan_order_statuses_class( $class, $status ){

    if( 'shipped-out' === $status || 'wc-shipped-out' === $status ){
        $class = 'info';
    }

    return $class;

}

add_filter( 'dokan_get_order_status_class', 'epmp_mpme_dokan_order_statuses_class', 10, 2 );

function epmp_mpme_dokan_order_statuses_translated( $translation, $status ){

    if( 'shipped-out' === $status || 'wc-shipped-out' === $status ){
        $translation = __('Order shipped', 'epmp-marketplace-melhorenvio');
    }

    return $translation;

}

add_filter( 'dokan_get_order_status_translated', 'epmp_mpme_dokan_order_statuses_translated', 10, 2 );

add_action( 'wp_head', function(){
    ?>
    <style>
        .me-action {
            background-color: #0550a0;
            color:#f3b331;
            margin-top: 3px;
        }
        .me-action:hover {
        	color:#fff !important;
        }
    </style>
    <?php
});

add_filter( 'woocommerce_admin_order_actions', function( $actions, $order ){

	if ( in_array( dokan_get_prop( $order, 'status' ), array( 'shipped-out', 'pending', 'on-hold', 'processing' ) ) ) {
	    $actions['complete'] = array(
	        'url' => wp_nonce_url( admin_url( 'admin-ajax.php?action=dokan-mark-order-complete&order_id=' . dokan_get_prop( $order, 'id' ) ), 'dokan-mark-order-complete' ),
	        'name' => __( 'Complete', 'dokan-lite' ),
	        'action' => "complete",
	        'icon' => '<i class="fa fa-check">&nbsp;</i>'
	    );
	}

	return $actions;

}, 9, 2 );

/**
 * Removing parent order actions.
 * @param  array $actions
 * @param  \WC_Order $order
 * @return array
 */
function epmp_mpme_wcmp_render_label_buttons( $actions, $order ){

	if( !get_post_meta( $order->get_id(), 'has_sub_order', true ) ){
		$actions = render_label_buttons( $actions, $order );
	}

	return $actions;

}

add_filter( 'woocommerce_admin_order_actions', 'epmp_mpme_wcmp_render_label_buttons', 10, 2 );

add_action( 'epmp_mpme_init', function(){
	remove_filter( 'woocommerce_admin_order_actions', 'Epmp\ME\functions\render_label_buttons', 10, 2 );
} );

add_filter( 'epmp_mpme_remove_parent_orders_meta_boxes', function( $remove, $order ){

	if( $order->get_meta( 'has_sub_order', true ) ){
		return true;
	}

	return $remove;

}, 10, 2 );
