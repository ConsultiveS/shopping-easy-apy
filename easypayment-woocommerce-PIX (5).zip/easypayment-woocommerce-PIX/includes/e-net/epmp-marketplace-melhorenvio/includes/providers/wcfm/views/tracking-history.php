<h2><?php esc_html_e( 'Other shipping methods (packages not sent by Correios)', 'epmp-mewcfm' );?></h2>
<table class="woocommerce-table shop_table shop_table_responsive">
    <?php foreach( $packages as $package ): ?>
    <?php
        $item_id = $package->get_id();
        $tracking_code = $package->get_meta( 'correios_tracking_code' );
        $tracking_url = $package->get_meta( 'correios_tracking_url' );
        $order_id = $order->get_id();
    ?>
    <tr>
        <th>
            <?php echo esc_html( $tracking_code ); ?>
        </th>
        <td>
            <a href="<?php echo esc_attr( $tracking_url ); ?>" class="button">
                <?php esc_html_e( 'Query tracking info', 'epmp-mewcfm' );?>
            </a>
            <?php if( apply_filters( 'wcfm_is_allow_mark_as_recived', true ) ):?>
            <a href="#" class="button">
                <?php _e( 'Mark as delivered', 'epmp-mewcfm' ); ?>
            </a>
            <?php endif;?>
        </td>
    </tr>
    <?php endforeach;?>
</table>
