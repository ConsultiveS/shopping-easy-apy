<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'EPMP_MEWCFM_PREFIX', 'epmp_mewcfm_' );
define( 'EPMP_MEWCFM_SLUG', 'epmp-mewcfm' );
define( 'EPMP_MEWCFM_BASENAME', plugin_basename( __FILE__ ) );
define( 'EPMP_MEWCFM_DIR', dirname( __FILE__ ) );
define( 'EPMP_MEWCFM_JS', plugin_dir_url( __FILE__ ) . 'assets/js' );

function epmp_mewcfm_wcmp_scripts(){
	if( wc_post_content_has_shortcode( 'wc_frontend_manager' ) ){

		global $WCFM_Query;

		$endpoint = $WCFM_Query->get_current_endpoint();

		$package_url = EPMP_MEWCFM_JS;
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		$ver_suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? time() : '';

		$dashboard_deps = [ 'jquery', 'wp-util', 'wcfm_core_js' ];

		$current_vendor = apply_filters( 'wcfm_current_vendor_id', get_current_user_id() );

		if( !function_exists('get_plugin_data') ){
			require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		}

		$plugin_data = get_plugin_data( EPMP_MPME_PLUGIN );
		$plugin_version = $plugin_data['Version'] . $ver_suffix;

		switch( $endpoint ){
			case 'wcfm-orders':
				$dashboard_orders = $package_url . '/dashboard-orders' . $suffix . '.js';
				wp_enqueue_script(
					'epmp-mewcfm-dashboard-orders',
					$dashboard_orders,
					$dashboard_deps,
					$plugin_version
				);
				break;
			case 'wcfm-vendors-manage':
			case 'wcfm-settings':
				if(
					wcfm_is_vendor( $current_vendor ) ||
					epmp_mpme_can_user_manage_me()
				){
					$dashboard_settings = $package_url . '/dashboard-settings' . $suffix . '.js';
					wp_enqueue_script( 'jquery-mask-decimals' );
					wp_enqueue_script(
						'epmp-mewcfm-dashboard-settings',
						$dashboard_settings,
						$dashboard_deps,
						$plugin_version
					);

        			wp_enqueue_script( 'epmp-mpme-dashboard' );

				}

				break;
		}


	}
}
add_action('wp_enqueue_scripts', 'epmp_mewcfm_wcmp_scripts');

include_once EPMP_MEWCFM_DIR . '/includes/functions.php';
include_once EPMP_MEWCFM_DIR . '/includes/class-wcfm.php';
