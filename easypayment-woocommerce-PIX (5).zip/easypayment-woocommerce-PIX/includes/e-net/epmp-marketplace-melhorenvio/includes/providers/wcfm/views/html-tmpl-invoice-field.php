<script type="text/html" id="tmpl-invoice_frm_template">

    <div id="wcfm_invoice_form_{{data.item_id}}" class="wcfm-collapse-content wcfm_popup_wrapper" style="display: inline-block;">
        <div style="margin-bottom: 15px;">
            <h2 style="float: none;"><?php _e('Invoice number', 'epmp-marketplace-melhorenvio'); ?></h2>
        </div>

        <p class="wcfm_tracking_code shipment_tracking_input wcfm_popup_label">
            <strong><?php _e('Invoice number', 'epmp-marketplace-melhorenvio'); ?></strong>
        </p>

        <label class="screen-reader-text" for="wcfm_tracking_code_{{data.item_id}}">
            <?php _e('Invoice number', 'epmp-marketplace-melhorenvio'); ?>
        </label>

        <input type="text" id="_invoice_number_{{data.item_id}}" name="_invoice_number[{{data.item_id}}]" class="wcfm-text shipment_tracking_input wcfm_popup_input" >

    </div>

</script>
<script type="text/html" id="tmpl-invoice_submit_button">
    <?php wp_nonce_field( 'add-invoice-number', 'invoice-number-field' ); ?>
    <div class="wcfm-message"></div>
    <input type="submit" id="wcfm_tracking_button" name="wcfm_tracking_button" class="wcfm_submit_button wcfm_popup_button" value="<?php _e('Submit', 'epmp-marketplace-melhorenvio'); ?>">
</script>
