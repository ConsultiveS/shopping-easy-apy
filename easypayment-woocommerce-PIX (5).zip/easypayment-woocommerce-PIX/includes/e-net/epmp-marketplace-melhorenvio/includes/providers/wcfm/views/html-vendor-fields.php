<?php

use function Epmp\ME\functions\{ get_companies_with_agencies, get_company_name_by_id };
use const \Epmp\ME\Constants\{ DOCUMENT_TYPE_CPF, DOCUMENT_TYPE_CNPJ };

global $WCFM, $WCFM_Query;

$endpoint = $WCFM_Query->get_current_endpoint();

$vendor_config = $this->get_vendor_config( $vendor_id );

$vendor_token = get_user_meta( $vendor_id, '_me_vendor_token', true );

$vendor_shipping_zones = get_user_meta( $vendor_id, '_me_vendor_shipping_zones', true );

$field_specs = epmp_mpme_wcfm_get_vendor_field_specs();

$shipping_fields = [];
$address_fields = [];

$enable_me_field = [
	'id' => '_me_vendor_enabled',
	'name' => '_me_vendor_enabled',
	'label' => $field_specs['vendor_enabled']['label'],
	'type' => 'checkbox',
	'dfvalue' => $enabled,
	'value' => 'yes',
	'class' => 'wcfm-checkbox',
	'label_class' => 'wcfm_title checkbox_title',
	'desc_class' => 'wcfm_page_options_desc',
	'desc' => __( 'Check if you want to use Melhor Envio shipping.', 'epmp-marketplace-melhorenvio' ),
];

if( apply_filters( 'epmp_mpme_allow_vendor_token', true ) ){

	$token_field = [
		'id' => '_me_vendor_token',
		'name' => '_me_vendor_token',
		'label' => $field_specs['vendor_token']['label'],
		'type' => 'textarea',
		'value' => $vendor_token,
		'class' => 'wcfm-textarea wcfm_ele',
		'label_class' => 'wcfm_title wcfm_ele',
	];

}

$shipping_fields['vendor_shipping_zones'] = [
	'id' => '_me_vendor_shipping_zones',
	'name' => '_me_vendor_shipping_zones',
	'label' => $field_specs['vendor_shipping_zones']['label'],
	'type' => 'select',
	'value' => $vendor_shipping_zones,
	'class' => 'wcfm-select wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
	'options' => epmp_mpme_get_available_shipping_zones(),
	'desc_class' => 'wcfm_page_options_desc',
	'desc' => __( 'Select the shipping zones you want to cover. Leave it blank to use all available shipping zones.', 'epmp-marketplace-melhorenvio' ),
	'attributes' => [ 'multiple' => 'multiple' ],

];

$shipping_fields['vendor_services'] = [
	'id' => '_me_vendor_services',
	'name' => '_me_vendor_services',
	'label' => $field_specs['vendor_services']['label'],
	'type' => 'select',
	'value' => $vendor_services,
	'class' => 'wcfm-select wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
	'options' => $services,
	'desc_class' => 'wcfm_page_options_desc',
	'desc' => __( 'Select the services you want to use for shipping.', 'epmp-marketplace-melhorenvio' ),
	'attributes' => [ 'multiple' => 'multiple' ],

];

$shipping_fields['vendor_fixed_cost'] = [
	'id' => '_me_vendor_fixed_cost',
	'name' => '_me_vendor_fixed_cost',
	'label' => $field_specs['vendor_fixed_cost']['label'],
	'type' => 'text',
	'value' => $vendor_config->get_fixed_cost(),
	'class' => 'wcfm-text wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
	'desc_class' => 'wcfm_page_options_desc',
	'desc' => __( 'Cost to be added to the final shipping rate.', 'epmp-marketplace-melhorenvio' ),
	'attributes' => [
		'min' 		=> 0,
		'inputmode' => 'numeric',
	]
];
$shipping_fields['vendor_percent_cost'] = [
	'id' => '_me_vendor_percent_cost',
	'name' => '_me_vendor_percent_cost',
	'label' => $field_specs['vendor_percent_cost']['label'],
	'type' => 'number',
	'value' => $vendor_config->get_percent_cost(),
	'class' => 'wcfm-text wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
	'desc_class' => 'wcfm_page_options_desc',
	'desc' => __( 'Percentage to be added to the final shipping rate.', 'epmp-marketplace-melhorenvio' ),
	'attributes' => [
		'min' => 0,
		// 'step' => '0.1',
		'lang' => 'pt-br',
	]
];

$shipping_fields['vendor_additional_time'] = [
	'id' => '_me_vendor_additional_time',
	'name' => '_me_vendor_additional_time',
	'label' => $field_specs['vendor_additional_time']['label'],
	'type' => 'number',
	'value' => $vendor_additional_time,
	'class' => 'wcfm-text wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
	'desc_class' => 'wcfm_page_options_desc',
	'desc' => __( 'Number of days to add to the delivery time.', 'epmp-marketplace-melhorenvio' ),
];

$shipping_fields['vendor_receiver_only'] = [
	'id' => '_me_vendor_receiver_only',
	'name' => '_me_vendor_receiver_only',
	'label' => $field_specs['vendor_receiver_only']['label'],
	'type' => 'checkbox',
	'dfvalue' => $receiver_only,
	'value' => 'yes',
	'class' => 'wcfm-checkbox',
	'label_class' => 'wcfm_title checkbox_title',
	'desc_class' => 'wcfm_page_options_desc',
	'desc' => __( 'Check if you want the parcel to be delivered to the receiver.', 'epmp-marketplace-melhorenvio' ),
];

$shipping_fields['vendor_receipt'] = [
	'id' => '_me_vendor_receipt',
	'name' => '_me_vendor_receipt',
	'label' => $field_specs['vendor_receipt']['label'],
	'type' => 'checkbox',
	'dfvalue' => $receipt,
	'value' => 'yes',
	'class' => 'wcfm-checkbox',
	'label_class' => 'wcfm_title checkbox_title',
	'desc_class' => 'wcfm_page_options_desc',
	'desc' => __( 'Check if you want to be notified when the parcel is delivered.', 'epmp-marketplace-melhorenvio' ),
];

$shipping_fields['vendor_collect'] = [
	'id' => '_me_vendor_collect',
	'name' => '_me_vendor_collect',
	'label' => $field_specs['vendor_collect']['label'],
	'type' => 'checkbox',
	'dfvalue' => $collect,
	'value' => 'yes',
	'class' => 'wcfm-checkbox',
	'label_class' => 'wcfm_title checkbox_title',
	'desc_class' => 'wcfm_page_options_desc',
	'desc' => __( 'Check if you want your packages to be collected.', 'epmp-marketplace-melhorenvio' ),
];

$address_fields['vendor_name'] = [
	'id' => '_me_vendor_name',
	'name' => '_me_vendor_name',
	'label' => $field_specs['vendor_name']['label'] . ' <span class="required">*</span>',
	'type' => 'text',
	'value' => $vendor_name,
	'class' => 'wcfm-text wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',

];

$address_fields['vendor_phone'] = [
	'id' => '_me_vendor_phone',
	'name' => '_me_vendor_phone',
	'label' => $field_specs['vendor_phone']['label'] . ' <span class="required">*</span>',
	'type' => 'text',
	'value' => $vendor_phone,
	'class' => 'wcfm-text wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
];

$address_fields['vendor_email'] = [
	'id' => '_me_vendor_email',
	'name' => '_me_vendor_email',
	'label' => $field_specs['vendor_email']['label'] . ' <span class="required">*</span>',
	'type' => 'text',
	'value' => $vendor_email,
	'class' => 'wcfm-text wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
];

$address_fields['vendor_document_type'] = [
	'id' => '_me_vendor_document_type',
	'name' => '_me_vendor_document_type',
	'label' => $field_specs['vendor_document_type']['label'],
	'type' => 'radio',
	'value' => $vendor_document_type,
	'dfvalue' => 0, // hack to overcome the poor 'value' evaluation
	'class' => 'wcfm-select wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
	'options' => [
		DOCUMENT_TYPE_CPF  => __( 'Natural person', 'epmp-marketplace-melhorenvio' ),
		DOCUMENT_TYPE_CNPJ => __( 'Legal person', 'epmp-marketplace-melhorenvio' ),
	],
	'desc_class' => 'wcfm_page_options_desc radio-desc',
	'desc' => __( 'Type of document of the sender', 'epmp-marketplace-melhorenvio' ),

];

$address_fields['vendor_document'] = [
	'id' => '_me_vendor_document',
	'name' => '_me_vendor_document',
	'label' => $field_specs['vendor_document']['label'] . ' <span class="required">*</span>',
	'type' => 'text',
	'value' => $vendor_document,
	'class' => 'wcfm-text wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele'
];

$address_fields['vendor_cnae'] = [
	'id' => '_me_vendor_cnae',
	'name' => '_me_vendor_cnae',
	'label' => $field_specs['vendor_cnae']['label'],
	'type' => 'text',
	'value' => $vendor_cnae,
	'class' => 'wcfm-text wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
	'desc_class' => 'wcfm_page_options_desc',
	'desc' => __( 'The CNAE code is used by LATAM when you send using CNPJ.', 'epmp-marketplace-melhorenvio' ),
];

add_action( 'before_field_wrapper__me_vendor_cnae', function() use ( $show_cnae_field ){
	?>
	<div class="_me_vendor_cnae_wrapper" <?php echo $show_cnae_field ? '' : 'style="display:none;"';?>>
	<?php
} );
// Typo not mine.
add_action( 'afet_field_wrapper__me_vendor_cnae', function(){
	?>
	</div>
	<?php
} );

$address_fields['vendor_state_register'] = [
	'id' => '_me_vendor_state_register',
	'name' => '_me_vendor_state_register',
	'label' => $field_specs['vendor_state_register']['label'],
	'type' => 'text',
	'value' => $vendor_state_register,
	'class' => 'wcfm-text wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele'
];

$address_fields['vendor_address'] = [
	'id' => '_me_vendor_address',
	'name' => '_me_vendor_address',
	'label' => $field_specs['vendor_address']['label'] . ' <span class="required">*</span>',
	'type' => 'text',
	'value' => $vendor_address,
	'class' => 'wcfm-text wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
];

$address_fields['vendor_complement'] = [
	'id' => '_me_vendor_complement',
	'name' => '_me_vendor_complement',
	'label' => $field_specs['vendor_complement']['label'],
	'type' => 'text',
	'value' => $vendor_complement,
	'class' => 'wcfm-text wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
];

$address_fields['vendor_number'] = [
	'id' => '_me_vendor_number',
	'name' => '_me_vendor_number',
	'label' => $field_specs['vendor_number']['label'] . ' <span class="required">*</span>',
	'type' => 'text',
	'value' => $vendor_number,
	'class' => 'wcfm-text wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
];

$address_fields['vendor_district'] = [
	'id' => '_me_vendor_district',
	'name' => '_me_vendor_district',
	'label' => $field_specs['vendor_district']['label'] . ' <span class="required">*</span>',
	'type' => 'text',
	'value' => $vendor_district,
	'class' => 'wcfm-text wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
];

$address_fields['vendor_city'] = [
	'id' => '_me_vendor_city',
	'name' => '_me_vendor_city',
	'label' => $field_specs['vendor_city']['label'] . ' <span class="required">*</span>',
	'type' => 'text',
	'value' => $vendor_city,
	'class' => 'wcfm-text wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
];

$address_fields['vendor_state'] = [
	'id' => '_me_vendor_state',
	'name' => '_me_vendor_state',
	'label' => $field_specs['vendor_state']['label'] . ' <span class="required">*</span>',
	'type' => 'select',
	'options' => WC()->countries->get_states( 'BR' ),
	'value' => $vendor_state,
	'class' => 'wcfm-select wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
];

$address_fields['vendor_postal_code'] = [
	'id' => '_me_vendor_postal_code',
	'name' => '_me_vendor_postal_code',
	'label' => $field_specs['vendor_postal_code']['label'] . ' <span class="required">*</span>',
	'type' => 'text',
	'value' => $vendor_postal_code,
	'class' => 'wcfm-text wcfm_ele',
	'label_class' => 'wcfm_title wcfm_ele',
];

?>
<div class="page_collapsible" id="wcfm_settings_form_melhor_envio_head">
	<label class="wcfmfa fa-truck"></label>
	<?php _e('Melhor Envio', 'epmp-marketplace-melhorenvio'); ?><span></span>
</div>
<div class="wcfm-container">
	<div id="wcfm_settings_form_melhor_envio_expander" class="wcfm-content melhor_envio_address_wrap">
		<?php if( 'wcfm-vendors-manage'  === $endpoint ): ?>
		<form id="wcfm_vendor_manage_form_epmp_melhor_envio">
		<?php endif;?>
		<div class="wcfm_clearfix"></div>
		<div class="wcfm_vendor_settings_heading"><h2><?php _e( 'Melhor Envio', 'epmp-marketplace-melhorenvio' ); ?></h2></div>
		<div class="wcfm_clearfix"></div>
		<div class="store_address">
			<?php $WCFM->wcfm_fields->wcfm_generate_form_field( apply_filters( 'epmp_mpme_wcfm_enable_me_field', [$enable_me_field] ) );?>
		</div>
		<div class="wcfm_clearfix"></div>
		<div class="wcfm_vendor_settings_heading"><h2><?php _e( 'Melhor Envio Token', 'epmp-marketplace-melhorenvio' ); ?></h2></div>
		<div class="wcfm_clearfix"></div>
		<div class="store_address">
			<?php $WCFM->wcfm_fields->wcfm_generate_form_field( apply_filters( 'epmp_mpme_wcfm_token_field', [$token_field] ) );?>
		</div>

		<div class="wcfm_clearfix"></div>
		<div class="wcfm_vendor_settings_heading"><h2><?php _e( 'Shipping settings', 'epmp-marketplace-melhorenvio' ); ?></h2></div>
		<div class="wcfm_clearfix"></div>
		<div class="store_address">
			<?php $WCFM->wcfm_fields->wcfm_generate_form_field( apply_filters( 'epmp_mpme_wcfm_vendor_shipping_fields', $shipping_fields, $vendor_id ) );?>
		</div>

		<div class="wcfm_clearfix"></div>
		<div class="wcfm_vendor_settings_heading"><h2><?php _e( 'Melhor Envio', 'epmp-marketplace-melhorenvio' ); ?></h2></div>
		<div class="wcfm_clearfix"></div>
		<div class="store_address">
			<p>
				<button type="button" id="load-vendor-address" class="alt">
					<?php _e( 'Load address from config', 'epmp-marketplace-melhorenvio' ); ?>
				</button>
				<?php wp_nonce_field( 'load-vendor-address', 'load-vendor-address-field' ); ?>
			</p>
			<div class="wcfm_clearfix"></div>
			<br>

			<?php $WCFM->wcfm_fields->wcfm_generate_form_field( apply_filters( 'epmp_mpme_wcfm_vendor_address_fields', $address_fields, $vendor_id ) );
			?>
			<p class="wcfm_title wcfm_ele"><strong>Agências</strong></p>
			<?php
			 	foreach( get_companies_with_agencies() as $company_id ):

					$agency_list = $agency_lists[$company_id] ?? [];
					$no_agency = empty( $agency_list );
					$company_name = get_company_name_by_id( $company_id );
					$selected_vendor_agency = $vendor_agencies[$company_id] ?? 0;

					$attributes = [];

					if( $no_agency ) {
						$attributes['disabled'] = 'disabled';
					}

					?>
					<div id="_me_company_container_<?php echo esc_attr( $company_id );?>" class="company-container" <?php echo $no_agency ? 'style="display:none"' : '' ;?>>

					<?php

					$WCFM->wcfm_fields->select_input(
						[
							'id' => '_me_company_' . esc_attr( $company_id ),
							'name' => '_me_vendor_agencies[' . esc_attr( $company_id ) .']',
							'label' => $company_name,
							'options' => wp_list_pluck( $agency_list, 'description', 'id' ),
							'type' => 'select',
							'value' => $selected_vendor_agency,
							'class' => 'wcfm-select wcfm_ele agency-list',
							'label_class' => 'wcfm_title wcfm_ele',
							'desc_class' => 'wcfm_page_options_desc',
							'desc' => sprintf(
										__( 'Select the %s agency from which you will send your packages.', 'epmp-marketplace-melhorenvio' ),
										$company_name
									),
							'attributes' => $attributes,
						]
					);
					?>
					</div>
					<?php

				endforeach;
			?>
		</div>
		<?php if( 'wcfm-vendors-manage'  === $endpoint ): ?>
			<div class="wcfm-clearfix"></div>
			<div class="wcfm-message" tabindex="-1"></div>
			<div class="wcfm-clearfix"></div>
			<div id="wcfm_messages_submit">
			    <input id="epmp-me-vendor-id" type="hidden" name="vendor_id" value="<?php echo $vendor_id; ?>">
			    <input type="hidden" name="store_id" value="<?php echo $vendor_id; ?>">
				<input type="submit" name="save-melhorenvio-data" value="<?php esc_attr_e( 'Update', 'epmp-marketplace-melhorenvio' ); ?>" id="epmp_store_melhorenvio_settings_save_button" class="wcfm_submit_button">
			</div>
			<div class="wcfm-clearfix"></div>
		</form>
		<?php endif;?>
	</div>
</div>
<style>
	#wcfm-main-contentainer .store_address p.instructions.radio-desc {
		margin-left: 0 !important;
		display: inline-block;
		width: 30% !important;
		margin-bottom: 0 !important;
	}
	#wcfm-main-contentainer fieldset#_me_vendor_document_type {
		margin-top:0;
		padding-top:0;
		box-shadow: none;
		background-color: transparent;
	}
	#wcfm-main-contentainer fieldset#_me_vendor_document_type [type="radio"] {
		vertical-align: middle;
	}
	#wcfm-main-contentainer fieldset#_me_vendor_document_type label {
		margin-bottom: 5px;
	}

	div.wcfm-content p.wcfm_page_options_desc {
	    margin-left: 35%;
	}
</style>
