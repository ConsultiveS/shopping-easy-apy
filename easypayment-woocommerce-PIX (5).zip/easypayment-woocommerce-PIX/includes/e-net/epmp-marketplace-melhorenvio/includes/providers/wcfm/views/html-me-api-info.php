<div class="epmp_mewcfm_balance">
	<div class="page_collapsible" id="epmp_mewcfm_balance_expander">
		<span class="wcfmfa fa-thumbs-up"></span>
		<span class="dashboard_widget_head">
			<?php echo esc_html( __( 'Melhor Envio info', 'epmp-marketplace-melhorenvio' ) );?>
		</span>
	</div>
	<div class="wcfm-container">
		<div id="epmp_mewcfm_balance" class="wcfm-content">
			<p><?php echo $formatted_balance;?></p>
			<?php if( $formatted_token_expiry ):?>
			<p><?php echo $formatted_token_expiry;?></p>
			<?php endif; ?>
		</div>
	</div>
</div>
