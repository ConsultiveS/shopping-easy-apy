<script type="text/html" id="tmpl-tracking_frm_template">

    <div id="wcfm_shipping_tracking_form_{{data.package_id}}" class="wcfm-collapse-content wcfm_popup_wrapper" style="display: inline-block;">
        <div style="margin-bottom: 15px;">
            <h2 style="float: none;"><?php _e('Shipment Tracking Info', 'epmp-mewcfm'); ?>: {{data.method_title}}</h2>
            <i>{{data.vendor_name}}</i>
        </div>

        <p class="wcfm_tracking_code shipment_tracking_input wcfm_popup_label">
            <strong><?php _e('Tracking Code', 'epmp-mewcfm'); ?></strong>
        </p>

        <label class="screen-reader-text" for="wcfm_tracking_code_{{data.package_id}}">
            <?php _e('Tracking Code', 'epmp-mewcfm'); ?>
        </label>

        <input type="text" id="wcfm_tracking_code_{{data.package_id}}" name="wcfm_tracking_code[{{data.package_id}}]" class="wcfm-text shipment_tracking_input wcfm_popup_input" value="{{data.value}}" placeholder="AB123456CD" >

        <# if( !data.is_correios ) { #>

        <p class="wcfm_tracking_url shipment_tracking_input wcfm_popup_label">
            <strong><?php _e('Tracking URL', 'epmp-mewcfm'); ?></strong>
        </p>

        <label class="screen-reader-text" for="wcfm_tracking_url_{{data.package_id}}">
            <?php _e('Tracking URL', 'epmp-mewcfm'); ?>
        </label>

        <input type="url" id="wcfm_tracking_url_{{data.package_id}}" name="wcfm_tracking_url[{{data.package_id}}]" class="wcfm-text shipment_tracking_input wcfm_popup_input" value="{{data.url}}" placeholder="https://site.com/" >

        <# } #>

    </div>

</script>
<script type="text/html" id="tmpl-submit_button">
    <?php wp_nonce_field( 'wcfm-track-shipment' ); ?>
    <input type="hidden" name="order_id" value="{{data.order_id}}">
    <div class="wcfm-message"></div>
    <input type="submit" id="wcfm_tracking_button" name="wcfm_tracking_button" class="wcfm_submit_button wcfm_popup_button" value="<?php _e('Submit', 'epmp-mewcfm'); ?>">
</script>
