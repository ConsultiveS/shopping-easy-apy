jQuery( function($){

	$('.agency-list').select2({
	    width: '100%'
	});

	$('#_me_vendor_shipping_zones, #_me_vendor_services').select2({
	    width: '100%',
	    closeOnSelect: false
	});

	/**
	 * Agency list cache in the format:
	 *
	 * {
	 * 		state_abbr: {
	 * 			company_id1: [ agency1, agency2, ... ],
	 * 			company_id2: [ agency1, agency2, ... ]
	 * 		}
	 * 	}
	 *
	 * @type {Object}
	 */
	var agencies = {};

	function load_agency_list(){

		var state = $('#_me_vendor_state').val();

		if( '0' == state  ){
			return;
		}

		if( !agencies.hasOwnProperty(state) ){

			$('.panel-body').block({
				message: null,
				overlayCSS: {
					background: '#fff',
					opacity: 0.6
				}
			});

			$.get(
				woocommerce_params.ajax_url,
				{ 'state':state, 'companies':epmp_mpme.all_companies, 'action':'epmp_me_get_agencies' },
				function( response ){
					if( response.success ){
						agencies[state] = response.data[state];
						epmp_mpme.populate_select( agencies[state] );
					}

					$('.panel-body').unblock();

				}
			);
		} else {
			epmp_mpme.populate_select( agencies[state] );
		}

	}

	epmp_mpme.show_agency_lists = function ( company_ids ){

		$( '.company-container,.no-agencies' ).hide();
		$( '.company-container' ).children('select').attr('disabled', 'disabled');

		var $company_containers = $(company_ids.map( company_id => '#_me_company_container_' + company_id ).join(','));

		$company_containers.show();
		$company_containers.children('select').removeAttr('disabled');

		if( !$('.company-container:visible').length ){
			$('.no-agencies').show();
		}

	}

	$('#_me_vendor_services').on( 'select2:unselect', function( e ){
		epmp_mpme.show_agency_lists(epmp_mpme.get_selected_companies())
	});

	$('#_me_vendor_services').on( 'select2:select', function( e ){

		var selected_value = parseInt(e.params.data.id);

		if( $('#_me_vendor_services [value="0"]').is(':selected') ){

			if( 1 < $('#_me_vendor_services :selected').length ) {
				$('#_me_vendor_services').val( [0] ).trigger('change');
			}

			if( 0 !== selected_value ) {
				$('#_me_vendor_services').val( [selected_value] ).trigger('change');
			}

		}

		load_agency_list();

	} );

	epmp_mpme.show_cnae_field( '._me_vendor_cnae_wrapper' );

	$( 'form' ).on('change', '#_me_vendor_services, [name="_me_vendor_document_type"]', function(){
		epmp_mpme.show_cnae_field( '._me_vendor_cnae_wrapper' );
	});
	$( 'form' ).on('change', '#_me_vendor_state', function(){
		epmp_mpme.force_select_update = true;
		load_agency_list();
	});

	$(document.body).on( 'wcfm_form_validate', function(e, form){

		$form = $(form);
		var $cep = $form.find('#_me_vendor_postal_code');
		$cep.removeClass('wcfm_validation_success wcfm_validation_failed');

		if( $cep.val() && $cep.val().length && !/[0-9]{5}[-\s]?[\d]{3}/.test( $cep.val() ) ){

			$('#' + $form.attr('id') + ' .wcfm-message').append( '<span class="wcicon-status-cancelled"></span>' + $cep.data('validation_message') ).addClass('wcfm-error').slideDown();

			$cep.addClass('wcfm_validation_failed');

			$wcfm_is_valid_form = false;
		} else {
			$cep.addClass('wcfm_validation_success');
		}

	} );

	$('#epmp_store_melhorenvio_settings_save_button').click(function(event) {
	    event.preventDefault();

	    // Validations
		$('.wcfm-message').html('').removeClass('wcfm-error').removeClass('wcfm-success').slideUp();
		$wcfm_is_valid_form = true;
		$( document.body ).trigger( 'wcfm_form_validate', $('#wcfm_vendor_manage_form_epmp_melhor_envio') );
		$is_valid = $wcfm_is_valid_form;

	    if($is_valid) {
			$('#wcfm_settings_form_melhor_envio_expander').block({
				message: null,
				overlayCSS: {
					background: '#fff',
					opacity: 0.6
				}
			});

			var data = {
				action : 'epmp_mpme_admin_vendor_manage',
				controller: 'epmp-mpme-admin-settings',
				wcfm_settings_form : $('#wcfm_vendor_manage_form_epmp_melhor_envio').serialize(),
			}

			$.post(wcfm_params.ajax_url, data, function($response_json) {
				if($response_json) {
					$('.wcfm-message').html('').removeClass('wcfm-error wcfm-success').slideUp();
					if($response_json.data.status) {
						wcfm_notification_sound.play();
						$('#wcfm_settings_form_melhor_envio_expander .wcfm-message').html('<span class="wcicon-status-completed"></span>' + $response_json.data.message).addClass('wcfm-success').slideDown();
						$( '.wcfm_validation_failed' ).removeClass( 'wcfm_validation_failed' );
					} else {
						wcfm_notification_sound.play();
						$('#wcfm_settings_form_melhor_envio_expander .wcfm-message').html('<span class="wcicon-status-cancelled"></span>' + $response_json.data.message).addClass('wcfm-error').slideDown();

						var fields_with_errors = $response_json.data.fields.map(function(el){
							return '#'+el;
						}).join();

						$( fields_with_errors ).addClass( 'wcfm_validation_failed' )
					}
					$('#wcfm_settings_form_melhor_envio_expander').unblock();
				}
			});
		}
	});

	$('#_me_vendor_fixed_cost').maskDecimals();

} );

jQuery(function ($) {
	$( '#load-vendor-address' ).click( function(){

		$('#wcfm_settings_form').block({
			message: null,
			overlayCSS: {
				background: '#fff',
				opacity: 0.6
			}
		});

		var nonce = $( '#load-vendor-address-field' ).val();
		var vendor_id = $( '#epmp-me-vendor-id' ).val();

		$.get( woocommerce_params.ajax_url, {
			'load-vendor-address-field': nonce,
			'action': 'load-vendor-address',
			'vendor_id': vendor_id
		}, function( response ){
			if( response.success ){
				var fields = response.data;
				for( var field_id in response.data ){
					value = fields[field_id] && ''
					if( value.length ){
						$( '#' + field_id ).val( value );
					}
				}
			}
			$('#wcfm_settings_form').unblock();
		} );
	} );
});
