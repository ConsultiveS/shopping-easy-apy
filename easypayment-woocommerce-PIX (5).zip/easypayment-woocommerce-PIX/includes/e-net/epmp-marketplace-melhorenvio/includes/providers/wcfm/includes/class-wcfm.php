<?php

use function Epmp\ME\functions\get_agencies_list_by_state;
use function Epmp\ME\functions\is_melhorenvio_method;
use const Epmp\ME\constants\{ CORREIOS_COMPANY_ID, JADLOG_COMPANY_ID };

class Epmp_MEWCFM_Provider extends Epmp_MPME_Abstract_Vendors_Provider implements Epmp_MPME_Shipping_Processor {

	public function __construct(){

		if( !class_exists( 'WCFMmp' ) ) {

			$this->provider_not_found_message = __( 'The plugin "WooCommerce Multivendor Marketplace" could not be found. Please, install and activate it before registering this adapter.', 'epmp-marketplace-melhorenvio' );
			$this->is_active = false;

			add_action( 'admin_notices', [ $this, 'provider_not_found' ] );

		} else {
			global $WCFMmp;
			add_filter( 'wcfm_is_allow_store_shipping','__return_true' );

			add_action( 'woocommerce_checkout_create_order_shipping_item', [ $this, 'add_package_qty' ], 99, 3 );

			remove_action( 'woocommerce_checkout_create_order_shipping_item',
				[ $WCFMmp->wcfmmp_shipping, 'wcfmmp_add_meta_date_in_shipping_package' ],
				10 );

			add_filter( 'woocommerce_order_item_get_formatted_meta_data' , [ $this, 'remove_useless_shipping_item_metas' ], 10, 2 );

			add_action( 'wcfm_vendor_settings_after_customer_support', [ $this, 'add_vendor_fields' ], 10, 2 );
			add_action( 'wp_ajax_epmp_mpme_admin_vendor_manage', [ $this, 'update_user_meta' ] );
			add_action( 'wcfm_vendor_settings_update', [ $this, 'update_user_meta' ] );

			// Admin fields
			add_action( 'end_wcfm_vendors_manage_form', [ $this, 'add_admin_vendor_fileds' ], 13 );

			add_action( 'woocommerce_order_details_after_order_table', [ $this, 'show_tracking_history' ] );

			// add_action( 'wp_ajax_mark-item-shipped', [ $this, 'mark_item_shipped' ] );
			add_action( 'wcfmmp_vendor_order_status_updated', [ $this, 'mark_order_shipped' ], 10, 3 );

			add_action( 'wp_ajax_load-vendor-address', [ $this, 'load_address_from_store_config' ] );

			add_action( 'after_wcfm_dashboard_product_stats',  [ $this, 'show_me_api_info' ] );


		}

	}

	public function is_vendor( $user_id ){
		return wcfm_is_vendor( $user_id );
	}

	public function is_vendor_dashboard(){
		return wc_post_content_has_shortcode( 'wc_frontend_manager' );
	}

	public function get_shipping_recipient(){
		$wcfm_commission_options = get_option( 'wcfm_commission_options', [] );

		$is_vendor_shipping = $wcfm_commission_options['get_shipping'] ?? 'yes';

		return wc_string_to_bool( $is_vendor_shipping ) ? 'vendor' : 'admin' ;
	}

	public function get_order_comission_by_vendor( $order_id, $vendor_id ){

	}

	/**
	 * Gets vendor id based on product id
	 * @param  int $id      the id of the product
	 * @return int          the id of the vendor
	 * @throws Exception    whether the product has a vendor assigned to it
	 */
	public function get_vendor_id_from_product( $id ){
		global $WCFM;

		$product = wc_get_product( $id );

		if( $product->is_type( 'variation' ) ){
			$id = $product->get_parent_id();
		}

		$vendor_id = $WCFM->wcfm_vendor_support->wcfm_get_vendor_id_from_product( $id );

		if( !$vendor_id ) {
			$message = sprintf( __( 'Product with id %d has no vendor assigned to it.', 'epmp-marketplace-melhorenvio' ), $id );
			throw new Exception( $message );
		}

		return $vendor_id;

	}

	/**
	 * Gets vendor "sold by" based on product id
	 * @param  int $id      the id of the vendor
	 * @return string       the "sold by" of the vendor
	 */
	public function get_vendor_name( $id ){
		$shop_info = wcfmmp_get_store( $id )->get_shop_info();
		return $shop_info['store_name'];
	}

	/**
	 * Gets vendor post code based on their id
	 * @param  int $id      the id of the vendor
	 * @return string       the vendor's post code
	 * @throws Exception    whether the vendor has a post code assigned to them
	 */
	public function get_vendor_postcode( $vendor_id ){

		$postcode = get_user_meta( $vendor_id, '_me_vendor_postal_code', true );

		if( !$postcode ) {
			$message = sprintf( __( 'Vendor with id %d has no post code.', 'epmp-marketplace-melhorenvio' ), $vendor_id );
			throw new Exception( $message );
		}

		return $postcode;

	}

	public function mark_order_shipped( $order_id, $order_status, $vendor_id ){

		if( 'wc-shipped-out' === $order_status ){
			$item_id = $_POST['item_id'] ?? 0;

			$vendor_packages = [];

			if( $item_id ){
				$vendor_packages[$item_id] = [];
				$vendor_packages[$item_id]['id'] = $item_id;
			} else {
				$vendor_packages = $this->get_package_by_vendor( $order_id, $vendor_id );
			}

			foreach( $vendor_packages as $item_id => $vendor_package ){
				if( !is_melhorenvio_method( wc_get_order_item_meta( $item_id, 'method_id', true ) ) ){
					continue;
				}
				$this->mark_as_shipped( $order_id, $vendor_id, intval( $item_id ) );
				$this->send_shipped_out_email( $order_id, $item_id );
			}
		}

	}

	public function send_shipped_out_email( $order_id, $item_id ){

	    $shipping_item = new \WC_Order_Item_Shipping( $item_id );

	    $emails = WC()->mailer()->get_emails();
	    $mailer = $emails['Epmp_ME_Emails_Shipped_Out'];

	    $companies = [ CORREIOS_COMPANY_ID => 'Correios', JADLOG_COMPANY_ID => 'JadLog' ];

	    $label_data = $shipping_item->get_meta( '_epmp_me_label_data' );

	    if( $label_data &&
	        isset( $label_data['orders'] ) &&
	        !$shipping_item->get_meta( '_epmp_me_shipping_mail_sent' )
	    ){
	        $label_data['company'] = $companies[$shipping_item->get_meta( '_company_id' )];
	        $mailer->trigger( $order_id, wc_get_order( $order_id ), $label_data, $shipping_item );
	    }

	}

	/**
	 * Marking order as shipped
	 * @param  int $order_id
	 * @param  int $vendor_id
	 * @param  int $package_id
	 * @return void
	 */
	public function mark_as_shipped( $order_id, $vendor_id = null, $package_id = null ){

		global $wpdb;

		$wpdb->query( $wpdb->prepare("UPDATE {$wpdb->prefix}wcfm_marketplace_orders
			SET shipping_status = 'shipped',
			commission_status = 'shipped'
			WHERE order_id = %d
			AND vendor_id = %d
			AND item_id = %d",
			$order_id,
			$vendor_id,
			$package_id
		) );

		$this->add_mark_as_shipped_note( $order_id, $vendor_id, $package_id );

	}

	private function add_mark_as_shipped_note( $order_id, $vendor_id, $package_id ){

		$order = wc_get_order( $order_id );
		$shippers[] = $vendor_id;
		$vendor_name = $this->get_vendor_name( $vendor_id );

		$message = sprintf( __( '%s added shipping info.', 'epmp-marketplace-melhorenvio' ), $vendor_name );

		$label_data = wc_get_order_item_meta( $package_id, '_epmp_me_label_data' );

		if( !isset( $label_data['orders'] ) ){
			return;
		}

		$tracking_code = join( ', ', epmp_mpme_get_tracking_code_list( $label_data ) );

		ob_start();
		include_once EPMP_MEWCFM_DIR . '/views/html-order-shipping-note.php';
		$html = ob_get_clean();

		$order->add_order_note( $html, true );

	}

	/**
	 * Get tracking code url.
	 *
	 * @param  string $tracking_code Tracking code.
	 *
	 * @return string
	 */
	public function get_tracking_code_url( $tracking_code ) {
		$url = sprintf(
			'<a href="https://www.melhorrastreio.com.br/rastreio/%1$s">%1$s</a>',
			$tracking_code
		);

		return $url;
	}

	/**
	 * Adds "package_qty" meta so the shippíng cost can be calculated later on
	 * @param WC_Order_Item_Shipping $item
	 * @param string                 $package_key
	 * @param array                  $package
	 */
	public function add_package_qty( $item, $package_key, $package ){

		$package_qty = array_sum( wp_list_pluck( $package['contents'], 'quantity' ) );
		$item->add_meta_data( 'package_qty', $package_qty, true );

		do_action( 'wcmp_add_shipping_package_meta_data' );

	}

	/**
	 * Little utility to remove useless info from the front-end
	 * @param  array                  $formatted_meta
	 * @param  WC_Order_Item_Shipping $item
	 * @return array
	 */
	public function remove_useless_shipping_item_metas( $formatted_meta, $item ){

		if( is_admin() ){
			return $formatted_meta;
		}

		foreach( $formatted_meta as $key => $meta ){
			if( in_array( $meta->key, ['method_label', 'vendor_name', 'Vendedor'] ) ){
				unset( $formatted_meta[$key] );
			}
		}

		return $formatted_meta;

	}

	public function add_vendor_fields( $vendor_id ){
		global $WCFMmp;

		$this->render_vendor_address_fields_html( $vendor_id, EPMP_MEWCFM_DIR . '/views/html-vendor-fields.php' );
	}

	public function update_user_meta( $vendor_id ){

		$is_admin = false;

		if( !in_array( $_POST['controller'] ?? '', [ 'wcfm-settings', 'epmp-mpme-admin-settings' ] ) ){
			return;
		}

		parse_str( $_POST['wcfm_settings_form'], $wcfm_settings_form );

		if( 'epmp-mpme-admin-settings' === $_POST['controller'] ){
			$is_admin = true;
			$vendor_id = $wcfm_settings_form['store_id'];
		}

		if( $errors = epmp_mpme_validate_vendor_fields( $wcfm_settings_form ) ){
			wp_send_json_success(
				[ 'status' => false, 'message' => join( '<br>', $errors ), 'fields' => array_keys( $errors ) ]
			);
			wp_die();
		}

		update_user_meta( $vendor_id, '_me_vendor_shipping_zones', $wcfm_settings_form['_me_vendor_shipping_zones'] ?? [] );
		update_user_meta( $vendor_id, '_me_vendor_services', $wcfm_settings_form['_me_vendor_services'] ?? null );

		epmp_mpme_update_user_meta( $vendor_id, $wcfm_settings_form );

		if( $is_admin ){
			wp_send_json_success( [ 'status' => true, 'message' => '' ] );
			wp_die();
		}

	}

	public function add_admin_vendor_fileds( $vendor_id ){
		add_action('wp_enqueue_scripts', 'epmp_mewcfm_wcmp_scripts');
		?>
		<style>
		    #wcfm-main-contentainer fieldset,
		    p.wcfm_page_options_desc {
		        margin-left: 35%;
		        border: 0px !important;
		        margin-right: 0% !important;
		        display: block;
		    }
		</style>
		<?php epmp_mpme_current_provider()->add_vendor_fields( $vendor_id ); ?>
		<div class="wcfm_clearfix"></div>
		<br>
		<?php
	}

	public function show_tracking_history( $order ){

		return;

		if( !is_wc_endpoint_url() ){
			return;
		}

		if( $packages = $order->get_shipping_methods() ){
			$packages = array_filter( $packages, function( $package ){
				return !epmp_wcvc_is_correios_method( $package->get_method_id() )
						&& $package->get_meta( 'correios_tracking_url' );
			} );

			include EPMP_MEWCFM_DIR . '/views/tracking-history.php';

		}

	}

	public function load_address_from_store_config(){

		$vendor_id = $_GET['vendor_id'] ?? get_current_user_id();

		if(
			!$this->is_vendor( $vendor_id ) ||
			!wp_verify_nonce( $_GET['load-vendor-address-field'], 'load-vendor-address' )
		){
			wp_send_json_error();
			wp_die();
		}

		$user_data = wcfmmp_get_store( $vendor_id )->get_shop_info();

		$address = apply_filters(
			'epmp_mpme_load_vendor_address',
			[
				'_me_vendor_name'          => $user_data['store_name'],
				'_me_vendor_phone'         => $user_data['phone'],
				'_me_vendor_email'         => $user_data['store_email'],
				'_me_vendor_address'       => $user_data['address']['street_1'],
				'_me_vendor_complement'    => $user_data['address']['street_2'],
				'_me_vendor_city'          => $user_data['address']['city'],
				'_me_vendor_state'         => $user_data['address']['state'],
				'_me_vendor_postal_code'   => $user_data['address']['zip'],
			],
			$vendor_id
		);

		wp_send_json_success( $address );
		wp_die();
	}

	public function show_me_api_info(){
		$this->load_me_user_info_template( get_current_user_id(), EPMP_MEWCFM_DIR . '/views/html-me-api-info.php' );
	}

}
