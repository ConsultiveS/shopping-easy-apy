<?php
global $WCFMmp;

use const Epmp\ME\constants\{ JADLOG_COMPANY_ID, DOCUMENT_TYPE_CNPJ };
use function Epmp\ME\functions\is_melhorenvio_method;
use function Epmp\ME\functions\is_invoice_required_for_item;
use function Epmp\ME\functions\is_labelling_available_for_item;
use function Epmp\ME\functions\item_can_bypass_invoice;
use function Epmp\ME\functions\get_labels_generation_allowed_statuses;
use function Epmp\ME\functions\save_product_fields;

function epmp_mewcfm_render_tracking_form(){
	include_once EPMP_MEWCFM_DIR . '/views/html-tmpl-tracking-fields.php';
}

function epmp_mewcfm_render_invoice_form(){
	include_once EPMP_MEWCFM_DIR . '/views/html-tmpl-invoice-field.php';
}

add_action( 'after_wcfm_orders', 'epmp_mewcfm_render_invoice_form' );
add_action( 'after_wcfm_vendors_manage', 'epmp_mewcfm_render_invoice_form' );

function epmp_mewcfm_add_label_actions( $actions, $order_id, $order ){

	global $WCFMmp;

	$me_actions = [];

	$labels_generation_allowed_statuses = get_labels_generation_allowed_statuses();

	$vendor_order_status = apply_filters( 'wcfm_current_order_status', $order->get_status(), $order->get_id() );

	if(
		!in_array( $vendor_order_status, $labels_generation_allowed_statuses ) ||
		!epmp_mpme_vendor_can_generate_labels( (int) get_current_user_id() )
	){
		return $actions;
	}

	$vendor_id = $WCFMmp->vendor_id;

	foreach( $order->get_shipping_methods() as $shipping_item ){

		$item_id = $shipping_item->get_id();

		if( !is_melhorenvio_method( $shipping_item->get_method_id() ) ||
			(int) wc_get_order_item_meta( $item_id, 'vendor_id' ) !== (int) $vendor_id ||
			!is_labelling_available_for_item( $item_id )
		){
			continue;
		}

		$label_data = wc_get_order_item_meta( $item_id, '_epmp_me_label_data' );

		if(
			empty( $label_data ) &&
			epmp_mpme_is_invoice_required_for_vendor( $vendor_id ) &&
			is_invoice_required_for_item( $item_id )
		){

			$me_actions['add_invoice_' . $item_id] = [
				'url' => '#',
				'name' => __( 'Add invoice number', 'epmp-marketplace-melhorenvio' ),
				'action' => 'add-invoice-number',
				'item_id' => $item_id,
				'external' => false,
			];

			if( item_can_bypass_invoice( $item_id ) ){
				$me_actions['buy_labels_' . $item_id] = [
					'url' => wp_nonce_url(
						admin_url(
							'admin-ajax.php?action=buy-labels-for-item&item_id=' . $item_id
						),
						'epmp-me-buy-labels-for-item'
					),
					'name' => __( 'Buy labels non-commercially', 'epmp-melhorenvio' ),
					'action' => 'buy-labels',
					'external' => false,
				];
			}

			continue;
		}

		if( empty( $label_data ) ){
			$me_actions['buy_labels_' . $item_id] = [
				'url' => wp_nonce_url(
					admin_url(
						'admin-ajax.php?action=buy-labels-for-item&item_id=' . $item_id
					),
					'epmp-me-buy-labels-for-item'
				),
				'name' => __( 'Buy labels', 'epmp-melhorenvio' ),
				'action' => 'buy-labels',
				'external' => false,
			];
		} elseif(
			( isset( $label_data['preview'] ) && $label_data['preview'] )
			|| isset( $label_data['print_link'], $label_data['print_link']->message)
		) {

			$me_actions['generate_labels_' . $item_id] = [
				'url' => wp_nonce_url(
					admin_url(
						'admin-ajax.php?action=generate-labels-for-item&item_id=' . $item_id
					),
					'epmp-me-generate-labels-for-item'
				),
				'name' => __( 'Generate labels', 'epmp-melhorenvio' ),
				'action' => 'generate-labels',
				'external' => false,
			];

			foreach( $label_data['orders'] as $key => $me_order ){
				if( isset( $me_order['preview_link']->url ) ){
					$me_actions['preview_labels_' . $key] = [
						'url' => $me_order['preview_link']->url,
						'name' => __( 'Preview labels', 'epmp-melhorenvio' ),
						'action' => 'preview-labels',
						'external' => true,
					];
				} elseif( isset( $me_order['error'] ) || isset( $me_order['preview_link']->error ) ){
					$error = $me_order['error'] ?? $me_order['preview_link']->error;

					$me_actions['generate_labels_' . $item_id]['name'] = wp_strip_all_tags( $error );
					$me_actions['generate_labels_' . $item_id]['action'] .= ' has-error';
				}
			}

		} elseif( isset( $label_data['preview'], $label_data['print_link'], $label_data['print_link']->url ) ) {

			$me_actions['mark_shipped_' . $item_id ] = [
				'url' => '#',
				'name' => __( 'Mark as shipped', 'epmp-marketplace-melhorenvio' ),
				'action' => 'mark-shipped',
				'external' => false,
				'item_id' => $item_id,
				'order_id' => $order_id,
			];

			$me_actions['print_labels_' . $item_id] = [
				'url' => $label_data['print_link']->url,
				'name' => __( 'Print labels', 'epmp-melhorenvio' ),
				'action' => 'print-labels',
				'external' => true,
			];

		}

	}

	foreach( $me_actions as $me_action ){

		$item_id =  isset( $me_action['item_id'] ) ? 'data-item_id=' . intval( $me_action['item_id'] ) : '';
		$order_id = isset( $me_action['order_id'] ) ? 'data-order_id=' . intval( $me_action['order_id'] ) : '';

		ob_start();
		?>
		<a class="me-action me-action-<?php echo esc_attr( $me_action['action'] );?> wcfm-action-icon" href="<?php echo esc_attr( $me_action['url'] );?>" <?php echo ( $me_action['external'] ? 'target="_blank" rel="noopener noreferrer"' : '' );?> <?php echo $item_id; ?> <?php echo $order_id; ?> >
			<span class='wcfmfa text_tip' data-tip='<?php echo esc_attr( $me_action['name'] )?>'></span>
		</a>
		<?php
		$actions .= ob_get_clean();

	}

	return $actions;

}

add_filter( 'wcfm_orders_module_actions', 'epmp_mewcfm_add_label_actions', 10, 3) ;

add_action( 'wp_head', function(){
	?>
	<style>
		.me-action {
			background-color: #0550a0 !important;
			color:#f3b331 !important;
			font-weight: 600;
		}
		.me-action-add-invoice-number span:before{
			content: "\f15c";
		}
		.me-action-buy-labels span:before{
			content: "\f217";
		}
		.me-action-generate-labels span:before{
			content: "\f56e";
		}
		.me-action-generate-labels.has-error span:after{
		    content: "\f06a";
		    display: block;
		    position: absolute;
		    color:red;
		    left:calc( 100% - 8px );
		    border-radius: 50%;
		    background-color: #fff;
		}
		.me-action-preview-labels span:before{
			content: "\f06e";
		}
		.me-action-print-labels span:before{
			content: "\f02f";
		}
		.me-action-mark-shipped span:before{
			content: "\f0d1";
		}

	</style>
	<?php
} );

function epmp_mewcfm_print_notices(){
	wc_print_notices();
}

add_action( 'before_wcfm_marketplace_settings', 'epmp_mewcfm_print_notices' );
add_action( 'before_wcfm_orders_container', 'epmp_mewcfm_print_notices' );

add_filter( 'wcfm_form_custom_validation', function( $form_data, $form_name ){

	// Making sure it comes from vendor's front-end, not admin's.
	if(
		( isset( $_POST['controller'] ) && 'wcfm-settings' === $_POST['controller'] ) &&
		'vendor_setting_manage' === $form_name &&
		$errors = epmp_mpme_validate_vendor_fields( $form_data )
	){
		return [ 'has_error' => true, 'message' => join( '<br>', $errors ) ];
	}

	return $form_data;

}, 10, 2 );

/**
 * Removing hooks
 */
function epmp_mewcfm_remove_hooks() {
	if( class_exists( 'WCFMu' ) ){
		global $WCFMu;

		remove_filter( 'wcfm_orders_actions', array( $WCFMu->wcfmu_shipment_tracking, 'wcfmu_shipping_tracking_orders_actions' ), 20);
		remove_filter( 'wcfmmarketplace_orders_actions', array( $WCFMu->wcfmu_shipment_tracking, 'wcfmu_wcfmmarketplace_shipping_tracking_orders_actions' ), 20);

	}
}

add_action( 'wcfm_init', 'epmp_mewcfm_remove_hooks', PHP_INT_MAX );

function epmp_mewcfm_remove_tracking_meta_from_customer_order(){
	if( class_exists( 'WCFMu' ) ){
		global $WCFMu;
		remove_action(
			'woocommerce_order_item_meta_end',
			array( $WCFMu->wcfmu_shipment_tracking, 'wcfm_order_tracking_response' ),
			20
		);
	}
}

add_action( 'wcfm_init', 'epmp_mewcfm_remove_tracking_meta_from_customer_order', PHP_INT_MAX );

function epmp_mewcfm_add_location_info_to_package( $packages ){

	$processing_times = wcfmmp_get_shipping_processing_times();

	foreach( $packages as &$package ){

		$vendor_id = $package['vendor_id'];

		$processing_time = isset($wcfmmp_shipping['_wcfmmp_pt']) ? $wcfmmp_shipping['_wcfmmp_pt'] : '';
		$processing_time = ( $processing_time && isset( $processing_times[$processing_time] ) ) ?
								$processing_times[$processing_time] : '-';

		$store_user = wcfmmp_get_store( $vendor_id );

		$package['processing_time'] = $processing_time;
		$package['pickup_address'] = $store_user->get_address_string();

		if( apply_filters( 'wcfmmp_is_allow_checkout_user_location', true ) ) {
			$wcfmmp_user_location     = WC()->session->get( '_wcfmmp_user_location' );
			$wcfmmp_user_location_lat = WC()->session->get( '_wcfmmp_user_location_lat' );
			$wcfmmp_user_location_lng = WC()->session->get( '_wcfmmp_user_location_lng' );
			if( $wcfmmp_user_location ) {
				$package['wcfmmp_user_location']     = $wcfmmp_user_location;
				$package['wcfmmp_user_location_lat'] = $wcfmmp_user_location_lat;
				$package['wcfmmp_user_location_lng'] = $wcfmmp_user_location_lng;
			}
		}
	}


	return $packages;
}

add_filter( 'epmp_mpme_cart_shipping_packages', 'epmp_mewcfm_add_location_info_to_package' );

add_action( 'wp_ajax_epmp_mewcfm_add_invoice_number', function(){

	if( wp_verify_nonce( $_POST['invoice-number-field'] ?? '', 'add-invoice-number' ) ){
		Epmp\ME\Admin\Orders::save();
	}

	wp_send_json_success();
} );

add_filter( 'wcfm_product_manage_fields_shipping', function( $shipping_fields, $product_id ){

	$shipping_fields['_epmp_me_additional_time'] = [
		'label' => __( 'Additional time', 'epmp-marketplace-melhorenvio' ),
		'type' => 'text',
		'class' => 'wcfm-text',
		'label_class' => 'wcfm_title',
		'value' => get_post_meta( $product_id, '_epmp_me_additional_time', true ),
		'hints' => __( 'Number of days to add to the delivery time.', 'epmp-marketplace-melhorenvio' )
	];

	return $shipping_fields;

}, 10, 2 );

add_filter( 'wcfm_is_allow_hide_admin_shipping_for_vendor_shipping', '__return_false' );

add_action( 'after_wcfm_products_manage_meta_save', function( $post_id, $post_data ){

	save_product_fields( $post_id, $post_data );

}, 10, 2 );

add_action( 'epmp_mpme_provider_wcfm_loaded', function(){
	global $WCFMmp;
	remove_action( 'woocommerce_shipping_package_name', array( $WCFMmp->wcfmmp_shipping, 'wcfmmp_shipping_package_name' ), 500 );
} );

function epmp_mpme_wcfm_get_vendor_field_specs(){

	$fields = [];

	$fields['vendor_enabled'] = [
		'id' => '_me_vendor_enabled',
		'label' => __( 'Enable Melhor Envio', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_token'] = [
		'id' => '_me_vendor_token',
		'label' => __( 'Token', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_shipping_zones'] = [
		'id' => '_me_vendor_shipping_zones',
		'label' => __( 'Shipping zones', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_services'] = [
		'id' => '_me_vendor_services',
		'label' => __( 'Services', 'epmp-marketplace-melhorenvio' ),
	];


	$fields['vendor_fixed_cost'] = [
		'id' => '_me_vendor_fixed_cost',
		'label' => __( 'Additional fixed cost', 'epmp-marketplace-melhorenvio' ),
	];


	$fields['vendor_percent_cost'] = [
		'id' => '_me_vendor_percent_cost',
		'label' => __( 'Additional percent cost', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_receiver_only'] = [
		'id' => '_me_vendor_receiver_only',
		'label' => __( 'Receiver only', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_receipt'] = [
		'id' => '_me_vendor_receipt',
		'label' => __( 'Receipt', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_collect'] = [
		'id' => '_me_vendor_collect',
		'label' => __( 'Collect', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_name'] = [
		'id' => '_me_vendor_name',
		'label' => __( 'Name', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_phone'] = [
		'id' => '_me_vendor_phone',
		'label' => __( 'Phone', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_email'] = [
		'id' => '_me_vendor_email',
		'label' => __( 'Email', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_additional_time'] = [
		'id' => '_me_vendor_additional_time',
		'label' => __( 'Additional time', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_document_type'] = [
		'id' => '_me_vendor_document_type',
		'label' => __( 'Document type', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_document'] = [
		'id' => '_me_vendor_document',
		'label' => __( 'Document', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_cnae'] = [
		'id' => '_me_vendor_cnae',
		'label' => __( 'CNAE', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_state_register'] = [
		'id' => '_me_vendor_state_register',
		'label' => __( 'State Register', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_address'] = [
		'id' => '_me_vendor_address',
		'label' => __( 'Address', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_complement'] = [
		'id' => '_me_vendor_complement',
		'label' => __( 'Complement', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_number'] = [
		'id' => '_me_vendor_number',
		'label' => __( 'Number', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_district'] = [
		'id' => '_me_vendor_district',
		'label' => __( 'Neighborhood', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_city'] = [
		'id' => '_me_vendor_city',
		'label' => __( 'City', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_state'] = [
		'id' => '_me_vendor_state',
		'label' => __( 'State', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_postal_code'] = [
		'id' => '_me_vendor_postal_code',
		'label' => __( 'Postcode', 'epmp-marketplace-melhorenvio' ),
	];

	$fields['vendor_agency'] = [
		'id' => '_me_vendor_agency',
		'label' => __( 'Agency', 'epmp-marketplace-melhorenvio' ),
	];

	return $fields;

}

add_filter( 'epmp_mpme_validate_vendor_fields', function( $errors, $post_data ){

	if( !isset( $post_data['_me_vendor_enabled'] ) ){
		return [];
	}

	$wcfm_fields = wp_list_pluck(
		epmp_mpme_wcfm_get_vendor_field_specs(),
		'label',
		'id'
	);

    $required_fields = [
    	'_me_vendor_name',
    	'_me_vendor_phone',
    	'_me_vendor_email',
    	'_me_vendor_document',
    	'_me_vendor_address',
    	'_me_vendor_number',
    	'_me_vendor_district',
    	'_me_vendor_city',
    	'_me_vendor_state',
    	'_me_vendor_postal_code',
    ];

    foreach( $required_fields as $field ){
    	if( empty( $post_data[$field] ) ){
    		$errors[$field] = sprintf(
    			__( 'The field %s is required.', 'epmp-marketplace-melhorenvio' ),
    			$wcfm_fields[$field]
    		);
    	}
    }

    return $errors;

}, 10, 2);

add_filter( 'epmp_mpme_remove_parent_orders_meta_boxes', '__return_false' );
