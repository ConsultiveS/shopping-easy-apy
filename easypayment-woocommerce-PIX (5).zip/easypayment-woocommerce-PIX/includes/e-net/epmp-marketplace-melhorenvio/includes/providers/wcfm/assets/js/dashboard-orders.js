jQuery(function($){

	invoice_number_labels = {number_saved:'Código enviado!', number_error:'Código não pode ser salvo!'};
	status_labels = {status_saved:'Pedido marcado como enviado!', status_error:'Houve um erro ao marcar o pedido como enviado!'};

	function show_error_message( message ){
		$('#wcfm_invoice_number_form .wcfm-message').html( '<span class="wcicon-status-completed"></span>' + message ).addClass('wcfm-error').slideDown();
	}
	function show_success_message( message ){
		$('#wcfm_invoice_number_form .wcfm-message').html( '<span class="wcicon-status-completed"></span>' + message ).addClass('wcfm-success').slideDown();
	}

	$( document.body ).on( 'updated_wcfm-orders', function() {

		$('.me-action-add-invoice-number').click(function(event) {

			event.preventDefault();

			var item = $(this);

			var template = wp.template("invoice_frm_template");

			var template_html = "";

			var item_id = item.data('item_id');
			var order_id = item.data('order_id');

			template_html = template( { 'item_id':item_id } );

			template_html = $('<form id="wcfm_invoice_number_form">').html( template_html );
				// Intialize colorbox
				$.colorbox( { html: template_html, height: 500, width: 600,
					onComplete: function() {

						$('.wcfm_popup_wrapper:last-child').append( wp.template("invoice_submit_button") );

						$('#wcfm_tracking_button').click(function(e) {
							e.preventDefault();

							$('#wcfm_invoice_number_form').block({
								message: null,
								overlayCSS: {
									background: '#fff',
									opacity: 0.6
								}
							});

							jQuery( document.body ).trigger( 'wcfm_form_validate', jQuery('#wcfm_invoice_number_form') );

							if( !$wcfm_is_valid_form ) {

								wcfm_notification_sound.play();
								jQuery('#wcfm_invoice_number_form').unblock();

							} else {

								$('#wcfm_tracking_button').hide();
								$('#wcfm_invoice_number_form .wcfm-message').html('').removeClass('wcfm-error').removeClass('wcfm-success').slideUp();


								var data = jQuery( "#wcfm_invoice_number_form" ).serializeArray();

								data.push( { name : 'action', value : 'epmp_mewcfm_add_invoice_number' } );

								$.ajax({
									type: 'POST',
									url: wcfm_params.ajax_url,
									data: data,
									success: function( response ) {

										if( response.success ){
											wcfm_notification_sound.play();
											$wcfm_orders_table.ajax.reload();
											show_success_message( invoice_number_labels.number_saved )
										} else {
											show_error_message( invoice_number_labels.number_error );
										}

										$('#wcfm_invoice_number_form').unblock();

										setTimeout(function() {
											$.colorbox.remove();
										}, 2000);

									},
									error : function( jqXHR, textStatus, errorThrown ) {
										show_error_message( invoice_number_labels.number_error );
										jQuery('#wcfm_invoice_number_form').unblock();
									}
								});
							}
						});
					}
				});

			});
	});
	$( document.body ).on( 'updated_wcfm-orders', function() {
		$('.me-action-mark-shipped').click(function( e ){
			e.preventDefault();
			var order_id = $(this).data('order_id');
			var item_id = $(this).data('item_id');
			var status = 'wc-shipped-out';

			$('#wcfm-orders_wrapper').block({
				message: null,
				overlayCSS: {
					background: '#fff',
					opacity: 0.6
				}
			});

			$.ajax({
				type: 'POST',
				url: wcfm_params.ajax_url,
				data: {
					item_id:item_id,
					order_id:order_id,
					order_status:status,
					action:'wcfm_modify_order_status',
					wcfm_ajax_nonce:wcfm_params.wcfm_ajax_nonce
				},
				success: function( response ) {

					response = $.parseJSON(response);

					if( response.status ){

						wcfm_notification_sound.play();
						$wcfm_orders_table.ajax.reload();

						show_success_message( invoice_number_labels.status_saved )

					} else {
						show_error_message( status_labels.status_error );
					}

					$('#wcfm-orders_wrapper').unblock();

				},
				error : function( jqXHR, textStatus, errorThrown ) {
					show_error_message( status_labels.status_error );
					jQuery('#wcfm-orders_wrapper').unblock();
				}
			});

		})
	})

});
