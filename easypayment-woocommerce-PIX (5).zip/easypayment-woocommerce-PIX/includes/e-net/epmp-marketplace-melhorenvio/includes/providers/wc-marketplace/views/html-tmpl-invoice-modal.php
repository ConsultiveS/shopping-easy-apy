<script type="text/html" id="tmpl-invoice_frm_template">
        <h3><?php _e('Add the invoice number to create shipping label', 'epmp-marketplace-melhorenvio') ?></h3>
    	<div class="form-group">
    	    <label for="_invoice_number_{{data.item_id}}"><?php _e('Invoice number', 'epmp-marketplace-melhorenvio'); ?> </label>
    	    <input type="text" class="form-control" id="_invoice_number_{{data.item_id}}" name="_invoice_number[{{data.item_id}}]" value="{{data.invoice_key}}" >
    	</div>
	</div>
</script>

<div id="invoice-info-modal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <form method="post">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><?php esc_html_e('Invoice info', 'epmp-marketplace-melhorenvio'); ?></h4>
                </div>
                <div class="modal-body">
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" name="wcmp-submit-invoice-number"><?php esc_html_e('Submit', 'epmp-marketplace-melhorenvio'); ?></button>
                </div>
            </div>
	    <?php wp_nonce_field( 'add-invoice-number', 'invoice-number-field' ); ?>
        </form>
    </div>
</div>
