<?php

use function Epmp\ME\functions\render_label_buttons;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_filter( 'wcmp_vendor_dash_hidden_order_itemmeta', function( $list ){

	$list[] = 'method_label';
	$list[] = 'vendor_name';
	$list[] = 'package_qty';

	if( defined('EPMP_ME_TESTING') && EPMP_ME_TESTING ){
		return $list;
	}

	$list[] = '_delivery_time';
	$list[] = '_service_id';
	$list[] = '_company_id';
	$list[] = '_packages';
	$list[] = '_vendor_order_shipping_item_id';
	$list[] = '_invoice_number';

	return $list;
} );

add_action( 'epmp_mpme_init', function(){
	remove_filter( 'woocommerce_admin_order_actions', 'Epmp\ME\functions\render_label_buttons', 10, 2 );
} );

function epmp_mpme_wcmp_render_label_buttons( $actions, $order ){

	$suborders = get_wcmp_suborders( $order->get_id(), false, false );

	foreach( $suborders as $suborder ){
		$actions = render_label_buttons( $actions, wc_get_order( $suborder ) );
	}

	return $actions;

}

add_filter( 'woocommerce_admin_order_actions', 'epmp_mpme_wcmp_render_label_buttons', 10, 2 );

add_filter( 'wcmp_locate_template', 'epmp_mpme_woocommerce_locate_template', 10, 3 );

function epmp_mpme_wcmp_add_template_path ( $path ){
	return EPMP_MEWCMP_DIR . '/templates/';
}
add_filter( 'epmp_mpme_template_base_path', 'epmp_mpme_wcmp_add_template_path' );

add_action( 'wcmp_vendor_preview_tabs_post', function( $is_approved_vendor ){

	if( $is_approved_vendor ){
	?>
	<li>
		<a href="#vendor-melhorenvio">
			<span class="dashicons dashicons-thumbs-up"></span> <?php echo __('Melhor Envio', 'epmp-marketplace-melhorenvio'); ?>
		</a>
	</li>
	<?php
	}

} );

add_filter( 'woocommerce_screen_ids', function( $screen_ids ){
	return array_merge( $screen_ids, [ 'wcmp_page_vendors' ] );
} );

add_filter( 'epmp_mpme_remove_parent_orders_meta_boxes', function( $remove, $order ){

	if( $order->get_meta( 'has_wcmp_sub_order', true ) ){
		return true;
	}

	return $remove;

}, 10, 2 );
