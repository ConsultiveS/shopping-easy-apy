<?php
use const \Epmp\ME\Constants\{ DOCUMENT_TYPE_CPF, DOCUMENT_TYPE_CNPJ };
$fields = new class extends WCMp_WP_Fields {
	public function select_input($field) {
	    $field['class'] = isset($field['class']) ? $field['class'] : 'select short';
	    $field['value'] = isset($field['value']) ? $field['value'] : '';
	    $field['name'] = isset($field['name']) ? $field['name'] : $field['id'];

	    // Custom attribute handling
	    $custom_attributes = array();

	    if (!empty($field['custom_attributes']) && is_array($field['custom_attributes']))
	        foreach ($field['custom_attributes'] as $attribute => $value)
	            $custom_attributes[] = 'data-' . esc_attr($attribute) . '="' . esc_attr($value) . '"';

	    // attribute handling
	    $attributes = array();
	    $is_multiple = false;
	    if (!empty($field['attributes']) && is_array($field['attributes'])) {
	        foreach ($field['attributes'] as $attribute => $value) {
	            $attributes[] = esc_attr($attribute) . '="' . esc_attr($value) . '"';
	            if ($attribute == 'multiple') {
	                $is_multiple = true;
	                $field['name'] .= '[]';
	            }
	        }
	    }

	    $options = '';
	    foreach ($field['options'] as $key => $value) {
	    	if ($is_multiple) {
	    	    $options .= '<option value="' . esc_attr($key) . '"' . selected(in_array($key, (array) $field['value']), true, false) . '>' . esc_html($value) . '</option>';
	    	} else {
	    	    $options .= '<option value="' . esc_attr($key) . '" ' . selected(esc_attr($field['value']), esc_attr($key), false) . '>' . esc_html($this->string_wpml($value)) . '</option>';
	    	}
	    }

	    $field = $this->field_wrapper_start($field);

	    printf(
	            '<select id="%s" name="%s" class="%s" %s %s>%s</select>', esc_attr($field['id']), esc_attr($field['name']), esc_attr($field['class']), implode(' ', $custom_attributes), implode(' ', $attributes), $options
	    );

	    $this->field_wrapper_end($field);
	}
};
$vendor_config = $this->get_vendor_config( $vendor_id );

$vendor_shipping_zones = $vendor_config->get_shipping_zones();
$vendor_fixed_cost = $vendor_config->get_fixed_cost();
$vendor_percent_cost = $vendor_config->get_percent_cost();

?>
<div id="vendor-melhorenvio">
	<h2><?php esc_html_e( 'Melhor Envio', 'epmp-marketplace-melhorenvio' );?></h2>
	<?php
		$fields->checkbox_input(
			[
				'id' => '_me_vendor_enabled',
				'name' => '_me_vendor_enabled',
				'label' => __( 'Enable Melhor Envio', 'epmp-marketplace-melhorenvio' ),
				'value' => 'yes',
				'dfvalue' => $enabled,
				'class' => 'user-profile-fields regular-text',
				'desc' => __( 'Check if you want to use Melhor Envio shipping.', 'epmp-marketplace-melhorenvio' ),
			]
		);

		$this->render_vendor_token_field_html( $vendor_id, EPMP_MEWCMP_DIR . '/views/admin/html-admin-token-field.php' );
	?>
	<h2><?php esc_html_e( 'Shipping settings', 'epmp-marketplace-melhorenvio' );?></h2>
		<?php
		$fields->select_input(
			[
				'id' => '_me_vendor_shipping_zones',
				'name' => '_me_vendor_shipping_zones',
				'label' => __( 'Shipping zones', 'epmp-marketplace-melhorenvio' ),
				'class' => 'wc-enhanced-select',
				'value' => $vendor_shipping_zones,
				'options' => epmp_mpme_get_available_shipping_zones(),
				'attributes' => [ 'multiple' => 'multiple', 'style' => 'width:25rem;' ],
				'desc' => __( 'Select the shipping zones you want to cover. Leave it blank to use all available shipping zones.', 'epmp-marketplace-melhorenvio' ),
			]
		);

		$fields->select_input(
			[
				'id' => '_me_vendor_services',
				'name' => '_me_vendor_services',
				'label' => __( 'Services', 'epmp-marketplace-melhorenvio' ),
				'class' => 'wc-enhanced-select',
				'value' => $vendor_services,
				'options' => $services,
				'attributes' => [ 'multiple' => 'multiple', 'style' => 'width:25rem;' ],
				'desc' => __( 'Select the services you want to use for shipping.', 'epmp-marketplace-melhorenvio' ),
			]
		);

		$fields->text_input(
			[
				'id' => '_me_vendor_fixed_cost',
				'name' => '_me_vendor_fixed_cost',
				'label' => __( 'Additional fixed cost', 'epmp-marketplace-melhorenvio' ),
				'value' => $vendor_fixed_cost,
				'desc' => __( 'Cost to be added to the final shipping rate.', 'epmp-marketplace-melhorenvio' ),
			]
		);


		$fields->text_input(
			[
				'id' => '_me_vendor_percent_cost',
				'name' => '_me_vendor_percent_cost',
				'type' => 'number',
				'label' => __( 'Additional percent cost', 'epmp-marketplace-melhorenvio' ),
				'value' => $vendor_percent_cost,
				'desc' => __( 'Percentage to be added to the final shipping rate.', 'epmp-marketplace-melhorenvio' ),
			]
		);

		$fields->text_input(
			[
				'id' => '_me_vendor_additional_time',
				'name' => '_me_vendor_additional_time',
				'type' => 'number',
				'label' => __( 'Additional time', 'epmp-marketplace-melhorenvio' ),
				'value' => $vendor_additional_time,
				'desc' => __( 'Number of days to add to the delivery time.', 'epmp-marketplace-melhorenvio' ),
			]
		);

		$fields->checkbox_input(
			[
				'id' => '_me_vendor_receiver_only',
				'name' => '_me_vendor_receiver_only',
				'label' => __( 'Receiver only', 'epmp-marketplace-melhorenvio' ),
				'value' => 'yes',
				'dfvalue' => $receiver_only,
				'class' => 'user-profile-fields regular-text',
				'desc' => __( 'Check if you want the parcel to be delivered to the receiver.', 'epmp-marketplace-melhorenvio' ),
			]
		);

		$fields->checkbox_input(
			[
				'id' => '_me_vendor_receipt',
				'name' => '_me_vendor_receipt',
				'label' => __( 'Receipt', 'epmp-marketplace-melhorenvio' ),
				'value' => 'yes',
				'dfvalue' => $receipt,
				'class' => 'user-profile-fields regular-text',
				'desc' => __( 'Check if you want to be notified when the parcel is delivered.', 'epmp-marketplace-melhorenvio' ),
			]
		);
		?>

	<h2 id="melhor-envio-address"><?php esc_html_e( 'Melhor Envio Address', 'epmp-marketplace-melhorenvio' );?></h2>
	<?php

	$fields->text_input(
		[
			'id' => '_me_vendor_name',
			'name' => '_me_vendor_name',
			'label' => __( 'Name', 'epmp-marketplace-melhorenvio' ) . '*',
			'value' => $vendor_name,
			'attributes' => [ 'required' => 'required' ],
		]
	);

	$fields->text_input(
		[
			'id' => '_me_vendor_email',
			'name' => '_me_vendor_email',
			'label' => __( 'Email', 'epmp-marketplace-melhorenvio' ) . '*',
			'value' => $vendor_email,
			'attributes' => [ 'required' => 'required' ],
		]
	);

	$fields->text_input(
		[
			'id' => '_me_vendor_phone',
			'name' => '_me_vendor_phone',
			'label' => __( 'Phone', 'epmp-marketplace-melhorenvio' ) . '*',
			'value' => $vendor_phone,
			'attributes' => [ 'required' => 'required' ],
		]
	);

	$fields->select_input(
		[
			'id' => '_me_vendor_document_type',
			'name' => '_me_vendor_document_type',
			'label' => __( 'Document type', 'epmp-marketplace-melhorenvio' ) . '*',
			'class' => 'wc-enhanced-select',
			'options' => [
				DOCUMENT_TYPE_CPF  => __( 'Natural person', 'epmp-marketplace-melhorenvio' ),
				DOCUMENT_TYPE_CNPJ => __( 'Legal person', 'epmp-marketplace-melhorenvio' ),
			],
			'dfvalue' => (int) $vendor_document_type,
			'attributes' => [ 'required' => 'required' ],
			'desc' => __( 'Type of document of the sender', 'epmp-marketplace-melhorenvio' ),
			'title' => '',
		]
	);

	$fields->text_input(
		[
			'id' => '_me_vendor_document',
			'name' => '_me_vendor_document',
			'label' => __( 'Document', 'epmp-marketplace-melhorenvio' ) . '*',
			'value' => $vendor_document,
			'attributes' => [ 'required' => 'required' ],
			'desc' => __( 'Document of the sender; CPF if natural, CNPJ if legal', 'epmp-marketplace-melhorenvio' ),
		]
	);

	$fields->text_input(
		[
			'id' => '_me_vendor_address',
			'name' => '_me_vendor_address',
			'label' => __( 'Address', 'epmp-marketplace-melhorenvio' ) . '*',
			'value' => $vendor_address,
			'attributes' => [ 'required' => 'required' ],
		]
	);

	$fields->text_input(
		[
			'id' => '_me_vendor_complement',
			'name' => '_me_vendor_complement',
			'label' => __( 'Complement', 'epmp-marketplace-melhorenvio' ),
			'value' => $vendor_complement,
		]
	);

	$fields->text_input(
		[
			'id' => '_me_vendor_number',
			'name' => '_me_vendor_number',
			'label' => __( 'Number', 'epmp-marketplace-melhorenvio' ) . '*',
			'value' => $vendor_number,
			'attributes' => [ 'required' => 'required' ],
		]
	);

	$fields->text_input(
		[
			'id' => '_me_vendor_district',
			'name' => '_me_vendor_district',
			'label' => __( 'Neighborhood', 'epmp-marketplace-melhorenvio' ) . '*',
			'value' => $vendor_district,
			'attributes' => [ 'required' => 'required' ],
		]
	);

	$fields->text_input(
		[
			'id' => '_me_vendor_city',
			'name' => '_me_vendor_city',
			'label' => __( 'City', 'epmp-marketplace-melhorenvio' ) . '*',
			'value' => $vendor_city,
			'attributes' => [ 'required' => 'required' ],
		]
	);

	$fields->select_input(
		[
			'id' => '_me_vendor_state',
			'name' => '_me_vendor_state',
			'label' => __( 'State', 'epmp-marketplace-melhorenvio' ) . '*',
			'options' => WC()->countries->get_states( 'BR' ),
			'value' => $vendor_state,
			'attributes' => [ 'required' => 'required' ],
		]
	);

	$fields->text_input(
		[
			'id' => '_me_vendor_postal_code',
			'name' => '_me_vendor_postal_code',
			'label' => __( 'Postcode', 'epmp-marketplace-melhorenvio' ) . '*',
			'value' => $vendor_postal_code,
			'attributes' => [ 'required' => 'required' ],
		]
	);

	$fields->select_input(
		[
			'id' => '_me_vendor_agency',
			'name' => '_me_vendor_agency',
			'label' => __( 'Agency', 'epmp-marketplace-melhorenvio' ),
			'options' => wp_list_pluck( $agency_lists, 'description', 'id' ),
			'value' => $vendor_agency,
			'desc' => __( 'Select the JadLog agency from which you will send your packages. Leave it blank if you are not going to use JadLog shipping.', 'epmp-marketplace-melhorenvio' ),
		]
	);

	?>
</div>
<script>
	jQuery( function( $ ){
		$('#_me_vendor_fixed_cost').maskDecimals();
	} );
</script>
