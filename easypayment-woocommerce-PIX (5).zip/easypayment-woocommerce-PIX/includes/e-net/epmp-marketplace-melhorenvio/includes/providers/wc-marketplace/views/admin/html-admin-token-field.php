<h2><?php esc_html_e( 'Melhor Envio Token', 'epmp-marketplace-melhorenvio' );?></h2>
<?php
( new WCMp_WP_Fields )->textarea_input(
    [
        'id' => '_me_vendor_token',
        'name' => '_me_vendor_token',
        'label' => __( 'Token', 'epmp-marketplace-melhorenvio' ),
        'value' => $vendor_token,
    ]
);
