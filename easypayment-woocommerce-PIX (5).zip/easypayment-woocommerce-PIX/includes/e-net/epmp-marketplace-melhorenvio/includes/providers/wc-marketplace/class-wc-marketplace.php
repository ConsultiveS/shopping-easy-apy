<?php

use function Epmp\ME\functions\get_labels_generation_allowed_statuses;
use function Epmp\ME\functions\is_invoice_required_for_item;
use function Epmp\ME\functions\is_labelling_available_for_item;
use function Epmp\ME\functions\is_melhorenvio_method;
use function Epmp\ME\functions\item_can_bypass_invoice;
use function Epmp\ME\functions\save_product_fields;
/**
* Encapsulates functionalities of WC Marketplace by Dual Cube <https://wordpress.org/plugins/dc-woocommerce-multi-vendor/>
*
* @author  Luis Eduardo Braschi <http://art-idesenvolvimento.com.br>
*
*/
class Epmp_ME_WC_Marketplace_Provider extends Epmp_MPME_Abstract_Vendors_Provider implements Epmp_MPME_Shipping_Processor {

	private $shipping_link;

	public function __construct() {

		if( !class_exists( 'WCMp' ) ) {

			$this->provider_not_found_message = __( 'The plugin "WC Marketplace" could not be found. Please, install and activate it before registering this adapter.', 'epmp-marketplace-melhorenvio' );

			add_action( 'admin_notices', [ $this, 'provider_not_found' ] );
			$this->is_active = false;

		} else {

			add_action( 'init', [ $this, 'override_hooks' ] );

			add_filter( 'wcmp_my_account_my_orders_actions', [ $this, 'add_label_actions' ], null, 2 );
			add_action( 'template_redirect', [ $this, 'save_post_data' ] );

			add_action( 'wcmp_vendor_dashboard_vendor-orders_endpoint', [ $this, 'add_invoice_fields_template' ]);

			add_action( 'personal_options_update', [ $this, 'save_vendor_fields' ] );
			add_action( 'edit_user_profile_update', [ $this, 'save_vendor_fields' ] );

			// Admin fields.
			add_action( 'wcmp_vendor_preview_tabs_form_post', [ $this, 'add_admin_vendor_fields' ] );
			add_action( 'wcmp_vendor_details_update', [ $this, 'save_admin_vendor_fields' ], 10, 2 );

			// Front-end  fields.
			add_action( 'other_exta_field_dcmv', [ $this, 'add_vendor_fields' ] );
			add_action( 'before_wcmp_vendor_dashboard', [ $this, 'save_vendor_fields' ] );

			// Product shipping tab.
			add_action( 'wcmp_afm_product_options_shipping', [ $this, 'add_product_shipping_fields' ], 10 );
			add_action( 'wcmp_process_product_object', [ $this, 'save_product_meta' ], 10 );

			add_action( 'wp_ajax_mark-item-shipped', [ $this, 'mark_item_shipped' ] );

			add_action( 'wp_ajax_load-vendor-address', [ $this, 'load_address_from_store_config' ] );

			add_action( 'wcmp_init', [ $this, 'add_late_hooks' ] );

			add_action( 'wp_head', [ $this, 'label_actions_css' ] );

		}

	}

	public function is_vendor( $user_id ){
		return is_user_wcmp_vendor( $user_id );
	}

	public function is_vendor_dashboard(){
		return wc_post_content_has_shortcode( 'wcmp_vendor' );
	}

	public function get_shipping_recipient(){
		$fee_recipient_is_vendor = 'Enable' === get_wcmp_vendor_settings( 'give_shipping', 'payment' );
		return $fee_recipient_is_vendor ? 'vendor' : 'admin';
	}

	public function get_vendor_id_from_product( $id ) {

		$variation = wc_get_product( $id );

		if ( $variation->get_parent_id() ){
			$id = $variation->get_parent_id();
		}

		$vendor = get_wcmp_product_vendors( $id );

		if( false === $vendor ) {
			$message = sprintf( __( 'Product with id %d has no vendor assigned to it.', 'epmp-marketplace-melhorenvio' ), $id );
			throw new Exception( $message );
		}

		return $vendor->user_data->data->ID;
	}

	public function get_vendor_postcode( $vendor_id ){

		$post_code = get_user_meta( $vendor_id, '_vendor_postcode', true );

		if( false === $post_code ) {
			$message = sprintf( __( 'Vendor with id %d has no post code.', 'epmp-marketplace-melhorenvio' ), $vendor_id );
			throw new Exception( $message );
		}

		return $post_code;
	}

	public function get_vendor_name( $id ){
		$vendor = get_wcmp_vendor( $id );
		return $vendor ? $vendor->page_title : '';
	}

	public function get_order_comission_by_vendor( $order_id, $vendor_id ){
		return 0;
	}

	/**
	 * Removing addition of WTF vendor_id meta
	 * @return void
	 */
	public function override_hooks(){
		global $WCMp;
		add_action( 'woocommerce_checkout_create_order_shipping_item', [ $this, 'add_package_qty' ], 99, 3 );
		remove_action( 'woocommerce_checkout_create_order_shipping_item',
						[ $WCMp->frontend, 'add_meta_date_in_shipping_package' ], 10 );
	}

	public function add_late_hooks(){

		global $WCMp;

		$WCMp->vendor_dashboard->wcmp_add_dashboard_widget(
			'epmp_me_show_balance',
			__( 'Melhor Envio balance', 'epmp-marketplace-melhorenvio' ),
			[ $this, 'show_me_api_info' ]
		);

	}

	public function add_package_qty( $item, $package_key, $package ){
		$vendor_id = ( isset( $package['vendor_id'] ) && $package['vendor_id'] ) ? $package['vendor_id'] : $package_key;
		$item->add_meta_data('vendor_id', $vendor_id, true);
		$package_qty = array_sum( wp_list_pluck( $package['contents'], 'quantity' ) );
		$item->add_meta_data( 'package_qty', $package_qty, true );
		do_action( 'wcmp_add_shipping_package_meta_data' );
	}

	/**
	 * Add shipping items to suborders
	 * @param int $vendor_order_id
	 * @param int $args
	 */
	public function add_methods_to_suborders( $vendor_order_id, $args ){

		$vendor_order = wc_get_order( $vendor_order_id );

		$native_packages_ids = wc_get_order( $vendor_order_id )->get_shipping_methods();

		foreach( array_keys( $native_packages_ids ) as $item ){
			$vendor_order->remove_item( $item );
			$vendor_order->save();
		}

		$parent_order_id = $args['order_id'];
		$parent_order = wc_get_order( $parent_order_id );
		$vendor_id = $args['vendor_id'];

		$packages = wc_get_order( $parent_order_id )->get_shipping_methods();

		$vendor_packages = array_filter( $packages, function( $package ) use ( $vendor_id ){
			return ( int ) $package->get_meta( 'vendor_id' ) === ( int ) $vendor_id;
		} );

		foreach( $vendor_packages as $shipping_rate ){

			$item = new WC_Order_Item_Shipping();

			$item->set_props(
					[
						'method_title' => $shipping_rate->get_method_title(),
						'method_id'    => $shipping_rate->get_method_id(),
						'instance_id'  => $shipping_rate->get_instance_id(),
						'total'        => $shipping_rate->get_total(),
						'taxes'        => $shipping_rate->get_taxes(),
					]
			);


			foreach ( $shipping_rate->get_meta_data() as $meta_data ) {
				$item->add_meta_data( $meta_data->key, $meta_data->value, true );
			}

			/**
			 * Action hook to adjust item before save.
			 *
			 * @since 3.4.0
			 */
			do_action( 'wcmp_vendor_create_order_shipping_item', $item, $vendor_id, $shipping_rate, $parent_order );

			$vendor_order->add_item( $item );

			$vendor_order->save();

		}

	}

	public function add_label_actions( $actions, $order_id ){

		$order = wc_get_order( $order_id );

		$labels_generation_allowed_statuses = get_labels_generation_allowed_statuses();

		if( !$order->has_status( $labels_generation_allowed_statuses ) ||
			!epmp_mpme_vendor_can_generate_labels( (int) get_current_user_id() )
		){
			return $actions;
		}

		$me_actions = [];

		foreach( $order->get_shipping_methods() as $shipping_item ){

			$item_id = $shipping_item->get_id();

			if(
				!is_melhorenvio_method( $shipping_item->get_method_id() ) ||
				( ( (int) $shipping_item->get_meta( 'vendor_id' ) !== (int) get_current_user_id() ) ) ||
				!is_labelling_available_for_item( $item_id )
			){
				continue;
			}

			unset( $actions['mark_ship'] );

			$vendor_id = (int) get_current_user_id();
			$label_data = wc_get_order_item_meta( $item_id, '_epmp_me_label_data' );

			if(
				empty( $label_data ) &&
				epmp_mpme_is_invoice_required_for_vendor( $vendor_id ) &&
				is_invoice_required_for_item( $item_id )
			){

				$me_actions['add_invoice_' . $item_id] = [
					'url' => '#',
					'title' => __( 'Add invoice number', 'epmp-marketplace-melhorenvio' ),
					'action' => 'add-invoice-number',
					'icon' => 'ico-billing-icon action-icon',
					'item_id' => $item_id,
					'external' => false,
				];

				if( item_can_bypass_invoice( $item_id ) ){
					$me_actions['buy_labels_' . $item_id] = [
						'url' => wp_nonce_url(
							admin_url(
								'admin-ajax.php?action=buy-labels-for-item&item_id=' . $item_id
							),
							'epmp-me-buy-labels-for-item'
						),
						'title' => __( 'Buy labels non-commercially', 'epmp-melhorenvio' ),
						'action' => 'buy-labels',
						'icon' => 'ico-cart-icon action-icon',
						'external' => false,
					];
				}

				continue;
			}

			if( empty( $label_data ) ){

				$me_actions['add_invoice_' . $item_id] = [
					'url' => '#',
					'title' => __( 'Edit invoice number', 'epmp-marketplace-melhorenvio' ),
					'action' => 'add-invoice-number',
					'icon' => 'ico-billing-icon action-icon',
					'item_id' => $item_id,
					'external' => false,
					'invoice_key' => wc_get_order_item_meta( $item_id, '_invoice_number', true ),
				];

				$me_actions['buy_labels_' . $item_id] = [
					'url' => wp_nonce_url(
						admin_url(
							'admin-ajax.php?action=buy-labels-for-item&item_id=' . $item_id
						),
						'epmp-me-buy-labels-for-item'
					),
					'title' => __( 'Buy labels', 'epmp-melhorenvio' ),
					'action' => 'buy-labels',
					'icon' => 'ico-cart-icon action-icon',
					'external' => false,
				];
			} elseif(
				( isset( $label_data['preview'] ) && $label_data['preview'] )
				|| isset( $label_data['print_link'], $label_data['print_link']->message)
				) {

				$me_actions['generate_labels_' . $item_id] = [
					'url' => wp_nonce_url(
						admin_url(
							'admin-ajax.php?action=generate-labels-for-item&item_id=' . $item_id
						),
						'epmp-me-generate-labels-for-item'
					),
					'title' => __( 'Generate labels', 'epmp-melhorenvio' ),
					'action' => 'generate-labels',
					'icon' => 'ico-shipping-action-icon action-icon',
					'external' => false,
				];

				foreach( $label_data['orders'] as $key => $me_order ){
					if( isset( $me_order['preview_link']->url ) ){
						$me_actions['preview_labels_' . $key] = [
							'url' => $me_order['preview_link']->url,
							'title' => __( 'Preview labels', 'epmp-melhorenvio' ),
							'action' => 'preview-labels',
							'icon' => 'ico-edit-pencil-icon action-icon external',
							'external' => true,
						];
					} elseif( isset( $me_order['error'] ) || isset( $me_order['preview_link']->error ) ){

						$error = $me_order['error'] ?? $me_order['preview_link']->error;

						$me_actions['generate_labels_' . $item_id]['name'] = wp_strip_all_tags( $error );
						$me_actions['generate_labels_' . $item_id]['class'] = ' has-error';

					}
				}


			} elseif( isset( $label_data['preview'], $label_data['print_link'], $label_data['print_link']->url ) ) {

				$me_actions['mark_shipped_' . $item_id ] = [
					'url' => wp_nonce_url(
						admin_url(
							'admin-ajax.php?action=mark-item-shipped&item_id=' . $item_id
						),
						'epmp-me-mark-item-shipped'
					),
					'title' => __( 'Mark as shipped', 'epmp-marketplace-melhorenvio' ),
					'action' => 'mark-shipped',
					'icon' => 'ico-shippingnew-icon action-icon',
					'external' => false,
				];

				$me_actions['print_labels_' . $item_id] = [
					'url' => $label_data['print_link']->url,
					'title' => __( 'Print labels', 'epmp-melhorenvio' ),
					'action' => 'print-labels',
					'icon' => 'ico-shipping-icon action-icon external',
					'external' => true,
				];

			}
		}

		$this->action_html = '';

		foreach ($me_actions as $key => $action) {
			$this->action_html .= sprintf(
								'<a id="%s" class="%s %s" href="%s" title="%s" data-item_id="%s" data-invoice_key="%s"><i class="wcmp-font %s"></i></a> ',
								$key,
								"me-action me-action-{$action['action']}",
								$action['class'] ?? '',
								$action['url'],
								$action['title'],
								$action['item_id'] ?? '',
								$action['invoice_key'] ?? '',
								$action['icon'],
							);
		}

		add_filter( 'wcmp_vendor_orders_row_action_html', [ $this, 'merge_action_buttons' ] );

		return $actions;

	}

	public function merge_action_buttons( $original_html ){

		$html = $original_html . $this->action_html;
		remove_filter( 'wcmp_vendor_orders_row_action_html', [ $this, __FUNCTION__ ] );

		return $html;
	}

	public function label_actions_css(){
		?>
		<style>
			.me-action i {
			    background-color: #0550a0 !important;
			    color: #f3b331 !important;
			    padding: 5px;
			    font-weight: bold;
			}
			.me-action.has-error i {
				position: relative;
			}
			.me-action.has-error i:after{
			    content: "\e946";
			    display: block;
			    position: absolute;
			    color: red;
			    left: 100%;
			    border-radius: 50%;
			    background-color: #fff;
			    top: 100%;
			    font-size: 10px;
			    font-weight: bolder;
			}
		</style>
		<?php
	}

	/**
	 * Will add fields to user dashborad in admin panel
	 * @return array
	 */
	public function add_admin_vendor_fields( $fields ){

		$vendor = get_wcmp_vendor( absint( $_GET['ID'] ?? 0 ) );

		if( !$vendor ){
			return;
		}

		$vendor_id = $vendor->id;

		$this->render_vendor_address_fields_html( $vendor_id, EPMP_MEWCMP_DIR . '/views/admin/html-admin-address-fields.php' );

	}

	public function save_admin_vendor_fields( $post_data, $vendor ){
		$this->save_vendor_fields( $vendor->get_id() );
	}

	/**
	 * Will add fields to user dashborad in th font-end
	 * @return array
	 */
	public function add_vendor_fields( $fields ){

		$vendor = get_wcmp_vendor( get_current_vendor_id() );

		if( !$vendor ){
			return;
		}

		$vendor_id = $vendor->id;

		$this->render_vendor_token_field_html( $vendor_id, EPMP_MEWCMP_DIR . '/views/html-token-field.php' );
		$this->render_vendor_address_fields_html( $vendor_id, EPMP_MEWCMP_DIR . '/views/html-address-fields.php' );

	}

	/**
	 * Save vendor's data
	 * @param  int|string $vendor_id
	 * @return void
	 */
	public function save_vendor_fields( $vendor_id = null ){

		global $WCMp;

		if (
			$_SERVER['REQUEST_METHOD'] === 'POST' &&
			( isset($_POST['wcmp_vendor_submit']) || 'storefront' === $WCMp->endpoints->get_current_endpoint() )
		) {

			if( empty( $vendor_id ) ){
				$vendor_id = get_current_vendor_id();
			}

			update_user_meta( $vendor_id, '_me_vendor_shipping_zones', $_POST['_me_vendor_shipping_zones'] ?? [] );
			update_user_meta( $vendor_id, '_me_vendor_services', $_POST['_me_vendor_services'] ?? null );

			$errors = epmp_mpme_validate_vendor_fields();

			if( $errors && !is_admin() ){
				array_map( 'wc_add_notice', $errors, [ 'error' ] );
			}

			epmp_mpme_update_user_meta( $vendor_id );

		}
	}

	/**
	 * Will add tracking fields temaplate to front-end modal
	 */
	public function add_invoice_fields_template(){
		include_once EPMP_MEWCMP_DIR . '/views/html-tmpl-invoice-modal.php';
	}

	public function update_tracking_info( $widget ){

		// Keep from marking as shipped if "other methods" fields empty
		if ( isset( $_POST['wcmp-submit-mark-as-ship'] ) ) {
			unset( $_POST['wcmp-submit-mark-as-ship'] );
		}

		return $widget;

	}

	public function mark_as_shipped( $order_id, $vendor_id = null, $package_id = null ) {
		$vendor = get_wcmp_vendor( $vendor_id );

		$label_data = wc_get_order_item_meta( $package_id, '_epmp_me_label_data' );

		$tracking_code = array_column( array_column( $label_data['orders'], 'tracking_code' ), 'tracking' );
		$tracking_url = $this->get_tracking_code_url( join( ', ', $tracking_code ) );

		$vendor->set_order_shipped( $order_id, join( ', ', $tracking_code ), $tracking_url );

		$this->add_mark_as_shipped_note( $order_id, $vendor_id, $package_id );
	}

	public function mark_item_shipped(){

		if ( !is_admin() ) {
			die;
		}

		if ( !check_admin_referer( 'epmp-me-mark-item-shipped' ) ) {
			wp_die( esc_html__( 'You do not have permission to change this order', 'epmp-marketplace-melhorenvio' ) );
		}

		$item_id = !empty( $_GET['item_id'] ) ? (int) $_GET['item_id'] : 0;

		if ( !$item_id ) {
			die;
		}

		$shipping_item = new \WC_Order_Item_Shipping( $item_id );

		$vendor_id = (int) $shipping_item->get_meta( 'vendor_id' );

		if ( $vendor_id !== (int) get_current_user_id() ) {
			wp_die( esc_html__( 'You do not have permission to change this order', 'epmp-marketplace-melhorenvio' ) );
		}

		$order = wc_get_order( $shipping_item->get_order_id() );
		$order->update_status( 'shipped-out' );

		$this->mark_as_shipped( $order->get_id(), $vendor_id, $item_id );

		wp_safe_redirect( wp_get_referer() );
		die;

	}

	private function add_mark_as_shipped_note( $order_id, $vendor_id, $package_id ){

		$order = wc_get_order( $order_id );
		$shippers[] = $vendor_id;
		$vendor_name = $this->get_vendor_name( $vendor_id );

		$message = sprintf( __( '%s added shipping info.', 'epmp-marketplace-melhorenvio' ), $vendor_name );

		$label_data = wc_get_order_item_meta( $package_id, '_epmp_me_label_data' );

		if( !isset( $label_data['orders'] ) ){
			return;
		}

		$tracking_code = join( ', ', epmp_mpme_get_tracking_code_list( $label_data ) );

		ob_start();
		include_once EPMP_MEWCMP_DIR . '/views/html-order-shipping-note.php';
		$html = ob_get_clean();

		$order->add_order_note( $html, true );

	}

	/**
	 * Get tracking code url.
	 *
	 * @param  string $tracking_code Tracking code.
	 *
	 * @return string
	 */
	public function get_tracking_code_url( $tracking_code ) {
		$url = sprintf(
			'https://www.melhorrastreio.com.br/rastreio/%1$s',
			$tracking_code
		);

		return $url;
	}

	public function save_post_data(){
		if( wp_verify_nonce( $_POST['invoice-number-field'] ?? '', 'add-invoice-number' ) ){
			Epmp\ME\Admin\Orders::save();
		}
	}

	public function load_address_from_store_config(){

		if(
			!$this->is_vendor( get_current_user_id() ) ||
			!wp_verify_nonce( $_GET['load-vendor-address-field'], 'load-vendor-address' )
		){
			wp_send_json_error();
			wp_die();
		}

		$vendor_id = get_current_user_id();

		$vendor = get_wcmp_vendor( $vendor_id );
		$user_data = $vendor->user_data->data;

		$address = apply_filters(
			'epmp_mpme_load_vendor_address',
			[
				'_me_vendor_name'          => $vendor->page_title ?? '',
				'_me_vendor_phone'         => get_user_meta( $vendor_id, '_vendor_phone', true ),
				'_me_vendor_email'         => $user_data->user_email ?? '',
				'_me_vendor_address'       => get_user_meta( $vendor_id, '_vendor_address_1', true ),
				'_me_vendor_complement'    => get_user_meta( $vendor_id, '_vendor_address_2', true ),
				'_me_vendor_number'        => get_user_meta( $vendor_id, '_vendor_number', true ),
				'_me_vendor_district'      => get_user_meta( $vendor_id, '_vendor_district', true ),
				'_me_vendor_city'          => get_user_meta( $vendor_id, '_vendor_city', true ),
				'_me_vendor_state'         => get_user_meta( $vendor_id, '_vendor_state', true ),
				'_me_vendor_postal_code'   => get_user_meta( $vendor_id, '_vendor_postcode', true ),
			],
			$vendor_id
		);

		wp_send_json_success( $address );
		wp_die();
	}

	public function add_product_shipping_fields( $product_id ){
		$additional_time = get_post_meta( $product_id, '_epmp_me_additional_time', true );
		include_once EPMP_MEWCMP_DIR . '/views/html-product-shipping-option-field.php';
	}

	public function save_product_meta( $product ){
		save_product_fields( $product->get_id(), $_POST );
	}

	public function show_me_api_info(){
		$this->load_me_user_info_template( get_current_user_id(), EPMP_MEWCMP_DIR . '/views/html-me-api-info.php' );
	}

}
