<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Art-i WC Marketplace root
 */
define( 'EPMP_MEWCMP_DIR', dirname( __FILE__ ));

function epmp_mpme_wcmp_scripts(){
    if( wc_post_content_has_shortcode( 'wcmp_vendor' ) ){
        $package_url = plugin_dir_url( __FILE__ );
        $suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
        $dashboard_scripts = $package_url . 'assets/dashboard' . $suffix . '.js';
        wp_enqueue_script(
        	'epmp-mpme-wcmp-dashboard',
        	$dashboard_scripts,
        	[ 'jquery', 'wp-util', 'selectWoo', 'jquery-mask-decimals', 'epmp-mpme-dashboard' ],
        	'1.4.4'
        );

        wp_enqueue_style( 'select2' );
        wp_enqueue_script( 'selectWoo' );
		wp_enqueue_script( 'jquery-mask-decimals' );

        wp_enqueue_script( 'epmp-mpme-dashboard' );

    }

}
add_action( 'wp_enqueue_scripts', 'epmp_mpme_wcmp_scripts' );

function epmp_mpme_wcmp_admin_scripts(){
	if( 'wcmp_page_vendors' === get_current_screen()->id ){
		wp_enqueue_script( 'jquery-mask-decimals' );
	}
}

add_action( 'admin_enqueue_scripts', 'epmp_mpme_wcmp_admin_scripts' );

include_once 'class-wc-marketplace.php';
include_once 'wc-marketplace-functions.php';
