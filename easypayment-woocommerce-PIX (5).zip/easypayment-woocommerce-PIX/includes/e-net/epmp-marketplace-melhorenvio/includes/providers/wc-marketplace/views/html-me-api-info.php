<div class="panel-content-padding">
	<p><?php echo $formatted_balance;?></p>
	<?php if( $formatted_token_expiry ):?>
		<p><?php echo $formatted_token_expiry;?></p>
	<?php endif;?>
</div>
