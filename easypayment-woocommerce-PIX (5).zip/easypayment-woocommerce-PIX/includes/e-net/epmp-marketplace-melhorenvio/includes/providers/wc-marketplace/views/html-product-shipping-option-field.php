<div class="form-group">
    <label class="control-label col-sm-3 col-md-3" for="_epmp_me_additional_time"><?php _e( 'Additional time', 'epmp-marketplace-melhorenvio' ); ?></label>
    <div class="col-md-6 col-sm-9">
        <input class="form-control" type="text" id="_epmp_me_additional_time" name="_epmp_me_additional_time" value="<?php echo esc_attr( $additional_time ); ?>" >
        <span class="form-text"><?php __('Number of days to add to the delivery time.', 'epmp-marketplace-melhorenvio' ); ?></span>
    </div>
</div>
