<div class="panel panel-default pannel-outer-heading">
    <div class="panel-heading">
        <h3><?php esc_html_e( 'Melhor Envio', 'epmp-marketplace-melhorenvio' );?></h3>
    </div>
    <div class="panel-body panel-content-padding form-horizontal">
    <?php
    ( new WCMp_Frontend_WP_Fields )->checkbox_input(
			[
				'id' => '_me_vendor_enabled',
				'name' => '_me_vendor_enabled',
				'label' => __( 'Enable Melhor Envio', 'epmp-marketplace-melhorenvio' ),
				'value' => 'yes',
				'dfvalue' => $this->is_me_enabled( $vendor_id ),
				'class' => 'user-profile-fields regular-text',
				'desc' => __( 'Check if you want to use Melhor Envio shipping.', 'epmp-marketplace-melhorenvio' ),
			]
		);
    ?>
    </div>
</div>

<div class="panel panel-default pannel-outer-heading">
    <div class="panel-heading">
        <h3><?php esc_html_e( 'Melhor Envio Token', 'epmp-marketplace-melhorenvio' );?></h3>
    </div>
    <div class="panel-body panel-content-padding form-horizontal">
	<?php do_action( 'epmp_mpme_before_wcmp_foken_field', $vendor_id ); ?>
    <?php
    ( new WCMp_Frontend_WP_Fields )->textarea_input(
        [
            'id' => '_me_vendor_token',
            'name' => '_me_vendor_token',
            'label' => __( 'Token', 'epmp-marketplace-melhorenvio' ),
            'value' => $vendor_token,
        ]
    );
    ?>
	<?php do_action( 'epmp_mpme_after_wcmp_foken_field', $vendor_id ); ?>
    </div>
</div>
