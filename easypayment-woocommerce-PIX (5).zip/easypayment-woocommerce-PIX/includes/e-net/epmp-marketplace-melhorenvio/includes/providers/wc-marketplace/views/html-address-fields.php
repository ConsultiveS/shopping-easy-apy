<?php
use function Epmp\ME\functions\{ get_companies_with_agencies, get_company_name_by_id };
use const \Epmp\ME\Constants\{ DOCUMENT_TYPE_CPF, DOCUMENT_TYPE_CNPJ };

$fields = new WCMp_Frontend_WP_Fields;

$vendor_config = $this->get_vendor_config( $vendor_id );

$vendor_shipping_zones = $vendor_config->get_shipping_zones();
$vendor_fixed_cost = $vendor_config->get_fixed_cost();
$vendor_percent_cost = $vendor_config->get_percent_cost();

$vendor_agencies = $vendor_config->get_agencies();

?>
<div class="panel panel-default pannel-outer-heading">
	<div class="panel-heading">
		<h3 id="melhor-envio"><?php esc_html_e( 'Shipping settings', 'epmp-marketplace-melhorenvio' );?></h3>
	</div>
	<div class="panel-body panel-content-padding form-horizontal">
		<?php do_action( 'epmp_mpme_before_wcmp_shipping_fields', $vendor_id ); ?>
		<?php
		$fields->select_input(
			[
				'id' => '_me_vendor_shipping_zones',
				'name' => '_me_vendor_shipping_zones',
				'label' => __( 'Shipping zones', 'epmp-marketplace-melhorenvio' ),
				'value' => $vendor_shipping_zones,
				'options' => epmp_mpme_get_available_shipping_zones(),
				'attributes' => [ 'multiple' => 'multiple' ],
				'desc' => __( 'Select the shipping zones you want to cover. Leave it blank to use all available shipping zones.', 'epmp-marketplace-melhorenvio' ),
			]
		);

		$fields->select_input(
			[
				'id' => '_me_vendor_services',
				'name' => '_me_vendor_services',
				'label' => __( 'Services', 'epmp-marketplace-melhorenvio' ),
				'value' => $vendor_services,
				'options' => $services,
				'attributes' => [ 'multiple' => 'multiple' ],
				'desc' => __( 'Select the services you want to use for shipping.', 'epmp-marketplace-melhorenvio' ),
			]
		);


		$fields->text_input(
			[
				'id' => '_me_vendor_fixed_cost',
				'name' => '_me_vendor_fixed_cost',
				'label' => __( 'Additional fixed cost', 'epmp-marketplace-melhorenvio' ) . ' (R$)',
				'value' => $vendor_fixed_cost,
				'desc' => __( 'Cost to be added to the final shipping rate.', 'epmp-marketplace-melhorenvio' ),
			]
		);


		$fields->text_input(
			[
				'id' => '_me_vendor_percent_cost',
				'name' => '_me_vendor_percent_cost',
				'type' => 'number',
				'label' => __( 'Additional percent cost', 'epmp-marketplace-melhorenvio' ) . ' (%)',
				'value' => $vendor_percent_cost,
				'desc' => __( 'Percentage to be added to the final shipping rate.', 'epmp-marketplace-melhorenvio' ),
			]
		);

		$fields->text_input(
			[
				'id' => '_me_vendor_additional_time',
				'name' => '_me_vendor_additional_time',
				'type' => 'number',
				'label' => __( 'Additional time', 'epmp-marketplace-melhorenvio' ),
				'value' => $vendor_additional_time,
				'desc' => __( 'Number of days to add to the delivery time.', 'epmp-marketplace-melhorenvio' ),
			]
		);

		$fields->checkbox_input(
			[
				'id' => '_me_vendor_receiver_only',
				'name' => '_me_vendor_receiver_only',
				'label' => __( 'Receiver only', 'epmp-marketplace-melhorenvio' ),
				'value' => 'yes',
				'dfvalue' => $receiver_only,
				'class' => 'user-profile-fields regular-text',
				'desc' => __( 'Check if you want the parcel to be delivered to the receiver.', 'epmp-marketplace-melhorenvio' ),
			]
		);

		$fields->checkbox_input(
			[
				'id' => '_me_vendor_receipt',
				'name' => '_me_vendor_receipt',
				'label' => __( 'Receipt', 'epmp-marketplace-melhorenvio' ),
				'value' => 'yes',
				'dfvalue' => $receipt,
				'class' => 'user-profile-fields regular-text',
				'desc' => __( 'Check if you want to be notified when the parcel is delivered.', 'epmp-marketplace-melhorenvio' ),
			]
		);
		?>
		<?php do_action( 'epmp_mpme_after_wcmp_shipping_fields', $vendor_id ); ?>
	</div>
</div>
<div class="panel panel-default pannel-outer-heading">
	<div class="panel-heading">
		<h3 id="melhor-envio-address"><?php esc_html_e( 'Melhor Envio Address', 'epmp-marketplace-melhorenvio' );?></h3>
	</div>
	<div class="panel-body panel-content-padding form-horizontal">
		<div class="form-group">
			<div class="col-sm-12">
				<button type="button" id="load-vendor-address" class="btn btn-default">
					<?php _e( 'Load address from config', 'epmp-marketplace-melhorenvio' ); ?>
				</button>
			</div>
			<?php wp_nonce_field( 'load-vendor-address', 'load-vendor-address-field' ); ?>
		</div>
		<?php do_action( 'epmp_mpme_before_wcmp_address_fields', $vendor_id ); ?>
		<?php

		$fields->text_input(
			[
				'id' => '_me_vendor_name',
				'name' => '_me_vendor_name',
				'label' => __( 'Name', 'epmp-marketplace-melhorenvio' ) . '*',
				'value' => $vendor_name,
				'attributes' => [ 'required' => 'required' ],
			]
		);

		$fields->text_input(
			[
				'id' => '_me_vendor_email',
				'name' => '_me_vendor_email',
				'label' => __( 'Email', 'epmp-marketplace-melhorenvio' ) . '*',
				'value' => $vendor_email,
				'attributes' => [ 'required' => 'required' ],
			]
		);

		$fields->text_input(
			[
				'id' => '_me_vendor_phone',
				'name' => '_me_vendor_phone',
				'label' => __( 'Phone', 'epmp-marketplace-melhorenvio' ) . '*',
				'value' => $vendor_phone,
				'attributes' => [ 'required' => 'required' ],
			]
		);

		$fields->radio_input(
			[
				'id' => '_me_vendor_document_type',
				'name' => '_me_vendor_document_type',
				'label' => __( 'Document type', 'epmp-marketplace-melhorenvio' ) . '*',
				'options' => [
					DOCUMENT_TYPE_CPF  => __( 'Natural person', 'epmp-marketplace-melhorenvio' ),
					DOCUMENT_TYPE_CNPJ => __( 'Legal person', 'epmp-marketplace-melhorenvio' ),
				],
				'dfvalue' => (int) $vendor_document_type,
				'attributes' => [ 'required' => 'required' ],
				'desc' => __( 'Type of document of the sender', 'epmp-marketplace-melhorenvio' ),
				'title' => '',
			]
		);

		$fields->text_input(
			[
				'id' => '_me_vendor_document',
				'name' => '_me_vendor_document',
				'label' => __( 'Document', 'epmp-marketplace-melhorenvio' ) . '*',
				'value' => $vendor_document,
				'attributes' => [ 'required' => 'required' ],
				'desc' => __( 'Document of the sender; CPF if natural, CNPJ if legal', 'epmp-marketplace-melhorenvio' ),
			]
		);

		$fields->text_input(
			[
				'id' => '_me_vendor_cnae',
				'name' => '_me_vendor_cnae',
				'label' => __( 'CNAE', 'epmp-marketplace-melhorenvio' ),
				'value' => $vendor_cnae,
				'desc' => __( 'The CNAE code is used by LATAM when you send using CNPJ.', 'epmp-marketplace-melhorenvio' ),
			]
		);

		$fields->text_input(
			[
				'id' => '_me_vendor_address',
				'name' => '_me_vendor_address',
				'label' => __( 'Address', 'epmp-marketplace-melhorenvio' ) . '*',
				'value' => $vendor_address,
				'attributes' => [ 'required' => 'required' ],
			]
		);

		$fields->text_input(
			[
				'id' => '_me_vendor_complement',
				'name' => '_me_vendor_complement',
				'label' => __( 'Complement', 'epmp-marketplace-melhorenvio' ),
				'value' => $vendor_complement,
			]
		);

		$fields->text_input(
			[
				'id' => '_me_vendor_number',
				'name' => '_me_vendor_number',
				'label' => __( 'Number', 'epmp-marketplace-melhorenvio' ) . '*',
				'value' => $vendor_number,
				'attributes' => [ 'required' => 'required' ],
			]
		);

		$fields->text_input(
			[
				'id' => '_me_vendor_district',
				'name' => '_me_vendor_district',
				'label' => __( 'Neighborhood', 'epmp-marketplace-melhorenvio' ) . '*',
				'value' => $vendor_district,
				'attributes' => [ 'required' => 'required' ],
			]
		);

		$fields->text_input(
			[
				'id' => '_me_vendor_city',
				'name' => '_me_vendor_city',
				'label' => __( 'City', 'epmp-marketplace-melhorenvio' ) . '*',
				'value' => $vendor_city,
				'attributes' => [ 'required' => 'required' ],
			]
		);

		$fields->select_input(
			[
				'id' => '_me_vendor_state',
				'name' => '_me_vendor_state',
				'label' => __( 'State', 'epmp-marketplace-melhorenvio' ) . '*',
				'options' => WC()->countries->get_states( 'BR' ),
				'value' => $vendor_state,
				'attributes' => [ 'required' => 'required' ],
			]
		);

		$fields->text_input(
			[
				'id' => '_me_vendor_postal_code',
				'name' => '_me_vendor_postal_code',
				'label' => __( 'Postcode', 'epmp-marketplace-melhorenvio' ) . '*',
				'value' => $vendor_postal_code,
				'attributes' => [ 'required' => 'required' ],
			]
		);


	 	foreach( get_companies_with_agencies() as $company_id ){

			$agency_list = $agency_lists[$company_id] ?? [];
			$no_agency = empty( $agency_list );
			$company_name = get_company_name_by_id( $company_id );
			$selected_vendor_agency = $vendor_agencies[$company_id] ?? 0;

			$attributes = [];

			if( $no_agency ) {
				$attributes['disabled'] = 'disabled';
			}

		?>
		<div id="_me_company_container_<?php echo esc_attr( $company_id );?>" class="company-container" <?php echo $no_agency ? 'style="display:none"' : '' ;?>>

		<?php

		$fields->select_input(
			[
				'id' => '_me_company_' . esc_attr( $company_id ),
				'name' => '_me_vendor_agencies[' . esc_attr( $company_id ) .']',
				'label' => $company_name,
				'options' => wp_list_pluck( $agency_list, 'description', 'id' ),
				'value' => $selected_vendor_agency,
				'class' => 'agency-list',
				'desc' => sprintf(
							__( 'Select the %s agency from which you will send your packages.', 'epmp-marketplace-melhorenvio' ),
							$company_name
						),
				'attributes' => $attributes,
			]
		);
		?>
		</div>
		<?php

	 }

	?>
	<?php do_action( 'epmp_mpme_after_wcmp_address_fields', $vendor_id ); ?>
	</div>
</div>
