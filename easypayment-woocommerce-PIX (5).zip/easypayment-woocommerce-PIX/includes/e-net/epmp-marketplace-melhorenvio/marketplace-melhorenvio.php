<?php
/**
 * Plugin START
*/
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'EPMP_MPME_PREFIX', 'epmp_mpme_' );
define( 'EPMP_MPME_SLUG', 'epmp-marketplace-melhorenvio' );
define( 'EPMP_MPME_PLUGIN',  __FILE__ );
define( 'EPMP_MPME_BASENAME', plugin_basename( __FILE__ ) );
define( 'EPMP_MPME_DIR', dirname( __FILE__ ) );
define( 'EPMP_MPME_JS', plugin_dir_url( __FILE__ ) . 'assets/js' );

register_activation_hook( __FILE__, 'epmp_mpme_activate' );
/**
 *  Plugin activation hook
 */
function epmp_mpme_activate() {

	epmp_mpme_load_plugin_textdomain();

	/**
	 *  Requires WooCommerce and WooCommerce Melhor Envio to be installed and active
	 */
	if ( !epmp_mpme_dependencies_running() ) {

		deactivate_plugins( EPMP_MPME_BASENAME );
		ob_start();
		?>
		<p>
			<?php _e( 'WooCommerce Marketplace/Melhor Envio requires WooCommerce, Art-i Melhor Envio and a marketplace provider to run. Please, install those plugins and try again', 'epmp-marketplace-melhorenvio' );?>
		</p>
		<?php if(php_sapi_name() != 'cli'):?>
		<p>
			<a href='<?=admin_url( 'plugins.php' )?>' tile=''>
				<?php _e('Return to Plugins page', 'epmp-marketplace-melhorenvio')?>
			</a>
		</p>
		<?php endif;

		$result = ob_get_clean();

		// checking for WP-cli calls
		echo (php_sapi_name() == 'cli') ? preg_replace('/\s+/S', " ",strip_tags( $result ) ) : $result;

		wp_die();

	}

}

function epmp_mpme_dependencies_running() {

	if( !function_exists('get_plugin_data') ){
		require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	}

	return apply_filters(
			'epmp_mpme_dependencies_running',
			class_exists( 'WooCommerce' ) &&
			defined( 'EPMP_ME_FILE' ) &&
			version_compare( get_plugin_data( EPMP_ME_FILE )['Version'], '1.3', '>=' )
	);
}

add_action( 'plugins_loaded', 'epmp_mpme_loadplugin', 11);

function epmp_mpme_loadplugin(){

	if(epmp_mpme_dependencies_running()) {
		include_once EPMP_MPME_DIR . '/includes/functions.php';
		include_once EPMP_MPME_DIR . '/includes/classes/class-provider-config.php';

		/**
		 * Will allow authors to add providers in the future
		 * @var array
		 */
		$providers = epmp_mpme_get_providers_list();
		$vendor_provider_option = get_option( 'epmp_mpme_vendor_provider' );

		if( $vendor_provider_option && isset( $providers[$vendor_provider_option] ) ) {

			$provider_config = $providers[$vendor_provider_option];

			include_once EPMP_MPME_DIR . '/includes/classes/interface-shipping-processor.php';
			include_once EPMP_MPME_DIR . "/includes/classes/abstract-provider.php";

			$provider_package = EPMP_MPME_DIR . "/includes/providers/{$provider_config->get_slug()}/bootstrap.php";

			include_once apply_filters( 'epmp_mpme_provider_package_path', $provider_package, $provider_config );

			include_once EPMP_MPME_DIR . '/includes/classes/class-vendor-provider-factory.php';

			/**
			 * @todo Move this elsewhere?
			 */
			if( Epmp_MPME_Provider_Factory::load_provider( $provider_config->get_class() ) ){

				do_action( 'epmp_mpme_provider_loaded' );
				do_action( "epmp_mpme_provider_{$provider_config->get_slug()}_loaded" );

				if( Epmp_MPME_Provider_Factory::$current_provider->is_active ) {

					include_once EPMP_MPME_DIR . '/includes/package-processing.php';
					include_once EPMP_MPME_DIR . '/includes/tracking-code-processing.php';
					include_once EPMP_MPME_DIR . '/includes/classes/class-protopackage-splitting.php';
					include_once EPMP_MPME_DIR . '/includes/woocommerce-hooks.php';
					include_once EPMP_MPME_DIR . '/includes/dependencies-hooks.php';
					include_once EPMP_MPME_DIR . '/includes/legacy-compatibility.php';

					do_action( 'epmp_mpme_init' );

				}

			}

		}

		include_once EPMP_MPME_DIR . '/includes/options.php';

	} else {
		add_action('admin_notices', 'epmp_mpme_plugin_not_loaded');
	}

}

function epmp_mpme_plugin_not_loaded(){
	?>
	<div class="notice notice-warning is-dismissible">
		<p><strong><?php _e( 'WooCommerce Marketplace/Melhor Envio requires WooCommerce, Art-i Melhor Envio and a marketplace provider to run. Please, install those plugins and try again', 'epmp-marketplace-melhorenvio' );?></strong></p>
		<button type="button" class="notice-dismiss">
			<span class="screen-reader-text"><?php _e('Dismiss this notice.', 'epmp-marketplace-melhorenvio')?></span>
		</button>
	</div>
	<?php
}

/**
 * Loading text domain
 */
function epmp_mpme_load_plugin_textdomain() {
	load_plugin_textdomain( EPMP_MPME_SLUG, false, dirname( EPMP_MPME_BASENAME ) . '/languages' );
}

add_action( 'plugins_loaded', 'epmp_mpme_load_plugin_textdomain', 10 );
