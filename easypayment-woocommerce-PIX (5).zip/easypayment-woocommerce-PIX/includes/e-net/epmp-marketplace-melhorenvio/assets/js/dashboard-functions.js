
var epmp_mpme = {

	force_select_update: false,

	all_companies: [...new Set(Object.values(epmp_me_params.service_to_company_map))],

	get_selected_companies: function get_selected_companies(){
		var selected_values = jQuery('#_me_vendor_services').val() || [];

		if( selected_values.includes('0') ){
			return epmp_mpme.all_companies;
		}

		var selected_companies = [];
		selected_values.forEach( function( e ) {
			if(epmp_me_params.service_to_company_map.hasOwnProperty(e)){
				selected_companies.push(epmp_me_params.service_to_company_map[e])
			}
		});
		return selected_companies;
	},

	show_cnae_field: function show_cnae_field( selector ){

		selector = selector || '#cnae-container';

		if(
			epmp_mpme.get_selected_companies().includes( parseInt(epmp_me_params.LATAM_COMPANY_ID) ) &&
			(
				epmp_me_params.DOCUMENT_TYPE_CNPJ === jQuery('[name="_me_vendor_document_type"]:checked').val() ||
				epmp_me_params.DOCUMENT_TYPE_CNPJ === jQuery('[name="_me_vendor_document_type"]').val()
			)
		){
			jQuery(selector).show().find('input').removeAttr( 'disabled' );
		} else {
			jQuery(selector).hide().find('input').attr( 'disabled', 'disabled' );
		}
	},

	populate_select: function populate_select( companies ){

		jQuery.each(companies, function(company_id, agencies) {

			var select = jQuery('#_me_company_' + company_id);

			// Don't populate in case it already has a selected value.
			if( select.find(':selected').length && !epmp_mpme.force_select_update ){
				return;
			}

			select.html('').prop('disabled', true);

			select.append(jQuery.map(agencies, function(el){
				return new Option(el.text, el.id);
			})).removeAttr('disabled');

		});

		epmp_mpme.force_select_update = false;

		epmp_mpme.show_agency_lists(epmp_mpme.get_selected_companies())

	}
}
