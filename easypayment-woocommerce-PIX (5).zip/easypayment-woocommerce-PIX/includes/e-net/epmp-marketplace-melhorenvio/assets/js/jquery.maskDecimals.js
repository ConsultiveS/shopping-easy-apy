(function ( $ ) {
	$.fn.maskDecimals = function(){

		var formatted = format( clean_string( $(this).val() ) );

		$(this).val(formatted);

		this.on('keydown',function(e){
		    // backspace, tab, esc, enter
		    if ($.inArray(e.keyCode, [9, 27, 13]) !== -1 ||
		        // Ctrl+A
		        (e.keyCode == 65 && e.ctrlKey === true) ||
		        // home, end, left, right, down, up
		        (e.keyCode >= 35 && e.keyCode <= 40)) {
		        return;
		    }

		    e.preventDefault();

		    // del
		    if($.inArray(e.keyCode,[46]) !== -1){
		        $(this).val('');
		        return;
		    }

		    if(e.keyCode === 8){
		        $(this).val( $(this).val().slice(0, -1) );
		    }

		    var a = ["a","b","c","d","e","f","g","h","i","`"];
		    var n = ["1","2","3","4","5","6","7","8","9","0"];

		    var charCode = String.fromCharCode(e.keyCode);
		    var p = $.inArray(charCode,a);

		    var value = clean_string( $(this).val() );

		    if(p !== -1){
		    	value += n[p];
		    }

		    if(0<=charCode && 10>=charCode ){
		    	value += charCode;
		    }

		    var formatted = format( value );

		    $(this).val(formatted);

		    return;

		});

	}

	function format( value ){

		var padding = '000';

        value = padding.slice(0, -value.length || padding.length) + value;

		a = value.slice(0, -2);
        b = value.slice(-2);

        var formatted = a + ',' + b;

        return formatted;

	}

	function clean_string( val ){
		val = val || '';
		return val.toString().replace(/\./g,'').replace(/,/g,'').replace(/^0+/, '');
	}

}( jQuery ));
