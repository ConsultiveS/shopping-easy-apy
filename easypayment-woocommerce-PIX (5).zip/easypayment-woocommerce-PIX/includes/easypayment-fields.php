<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adicionar campos personalizados na tela do lojista para o WCFM - Marketplace
 * Source: https://wclovers.com/forums/topic/add-acf-field-to-store-settings/
*/

function wcfm_vendor_custom_0411_store_settings( $vendor_id ) {
	global $WCFM, $WCFMu;
	
	$wcfm_vendor_custom_options = (array) get_user_meta( $vendor_id, 'wcfm_vendor_custom_options', true );
	$wcfm_vendor_easypayment_allow      = isset( $wcfm_vendor_custom_options['easypayment_allow'] ) && $wcfm_vendor_custom_options['easypayment_allow'] == 'yes'? 'yes' : 'no';
	$wcfm_vendor_easypayment_allow_check= isset( $wcfm_vendor_easypayment_allow ) && $wcfm_vendor_easypayment_allow == 'yes'? 'true' : 'false';
	$wcfm_vendor_easypayment_token      = isset( $wcfm_vendor_custom_options['token'] ) ? $wcfm_vendor_custom_options['token'] : '';
	
	?>
	<!-- collapsible -->
	<div class="page_collapsible" id="wcfm_settings_form_vendor_custom_head">
		<label class="wcfmfa fa fa-money"></label>
		<?php _e( 'Easypayment', 'wc-frontend-manager-ultimate'); ?>
		<span class="wcfmfa"></span>
	</div>
	<div class="wcfm-container">
		<div id="wcfm_settings_form_vendor_custom_expander" class="wcfm-content">
			<?php
			
			$fieldsThisPlugin = array(
                "wcfm_vendor_custom_easypayment_allow"      => array(
                    'label'         => __( 'Ativar EasyPayment?', 'wc-frontend-manager-ultimate'),
                    'type'          => 'checkbox',
                    'name'          => 'wcfm_vendor_custom_options[easypayment_allow]',
                    'in_table'      => true,
                    'class'         => 'wcfm-checkbox wcfm_ele',
                    'label_class'   => 'wcfm_title wcfm_ele',
                    'value'         => 'yes',
                    'dfvalue'       => $wcfm_vendor_easypayment_allow,
                ),
                "wcfm_vendor_custom_easypayment_token"      => array(
                    'label'         => __( 'Token', 'wc-frontend-manager-ultimate'),
                    'type'          => 'text',
                    'name'          => 'wcfm_vendor_custom_options[token]',
                    'class'         => 'wcfm-text wcfm_ele',
                    'label_class'   => 'wcfm_title wcfm_ele',
                    'value'         => $wcfm_vendor_easypayment_token,
                    'attributes'    => array(
                        'placeholder'   => 'Token Easypayment'
                    )   
                )
            );
			
			$WCFM->wcfm_fields->wcfm_generate_form_field( apply_filters( 'wcfmu_settings_fields_vendor_store_invoice', $fieldsThisPlugin ) );
			?>
		</div>
	</div>
	<div class="wcfm_clearfix"></div>
	<!-- end collapsible -->
	<?php
}
	

//add_action( 'end_wcfm_vendor_settings', 'wcfm_vendor_custom_0411_store_settings', 20 );

function wcfmu_vendor_custom_0411_store_settings_update( $user_id, $wcfm_settings_form ) {
	global $WCFM, $WCFMu, $_POST;
	
	if( isset( $wcfm_settings_form['wcfm_vendor_custom_options'] ) ) {
		$wcfm_vendor_custom_options = $wcfm_settings_form['wcfm_vendor_custom_options'];
		update_user_meta( $user_id, 'wcfm_vendor_custom_options',  $wcfm_vendor_custom_options );
	}
}
//add_action( 'wcfm_vendor_settings_update', 'wcfmu_vendor_custom_0411_store_settings_update', 20, 2 );




/**
 * Adicionar campos personalizados no perfil do usuário/vendor
*/
add_action( 'show_user_profile', 'extra_user_profile_fields_easypayment' );
add_action( 'edit_user_profile', 'extra_user_profile_fields_easypayment' );

function extra_user_profile_fields_easypayment( $user ) {
	global $WCFM, $WCFMu;
	$vendor_id = $user->ID;
	$wcfm_vendor_custom_options = (array) get_user_meta( $vendor_id, 'wcfm_vendor_custom_options', true );
	$wcfm_vendor_easypayment_allow      = isset( $wcfm_vendor_custom_options['easypayment_allow'] ) && $wcfm_vendor_custom_options['easypayment_allow'] == 'yes'? 'yes' : 'no';
	$wcfm_vendor_easypayment_allow_check= isset( $wcfm_vendor_easypayment_allow ) && $wcfm_vendor_easypayment_allow == 'yes'? 'checked' : '';
	$wcfm_vendor_easypayment_token      = isset( $wcfm_vendor_custom_options['token'] ) ? $wcfm_vendor_custom_options['token'] : '';
// 	echo "<pre>";
// 	var_dump($wcfm_vendor_custom_options);
// 	var_dump( checked( $wcfm_vendor_easypayment_allow, 'yes', 'true' ) );
//     echo "</pre>";
    ?>
    <h3><?php _e("Easypayment", "blank"); ?></h3>

    <table class="form-table">
    <tr>
        <th><label for="address"><?php _e("Ativar Easypayment?"); ?></label></th>
        <td>
            <input type="checkbox" name="wcfm_vendor_custom_options[easypayment_allow]" id="wcfm_vendor_custom_options[easypayment_allow]" value="<?php echo $wcfm_vendor_easypayment_allow; ?>"<?php echo checked( $wcfm_vendor_easypayment_allow, 'yes', 'true' )?> class="regular-text" /><br />
            <span class="description"><?php _e("Ativar easypayment para esse usuário"); ?></span>
        </td>
    </tr>
    <tr>
        <th><label for="city"><?php _e("Token"); ?></label></th>
        <td>
            <input type="text" name="wcfm_vendor_custom_options[token]" id="wcfm_vendor_custom_options[token]" value="<?php echo $wcfm_vendor_easypayment_token; ?>" class="regular-text" /><br />
            <span class="description"><?php _e("Token de integração easypayment"); ?></span>
        </td>
    </tr>
    <tr>
    </table>
    <script>
        var easypaymentAllow = '#wcfm_vendor_custom_options\\[easypayment_allow\\]';
        jQuery(easypaymentAllow).change(function(){
            jQuery(easypaymentAllow).is(":checked") ? jQuery(easypaymentAllow).val('yes') : jQuery(easypaymentAllow).val('no');
        });
    </script>
    <?php
}
//Salvar dados do perfil do usuário no admin
add_action( 'personal_options_update', 'save_extra_user_profile_fields_easypayment' );
add_action( 'edit_user_profile_update', 'save_extra_user_profile_fields_easypayment' );
function save_extra_user_profile_fields_easypayment( $user_id ) {
	global $WCFM, $WCFMu, $_POST;
	
	
    if ( empty( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'update-user_' . $user_id ) ) {
        return;
    }
    
    if ( !current_user_can( 'edit_user', $user_id ) ) { 
        return false; 
    }
    
	//if( isset( $_POST['wcfm_vendor_custom_options'] ) ) {
		$wcfm_vendor_custom_options = $_POST['wcfm_vendor_custom_options'];
		update_user_meta( $user_id, 'wcfm_vendor_custom_options',  $wcfm_vendor_custom_options );
	//}
}