<?php
/**
 * Plugin's main class
 *
 * @package WooCommerce_EasyPayment
 */

/**
 * WooCommerce bootstrap class.
 */
class WC_EasyPayment {

	/**
	 * Initialize the plugin public actions.
	 */
	public static function init() {
		// Load plugin text domain.
		add_action( 'init', array( __CLASS__, 'load_plugin_textdomain' ) );

		// Checks with WooCommerce is installed.
		if ( class_exists( 'WC_Payment_Gateway' ) ) {
			self::includes();

			add_filter( 'woocommerce_payment_gateways', array( __CLASS__, 'add_gateway' ) );
			add_filter( 'woocommerce_available_payment_gateways', array( __CLASS__, 'hides_when_is_outside_brazil' ) );
			add_filter( 'woocommerce_billing_fields', array( __CLASS__, 'transparent_checkout_billing_fields' ), 9999 );
			add_filter( 'woocommerce_shipping_fields', array( __CLASS__, 'transparent_checkout_shipping_fields' ), 9999 );
			add_filter( 'plugin_action_links_' . plugin_basename( WC_EASYPAYMENT_PLUGIN_FILE ), array( __CLASS__, 'plugin_action_links' ) );
            
            //add_action( 'template_redirect', array( __CLASS__, 'define_default_payment_gateway') ); //Definir o plugin como escolha padr���o
			if ( is_admin() ) {
				add_action( 'admin_notices', array( __CLASS__, 'ecfb_missing_notice' ) );
			}
		} else {
			add_action( 'admin_notices', array( __CLASS__, 'woocommerce_missing_notice' ) );
		}
	}

	/**
	 * Add the gateway to WooCommerce.
	 *
	 * @param  array $methods WooCommerce payment methods.
	 * @return array          Payment methods with EasyPayment.
	 */
	public static function add_gateway( $methods ) {
		$methods[] = 'WC_EasyPayment_Gateway';
		new WC_EasyPayment_Gateway();
		return $methods;
	}
	

/**
 * Register custom blocks for WooCommerce.
 */
public static function register_blocks() {
    // Register block categories
    register_block_type_category(
        'easypayment',
        array( 'label' => __( 'EasyPayment Blocks', 'woocommerce-easypayment' ) )
    );

    // Register custom blocks for payment methods
    register_block_type(
        'woocommerce-easypayment/credit-card',
        array(
            'render_callback' => array( __CLASS__, 'render_credit_card_block' ),
            'category'        => 'easypayment',
            'attributes'      => array(
                'align' => array(
                    'type' => 'string',
                ),
            ),
        )
    );

    // Register more payment method blocks as needed
}

/**
 * Render callback for the credit card block.
 */
public static function render_credit_card_block( $attributes ) {
    // Customize the rendering of your credit card block here
    // You can use the $attributes array to customize the block output based on user input
    ob_start();
    // Output your credit card block HTML here
    echo '<div class="woocommerce-easypayment-credit-card-block">';
    echo '<p>' . __( 'Customize your credit card block here.', 'woocommerce-easypayment' ) . '</p>';
    echo '</div>';
    return ob_get_clean();
}


	/**
	 * Define o plugin como escolha padrão no Woocommerce checkout
	*/
    public function define_default_payment_gateway(){
        if( is_checkout() && ! is_wc_endpoint_url() ) {
            // HERE define the default payment gateway ID
            $default_payment_id = 'easypayment';
    
            WC()->session->set( 'chosen_payment_method', $default_payment_id );
        }
    }

	/**
	 * Get templates path.
	 *
	 * @return string
	 */
	public static function get_templates_path() {
		return plugin_dir_path( WC_EASYPAYMENT_PLUGIN_FILE ) . 'templates/';
	}

	/**
	 * Load the plugin text domain for translation.
	 */
	public static function load_plugin_textdomain() {
		load_plugin_textdomain( 'woocommerce-easypayment', false, dirname( plugin_basename( WC_EASYPAYMENT_PLUGIN_FILE ) ) . '/languages/' );
	}

	/**
	 * Action links.
	 *
	 * @param array $links Action links.
	 *
	 * @return array
	 */
	public static function plugin_action_links( $links ) {
		$plugin_links   = array();
		$plugin_links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=easypayment' ) ) . '">' . __( 'Settings', 'woocommerce-easypayment' ) . '</a>';

		return array_merge( $plugin_links, $links );
	}

	/**
	 * Includes.
	 */ 
	private static function includes() {
		include_once dirname( __FILE__ ) . '/class-wc-easypayment-xml.php';
		include_once dirname( __FILE__ ) . '/class-wc-easypayment-api.php';
		include_once dirname( __FILE__ ) . '/class-wc-easypayment-gateway.php';
// 		include_once dirname( __FILE__ ) . '/class-wc-easypayment-webhook.php';
		include_once dirname( __FILE__ ) . '/easypayment-fields.php';
		
		if( class_exists('WCFMmp') ){
		    //Carregar multiceps
		    include_once dirname( __FILE__ ) . '/e-net/epmp-marketplace-melhorenvio/marketplace-melhorenvio.php';
		    include_once dirname( __FILE__ ) . '/e-net/epmp-melhorenvio/melhorenvio.php';
		    include_once dirname( __FILE__ ) . '/e-net/wcfm-custom-menus/wcfm-custom-menus.php';
		}
	}

	/**
	 * Hides the EasyPayment with payment method with the customer lives outside Brazil.
	 *
	 * @param   array $available_gateways Default Available Gateways.
	 *
	 * @return  array                     New Available Gateways.
	 */
	public static function hides_when_is_outside_brazil( $available_gateways ) {
		// Remove EasyPayment gateway.
		if ( isset( $_REQUEST['country'] ) && 'BR' !== $_REQUEST['country'] ) { // WPCS: input var ok, CSRF ok.
			unset( $available_gateways['easypayment'] );
		}

		return $available_gateways;
	}

	/**
	 * Transparent checkout billing fields.
	 *
	 * @param array $fields Checkout fields.
	 * @return array
	 */
	public static function transparent_checkout_billing_fields( $fields ) {
		$settings = get_option( 'woocommerce_easypayment_settings', array( 'method' => '' ) );

		if ( isset($settings['method']) && 'transparent' === $settings['method'] && class_exists( 'Extra_Checkout_Fields_For_Brazil' ) ) {
			if ( isset( $fields['billing_neighborhood'] ) ) {
				$fields['billing_neighborhood']['required'] = true;
			}
			if ( isset( $fields['billing_number'] ) ) {
				$fields['billing_number']['required'] = true;
			}
		}

		return $fields;
	}

	/**
	 * Transparent checkout billing fields.
	 *
	 * @param array $fields Checkout fields.
	 * @return array
	 */
	public static function transparent_checkout_shipping_fields( $fields ) {
		$settings = get_option( 'woocommerce_easypayment_settings', array( 'method' => '' ) );

		if ( isset($settings['method']) && 'transparent' === $settings['method'] && class_exists( 'Extra_Checkout_Fields_For_Brazil' ) ) {
			if ( isset( $fields['shipping_neighborhood'] ) ) {
				$fields['shipping_neighborhood']['required'] = true;
			}
		}

		return $fields;
	}

	/**
	 * WooCommerce Extra Checkout Fields for Brazil notice.
	 */
	public static function ecfb_missing_notice() {
		$settings = get_option( 'woocommerce_easypayment_settings', array( 'method' => '' ) );

		if ( isset($settings['method']) && 'transparent' === $settings['method'] && ! class_exists( 'Extra_Checkout_Fields_For_Brazil' ) ) {
			include dirname( __FILE__ ) . '/admin/views/html-notice-missing-ecfb.php';
		}
	}

	/**
	 * WooCommerce missing notice.
	 */
	public static function woocommerce_missing_notice() {
		include dirname( __FILE__ ) . '/admin/views/html-notice-missing-woocommerce.php';
	}
}