<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Source code complete: https://wclovers.com/knowledgebase/wcfm-marketplace-custom-payment-gateway-developers-guide/
 */
add_filter('wcfm_marketplace_withdrwal_payment_methods', function ($payment_methods) {
    $payment_methods['wc_easypayment'] = 'Easypayment';
    return $payment_methods;
});


add_filter('wcfm_marketplace_settings_fields_withdrawal_payment_keys', function ($payment_keys, $wcfm_withdrawal_options) {
    $gateway_slug = 'wc_easypayment';
    $withdrawal_wc_easypayment_token_easypayment = isset ($wcfm_withdrawal_options[$gateway_slug . '_token_easypayment']) ? $wcfm_withdrawal_options[$gateway_slug . '_token_easypayment'] : '';
    $payment_wc_easypayment_keys = [
        "withdrawal_" . $gateway_slug . "_token_easypayment" => [
            'label' => __('Easypayment Token', 'woocommerce-easypayment'),
            'name' => 'wcfm_withdrawal_options[' . $gateway_slug . '_token_easypayment]',
            'type' => 'text',
            'class' => 'wcfm-text wcfm_ele withdrawal_mode withdrawal_mode_live withdrawal_mode_' . $gateway_slug,
            'label_class' => 'wcfm_title withdrawal_mode withdrawal_mode_live withdrawal_mode_' . $gateway_slug,
            'value' => $withdrawal_wc_easypayment_token_easypayment
        ],
    ];
    $payment_keys = array_merge($payment_keys, $payment_wc_easypayment_keys);
    return $payment_keys;
}, 50, 2);


add_filter('wcfm_marketplace_settings_fields_withdrawal_charges', function ($withdrawal_charges, $wcfm_withdrawal_options, $withdrawal_charge) {
    $gateway_slug = 'wc_easypayment';
    $withdrawal_charge_wc_easypayment = isset ($withdrawal_charge[$gateway_slug]) ? $withdrawal_charge[$gateway_slug] : array ();
    $payment_withdrawal_charges = [
        "withdrawal_charge_" . $gateway_slug => [
            'label' => __('Easypayment Charge', 'woocommerce-easypayment'),
            'type' => 'multiinput',
            'name' => 'wcfm_withdrawal_options[withdrawal_charge][' . $gateway_slug . ']',
            'class' => 'withdraw_charge_block withdraw_charge_' . $gateway_slug,
            'label_class' => 'wcfm_title wcfm_ele wcfm_fill_ele withdraw_charge_block withdraw_charge_' . $gateway_slug,
            'value' => $withdrawal_charge_wc_easypayment,
            'custom_attributes' => [
                'limit' => 1
            ],
            'options' => [
                "percent" => [
                    'label' => __('Percent Charge(%)', 'woocommerce-easypayment'),
                    'type' => 'number',
                    'class' => 'wcfm-text wcfm_ele withdraw_charge_field withdraw_charge_percent withdraw_charge_percent_fixed',
                    'label_class' => 'wcfm_title wcfm_ele withdraw_charge_field withdraw_charge_percent withdraw_charge_percent_fixed',
                    'attributes' => [
                        'min' => '0.1',
                        'step' => '0.1'
                    ]
                ],
                "fixed" => [
                    'label' => __('Fixed Charge', 'woocommerce-easypayment'),
                    'type' => 'number',
                    'class' => 'wcfm-text wcfm_ele withdraw_charge_field withdraw_charge_fixed withdraw_charge_percent_fixed',
                    'label_class' => 'wcfm_title wcfm_ele withdraw_charge_field withdraw_charge_fixed withdraw_charge_percent_fixed',
                    'attributes' => [
                        'min' => '0.1',
                        'step' => '0.1'
                    ]
                ],
                "tax" => [
                    'label' => __('Charge Tax', 'woocommerce-easypayment'),
                    'type' => 'number',
                    'class' => 'wcfm-text wcfm_ele',
                    'label_class' => 'wcfm_title wcfm_ele',
                    'attributes' => [
                        'min' => '0.1',
                        'step' => '0.1'
                    ],
                    'hints' => __('Tax for withdrawal charge, calculate in percent.', 'woocommerce-easypayment')
                ],
            ]
        ]
    ];
    $withdrawal_charges = array_merge($withdrawal_charges, $payment_withdrawal_charges);
    return $withdrawal_charges;
}, 50, 3);

add_filter('wcfm_marketplace_settings_fields_billing', function ($vendor_billing_fileds, $vendor_id) {
    $gateway_slug = 'wc_easypayment';
    $vendor_data = get_user_meta($vendor_id, 'wcfmmp_profile_settings', true);
    // echo "<pre>";
    // var_dump( $vendor_data);
    // echo "</pre>";
    if (!$vendor_data)
        $vendor_data = [];
    //$wc_easypayment = isset( $vendor_data['payment'][$gateway_slug]['email'] ) ? esc_attr( $vendor_data['payment'][$gateway_slug]['email'] ) : '' ;
    $wc_easypayment = isset ($vendor_data['user_email']) ? esc_attr($vendor_data['user_email']) : '';
    $vendor_wc_easypayment_billing_fileds = [
        $gateway_slug => [
            'label' => __('Easypayment Email', 'wc-frontend-manager'),
            'name' => 'payment[' . $gateway_slug . '][email]',
            'type' => 'text',
            'class' => 'wcfm-text wcfm_ele paymode_field paymode_' . $gateway_slug,
            'label_class' => 'wcfm_title wcfm_ele paymode_field paymode_' . $gateway_slug,
            'value' => $wc_easypayment
        ],
    ];
    $vendor_billing_fileds = array_merge($vendor_billing_fileds, $vendor_wc_easypayment_billing_fileds);
    return $vendor_billing_fileds;
}, 50, 2);


class WCFMmp_Gateway_wc_easypayment
{
    public $id;
    public $message = array();
    public $gateway_title;
    public $payment_gateway;
    public $withdrawal_id;
    public $vendor_id;
    public $withdraw_amount = 0;
    public $currency;
    public $transaction_mode;
    private $reciver_email;
    public $token;
    public $client_secret;

    public function __construct()
    {
        $this->id = 'wc_easypayment';
        $this->gateway_title = __('EasyPay', 'woocommerce-easypayment');
        $this->payment_gateway = $this->id;
    }

    public function gateway_logo()
    {
        global $WCFMmp;
        return $WCFMmp->plugin_url . 'assets/images/' . $this->id . '.png';
    }

    public function process_payment($withdrawal_id, $vendor_id, $withdraw_amount, $withdraw_charges, $transaction_mode = 'auto')
    {
        global $WCFM, $WCFMmp;
        $this->withdrawal_id = $withdrawal_id;
        $this->vendor_id = $vendor_id;
        $this->withdraw_amount = $withdraw_amount;
        $this->currency = get_woocommerce_currency();
        $this->transaction_mode = $transaction_mode;
        $this->reciver_email = $WCFMmp->wcfmmp_vendor->get_vendor_payment_account($this->vendor_id, $this->id);
        $this->token = isset($WCFMmp->wcfmmp_withdrawal_options[$this->id . '_token_easypayment']) ? $WCFMmp->wcfmmp_withdrawal_options[$this->id . '_token_easypayment'] : '';

        if ($this->validate_request()) {
            // Updating withdrawal meta
            $WCFMmp->wcfmmp_withdraw->wcfmmp_update_withdrawal_meta($this->withdrawal_id, 'withdraw_amount', $this->withdraw_amount);
            $WCFMmp->wcfmmp_withdraw->wcfmmp_update_withdrawal_meta($this->withdrawal_id, 'currency', $this->currency);
            $WCFMmp->wcfmmp_withdraw->wcfmmp_update_withdrawal_meta($this->withdrawal_id, 'reciver_email', $this->reciver_email);
            return array('status' => true, 'message' => __('New transaction has been initiated', 'woocommerce-easypayment'));
        } else {
            return $this->message;
        }
    }

    public function validate_request()
    {
        global $WCFMmp;
        return true;
    }
}
new WCFMmp_Gateway_wc_easypayment();