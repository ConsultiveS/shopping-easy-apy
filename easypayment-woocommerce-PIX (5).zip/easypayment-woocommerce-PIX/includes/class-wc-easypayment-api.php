<?php
/**
 * API class
 *
 * @package WooCommerce_EasyPayment/Classes/API
 * @version 2.12.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * API.
 */
class WC_EasyPayment_API
{

    /**
     * Gateway class.
     *
     * @var WC_EasyPayment_Gateway
     */
    protected $gateway;

    /**
     * Constructor.
     *
     * @param WC_EasyPayment_Gateway $gateway Payment Gateway instance.
     */
    public function __construct($gateway = null)
    {
        $this->gateway = $gateway;
        $this->domain = 'shoppingeasypay.com.br';
    }

    /**
     * Get the API environment.
     *
     * @return string
     */
    protected function get_environment()
    {
        return (isset($this->gateway->sandbox) && 'yes' == $this->gateway->sandbox) ? WC_EASYPAYMENT_URL_SANDBOX : WC_EASYPAYMENT_URL_PRODUCTION;
    }

    /**
     * =======================================================================================================================================
     * =========================================================== API EASYPAYMENT ===========================================================
     * =======================================================================================================================================
     */

    /**
     * ****************************************** VENDEDOR ****************************************
     */

    /**
     * Criando novo Vendedor
     * @link https://sistema.shoppingeasypay.com.br/reference/criando-novo-vendedor/
     * @method POST
     * @param array $body_params
     */
    public function vendedor_criar($body_params)
    {
        $url = $this->get_environment() . "/sellers";
        $response = $this->do_request($url, 'POST', $body_params);
        return $response;
    }

    /**
     * Listando Vendedores
     * @link https://sistema.shoppingeasypay.com.br/reference/listando-vendedores/
     * @method GET
     */
    public function vendedor_listar()
    {
        $url = $this->get_environment() . "/sellers";
        $response = $this->do_request($url, 'GET');
        return $response;
    }

    /**
     * Atualizando dados do Vendedor
     * @link https://sistema.shoppingeasypay.com.br/reference/atualizando-dados-do-vendedor/
     * @method PUT
     * @param int $seller_id
     * @param array $body_params
     */
    public function vendedor_atualizar($seller_id, $body_params)
    {
        $url = $this->get_environment() . "/sellers/$seller_id";
        $response = $this->do_request($url, 'PUT', $body_params);
        return $response;
    }

    /**
     * Consultando um Vendedor
     * @link https://sistema.shoppingeasypay.com.br/reference/consultando-um-vendedor/
     * @method GET
     * @param int $seller_id
     */
    public function vendedor_consultar($seller_id)
    {
        $url = $this->get_environment() . "/sellers/$seller_id";
        $response = $this->do_request($url, 'GET');
        return $response;
    }

    /**
     * ****************************************** CLIENTE (COMPRADOR) ****************************************
     */

    /**
     * Criando um Cliente
     * @link https://sistema.shoppingeasypay.com.br/reference/criando-um-cliente/
     * @method POST
     * @param array $body_params
     */
    public function comprador_criar($body_params)
    {
        $url = $this->get_environment() . "/customers";
        $response = $this->do_request($url, 'POST', $body_params);
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Atualizando dados do Cliente
     * @link https://sistema.shoppingeasypay.com.br/reference/atualizando-dados-do-cliente/
     * @method PUT
     * @param int $customer_id
     * @param array $body_params
     */
    public function comprador_atualizar($customer_id, $body_params)
    {
        $url = $this->get_environment() . "/customers/$customer_id";
        $response = $this->do_request($url, 'PUT', $body_params);
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Consultando um Cliente
     * @link https://sistema.shoppingeasypay.com.br/reference/consultando-um-cliente/
     * @method GET
     * @param int $customer_id
     */
    public function comprador_consultar($customer_id)
    {
        $url = $this->get_environment() . "/customers/$customer_id";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Listando Clientes
     * @link https://sistema.shoppingeasypay.com.br/reference/listando-clientes/
     * @method GET
     */
    public function comprador_listar()
    {
        $url = $this->get_environment() . "/customers/?limit=1000";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Removendo um Clientes
     * @link https://sistema.shoppingeasypay.com.br/reference/removendo-um-cliente/
     * @method DELETE
     * @param int $customer_id
     */
    public function comprador_remover($customer_id)
    {
        $url = $this->get_environment() . "/customers/$customer_id";
        $response = $this->do_request($url, 'DELETE');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /*
     * ****************************************** MÉTODOS DE COBRANÇA ****************************************
     */

    /**
     * Criando uma Cobrança Avulsa
     * @link https://sistema.shoppingeasypay.com.br/reference/criando-uma-cobranca-avulsa/
     * @method POST
     * @param array $body_params
     */
    public function cobranca_criar($body_params)
    {
        $url = $this->get_environment() . "/invoices";
        $response = $this->do_request($url, 'POST', $body_params);
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Consultando uma Cobrança Avulsa
     * @link https://sistema.shoppingeasypay.com.br/reference/consultando-uma-cobranca-avulsa/
     * @method GET
     * @param int $invoice_id
     */
    public function cobranca_consultar($invoice_id)
    {
        $url = $this->get_environment() . "/invoices/$invoice_id";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Listando uma Cobrança Avulsa
     * @link https://sistema.shoppingeasypay.com.br/reference/listando-cobrancas-avulsas/
     * @method GET
     * @param array $query_params
     */
    public function cobranca_listar_avulsa($query_params = [])
    {
        $query = isset($query_params) ? '?' . http_build_query($query_params) : '';
        $url = $this->get_environment() . "/invoices/$query";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Criando um Pagamento com Cartão
     * @link https://sistema.shoppingeasypay.com.br/reference/criando-um-pagamento-com-cartao/
     * @method POST
     * @param int $invoice_id
     * @param array $body_params
     */
    public function cobranca_criar_cartao($invoice_id, $body_params)
    {
        $url = $this->get_environment() . "/invoices/$invoice_id/payment";
        $response = $this->do_request($url, 'POST', $body_params);
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];

    }

    /**
     * Simular Pagamentos (sandbox)
     * @link https://sistema.shoppingeasypay.com.br/reference/simular-pagamentos-sandbox/
     * @method GET
     * @param int $transaction_id
     * @param int $amount
     */
    public function cobranca_simular_sandbox($transaction_id, $amount)
    {
        $url = $this->get_environment() . "/transactions/$transaction_id/simulate/authorize/?amount=$amount";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Listando Transações de uma Cobrança
     * @link https://sistema.shoppingeasypay.com.br/reference/listando-transacoes-de-uma-cobranca/
     * @method GET
     * @param int $invoice_id
     */
    public function cobranca_lista_transacoes($invoice_id)
    {
        $url = $this->get_environment() . "/invoices/$invoice_id/payment";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Cancelando uma Cobrança
     * @link https://sistema.shoppingeasypay.com.br/reference/cancelando-uma-cobranca/
     * @method POST
     * @param int $invoice_id
     */
    public function cobranca_cancelar($invoice_id)
    {
        $url = $this->get_environment() . "/invoices/$invoice_id/cancel";
        $response = $this->do_request($url, 'POST');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Estornando uma Cobrança no Cartão
     * @link https://sistema.shoppingeasypay.com.br/reference/estornando-uma-cobranca-no-cartao/
     * @method POST
     * @param int $invoice_id
     */
    public function cobranca_estornar($invoice_id)
    {
        $url = $this->get_environment() . "/invoices/$invoice_id/refund";
        $response = $this->do_request($url, 'POST');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Listando Transações
     * @link https://sistema.shoppingeasypay.com.br/reference/listando-transacoes/
     * @method GET
     */
    public function cobranca_listar_transacoes($query_params = [])
    {
        $query = isset($query_params) ? '?' . http_build_query($query_params) : '';
        $url = $this->get_environment() . "/transactions/?limit=1000";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Consultando uma Transação
     * @link https://sistema.shoppingeasypay.com.br/reference/consultando-uma-transacao/
     * @method GET
     * @param $transaction_id
     */
    public function cobranca_consultar_transacao($transaction_id)
    {
        $url = $this->get_environment() . "/transactions/$transaction_id";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Alterando Vencimento de uma Cobrança
     * @link https://sistema.shoppingeasypay.com.br/reference/alterando-vencimento-de-uma-cobranca/
     * @method POST
     * @param int $invoice_id
     * @param array $body_params
     */
    public function cobranca_alterar_vencimento($invoice_id, $body_params)
    {
        $url = $this->get_environment() . "/invoices/$invoice_id/change-expiration-date";
        $response = $this->do_request($url, 'GET', $body_params);
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Marcando uma Cobrança como Paga Manualmente
     * @link https://sistema.shoppingeasypay.com.br/reference/marcando-uma-cobranca-como-paga-manualmente/
     * @method POST
     * @param int $invoice_id
     */
    public function cobranca_marcar_como_pago($invoice_id)
    {
        $url = $this->get_environment() . "/invoices/$invoice_id/mark-as-paid";
        $response = $this->do_request($url, 'POST');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /*
     * ****************************************** CARNÊ ****************************************
     */

    /**
     * Criando um Carnê de Boletos
     * @link https://sistema.shoppingeasypay.com.br/reference/criando-um-carne-de-boletos/
     * @method POST
     * @param array $body_params
     */
    public function carne_criar($body_params)
    {
        $url = $this->get_environment() . "/bookpayments";
        $response = $this->do_request($url, 'POST', $body_params);
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Consultando um Carnê
     * @link https://sistema.shoppingeasypay.com.br/reference/criando-um-carne-de-boletos/
     * @method GET
     * @param array $body_params
     */
    public function carne_consultar($book_payment_id)
    {
        $url = $this->get_environment() . "/bookpayments/$book_payment_id";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Listando Carnês
     * @link https://sistema.shoppingeasypay.com.br/reference/listando-carnes/
     * @method GET
     * @param array $query_params
     */
    public function carne_listar($query_params)
    {
        $query = isset($query_params) ? '?' . http_build_query($query_params) : '';
        $url = $this->get_environment() . "/bookpayments/$query";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Cancelando um Carnê
     * @link https://sistema.shoppingeasypay.com.br/reference/cancelando-um-carne/
     * @method POST
     * @param int $book_payment_id
     * @param array $body_params
     */
    public function carne_cancelar($book_payment_id, $body_params)
    {
        $url = $this->get_environment() . "/bookpayments/$book_payment_id/cancel";
        $response = $this->do_request($url, 'POST', $body_params);
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Listando Cobranças de um Carnê
     * @link https://sistema.shoppingeasypay.com.br/reference/listando-cobrancas-de-um-carne/
     * @method GET
     * @param int $book_payment_id
     */
    public function carne_listar_cobrancas($book_payment_id)
    {
        $url = $this->get_environment() . "/bookpayments/$book_payment_id/invoices";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }


    /*
     * ******************************** ASSINATURA RECORRENTE **********************************
     */

    /**
     * Criando uma Assinatura
     * @link https://sistema.shoppingeasypay.com.br/reference/criando-uma-assinatura/
     * @method POST
     * @param array $body_params
     */
    public function assinatura_criar($body_params)
    {
        $url = $this->get_environment() . "/subscriptions";
        $response = $this->do_request($url, 'POST', $body_params);
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Consultando uma Assinatura
     * @link https://sistema.shoppingeasypay.com.br/reference/consultando-uma-assinatura/
     * @method GET
     * @param int $subscription_id
     */
    public function assinatura_consultar($subscription_id)
    {
        $url = $this->get_environment() . "/subscriptions/$subscription_id";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Listando Assinaturas
     * @link https://sistema.shoppingeasypay.com.br/reference/listando-assinaturas/
     * @method GET
     * @param array $query_params
     */
    public function assinatura_listar($query_params)
    {
        $query = isset($query_params) ? '?' . http_build_query($query_params) : '';
        $url = $this->get_environment() . "/subscriptions/$query";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Listando Cobranças de uma Assinatura
     * @link https://sistema.shoppingeasypay.com.br/reference/listando-cobrancas-de-uma-assinatura/
     * @method GET
     * @param int $subscription_id
     */
    public function assinatura_listar_cobrancas($subscription_id)
    {
        $url = $this->get_environment() . "/subscriptions/$subscription_id/invoices";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Cancelando uma Assinatura
     * @link https://sistema.shoppingeasypay.com.br/reference/cancelando-uma-assinatura/
     * @method POST
     * @param int $subscription_id
     */
    public function assinatura_cancelar($subscription_id)
    {
        $url = $this->get_environment() . "/subscriptions/$subscription_id/cancel";
        $response = $this->do_request($url, 'POST');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Suspendendo uma Assinatura
     * @link https://sistema.shoppingeasypay.com.br/reference/suspendendo-uma-assinatura/
     * @method POST
     * @param int $subscription_id
     */
    public function assinatura_suspender($subscription_id)
    {
        $url = $this->get_environment() . "/subscriptions/$subscription_id/suspend";
        $response = $this->do_request($url, 'POST');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Reativando uma Assinatura
     * @link https://sistema.shoppingeasypay.com.br/reference/reativando-uma-assinatura/
     * @method POST
     * @param int $subscription_id
     * @param array $body_params
     */
    public function assinatura_reativar($subscription_id, $body_params)
    {
        $url = $this->get_environment() . "/subscriptions/$subscription_id/reactivate";
        $response = $this->do_request($url, 'POST', $body_params);
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /*
     * ******************************** CONTA BANCÁRIA **********************************
     */

    /**
     * Criando uma Conta Bancária
     * @link https://sistema.shoppingeasypay.com.br/reference/criando-uma-conta-bancaria/
     * @method POST
     * @param array $body_params
     */
    public function conta_bancaria_criar($body_params)
    {
        $url = $this->get_environment() . "/bankaccounts";
        $response = $this->do_request($url, 'POST', $body_params);
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Consultando uma Conta Bancária
     * @link https://sistema.shoppingeasypay.com.br/reference/consultando-uma-conta-bancaria/
     * @method GET
     * @param $bank_account_id
     */
    public function conta_bancaria_consultar($bank_account_id)
    {
        $url = $this->get_environment() . "/bankaccounts/$bank_account_id";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Listando Contas Bancárias
     * @link https://sistema.shoppingeasypay.com.br/reference/listando-contas-bancarias/
     * @method GET
     * @param $bank_account_id
     */
    public function conta_bancaria_listar()
    {
        $url = $this->get_environment() . "/bankaccounts";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Removendo uma Conta Bancária
     * @link https://sistema.shoppingeasypay.com.br/reference/removendo-uma-conta-bancaria/
     * @method DELETE
     * @param $bank_account_id
     */
    public function conta_bancaria_remover($bank_account_id)
    {
        $url = $this->get_environment() . "/bankaccounts/$bank_account_id";
        $response = $this->do_request($url, 'DELETE');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /*
     * ******************************** TRANSFERÊNCIA **********************************
     */

    /**
     * Criando uma Transferência
     * @link https://sistema.shoppingeasypay.com.br/reference/criando-uma-transferencia/
     * @method POST
     * @param array $body_params
     */
    public function transferencia_criar($body_params)
    {
        $url = $this->get_environment() . "/transfers";
        $response = $this->do_request($url, 'POST', $body_params);
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Consultando uma Transferência
     * @link https://sistema.shoppingeasypay.com.br/reference/consultando-uma-transferencia/
     * @method GET
     * @param int $transfer_id
     */
    public function transferencia_consultar($transfer_id)
    {
        $url = $this->get_environment() . "/$transfer_id/transfers";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Listando Transferências
     * @link https://sistema.shoppingeasypay.com.br/reference/listando-transferencias/
     * @method GET
     */
    public function transferencia_obter()
    {
        $url = $this->get_environment() . "/transfers";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /*
     * *********************************** EXTRATOS ************************************
     */
    /**
     * Listando Extrato
     * @link https://sistema.shoppingeasypay.com.br/reference/listando-extrato/
     * @method GET
     */
    public function extrato_listar()
    {
        $url = $this->get_environment() . "/statements";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Listando Extrato Futuro
     * @link https://sistema.shoppingeasypay.com.br/reference/listando-extrato-futuro/
     * @method GET
     */
    public function extrato_futuro()
    {
        $url = $this->get_environment() . "/futurestatements";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Listando Extrato Bloqueado
     * @link https://sistema.shoppingeasypay.com.br/reference/listando-extrato-bloqueado/
     * @method GET
     */
    public function extrato_bloqueado()
    {
        $url = $this->get_environment() . "/blockedstatements";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /**
     * Consultando Saldo de um Vendedor
     * @link https://sistema.shoppingeasypay.com.br/reference/consultando-saldo-de-um-vendedor/
     * @method GET
     * @param int $seller_id
     */
    public function extrato_saldo_vendedor($seller_id)
    {
        $url = $this->base_vendedor() . "/$seller_id/balances";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }

    /*
     * *********************************** WEBHOOK ************************************
     */

    //MOVIDO PARA A class-easypayment-webhook.php

    /* -------------------------------------- END API -------------------------------------- */

    /**
     * Check if is localhost.
     *
     * @return bool
     */
    protected function is_localhost()
    {
        $url = home_url('/');
        $home = untrailingslashit(str_replace(array('https://', 'http://'), '', $url));

        return in_array($home, array('localhost', '127.0.0.1'));
    }

    /**
     * Money format.
     *
     * @param  int/float $value Value to fix.
     *
     * @return float Fixed value.
     */
    protected function money_format($value)
    {
        return number_format($value, 2, '.', '');
    }

    /**
     * Sanitize the item description.
     *
     * @param  string $description Description to be sanitized.
     *
     * @return string
     */
    protected function sanitize_description($description)
    {
        return sanitize_text_field(substr($description, 0, 95));
    }

    /**
     * Get payment name by type.
     *
     * @param  int $value Payment Type number.
     *
     * @return string
     */
    public function get_payment_name_by_type($value)
    {
        $types = array(
            1 => __('Cartão de crédito', 'woocommerce-easypayment'),
            2 => __('Boleto', 'woocommerce-easypayment'),
            3 => __('Carnê', 'woocommerce-easypayment'),
            4 => __('Pix', 'woocommerce-easypayment'),
            5 => __('Assinatura', 'woocommerce-easypayment'),
        );

        return isset($types[$value]) ? $types[$value] : __('Unknown', 'woocommerce-easypayment');
    }

    /**
     * Get payment method name.
     *
     * @param  int $value Payment method number.
     *
     * @return string
     */
    public function get_payment_method_name($value)
    {
        $credit = __('Cartão de crédito %s', 'woocommerce-easypayment');
        $ticket = __('Boleto %s', 'woocommerce-easypayment');
        $debit = __('Débito %s', 'woocommerce-easypayment');

        //Cartões aceitos: https://sistema.shoppingeasypay.com.br/docs/cartao-de-credito/
        $methods = array(
            101 => sprintf($credit, 'Visa'),
            102 => sprintf($credit, 'MasterCard'),
            105 => sprintf($credit, 'Hipercard'),
            104 => sprintf($credit, 'Diners'),
            103 => sprintf($credit, 'American Express'),
            107 => sprintf($credit, 'Elo')
        );

        return isset($methods[$value]) ? $methods[$value] : __('Unknown', 'woocommerce-easypayment');
    }

    /**
     * Get the paymet method.
     *
     * @param  string $method Payment method.
     *
     * @return string
     */
    public function get_payment_method($method)
    {
        $methods = array(
            'credit-card' => 'creditCard',
            'banking-ticket' => 'boleto',
            'bank-transfer' => 'eft',
            'recorrencia' => 'assinatura',
            'carne' => 'carne',
            'pix' => 'pix'
        );

        return isset($methods[$method]) ? $methods[$method] : '';
    }

    /**
     * Get error message.
     *
     * @param  int $code Error code.
     *
     * @return string
     */
    public function get_error_message($code)
    {
        $code = (string) $code;

        $messages = array(
            '11013' => __('Easypayment: Please enter with a valid phone number with DDD. Example: (11) 5555-5555.', 'woocommerce-easypayment'),
            '11014' => __('Easypayment: Please enter with a valid phone number with DDD. Example: (11) 5555-5555.', 'woocommerce-easypayment'),
            '53018' => __('Easypayment: Please enter with a valid phone number with DDD. Example: (11) 5555-5555.', 'woocommerce-easypayment'),
            '53019' => __('Easypayment: Please enter with a valid phone number with DDD. Example: (11) 5555-5555.', 'woocommerce-easypayment'),
            '53020' => __('Easypayment: Please enter with a valid phone number with DDD. Example: (11) 5555-5555.', 'woocommerce-easypayment'),
            '53021' => __('Easypayment: Please enter with a valid phone number with DDD. Example: (11) 5555-5555.', 'woocommerce-easypayment'),
            '11017' => __('Easypayment: Please enter with a valid zip code number.', 'woocommerce-easypayment'),
            '53022' => __('Easypayment: Please enter with a valid zip code number.', 'woocommerce-easypayment'),
            '53023' => __('Easypayment: Please enter with a valid zip code number.', 'woocommerce-easypayment'),
            '53053' => __('Easypayment: Please enter with a valid zip code number.', 'woocommerce-easypayment'),
            '53054' => __('Easypayment: Please enter with a valid zip code number.', 'woocommerce-easypayment'),
            '11164' => __('Easypayment: Please enter with a valid CPF number.', 'woocommerce-easypayment'),
            '53110' => '',
            '53111' => __('Easypayment: Please select a bank to make payment by bank transfer.', 'woocommerce-easypayment'),
            '53045' => __('Easypayment: Credit card holder CPF is required.', 'woocommerce-easypayment'),
            '53047' => __('Easypayment: Credit card holder birthdate is required.', 'woocommerce-easypayment'),
            '53042' => __('Easypayment: Credit card holder name is required.', 'woocommerce-easypayment'),
            '53049' => __('Easypayment: Credit card holder phone is required.', 'woocommerce-easypayment'),
            '53051' => __('Easypayment: Credit card holder phone is required.', 'woocommerce-easypayment'),
            '11020' => __('Easypayment: The address complement is too long, it cannot be more than 40 characters.', 'woocommerce-easypayment'),
            '53028' => __('Easypayment: The address complement is too long, it cannot be more than 40 characters.', 'woocommerce-easypayment'),
            '53029' => __('Easypayment: <strong>Neighborhood</strong> is a required field.', 'woocommerce-easypayment'),
            '53046' => __('Easypayment: Credit card holder CPF invalid.', 'woocommerce-easypayment'),
            '53122' => __('Easypayment: Invalid email domain. You must use an email @sandbox.shoppingeasypay.com.br while you are using the EasyPayment Sandbox.', 'woocommerce-easypayment'),
            '53081' => __('Easypayment: The customer email can not be the same as the EasyPayment account owner.', 'woocommerce-easypayment'),
        );

        if (isset($messages[$code])) {
            return $messages[$code];
        }

        return __('Easypayment: An error has occurred while processing your payment, please review your data and try again. Or contact us for assistance.', 'woocommerce-easypayment');
    }

    /**
     * Get the available payment methods.
     *
     * @return array
     */
    protected function get_available_payment_methods()
    {
        $methods = array();

        if ('yes' == $this->gateway->easypayment_cartao_credito) {
            $methods[] = 'cartao_credito';
        }
        if ('yes' == $this->gateway->easypayment_boleto) {
            $methods[] = 'boleto';
        }
        if ('yes' == $this->gateway->easypayment_carne) {
            $methods[] = 'carne';
        }
        if ('yes' == $this->gateway->easypayment_pix) {
            $methods[] = 'pix';
        }
        if ('yes' == $this->gateway->easypayment_assinatura) {
            $methods[] = 'assinatura';
        }

        return $methods;
    }

    /**
     * Do requests in the EasyPayment API.
     *
     * @param  string $url      URL.
     * @param  string $method   Request method.
     * @param  array  $data     Request data.
     * @param  array  $headers  Request headers.
     *
     * @return array            Request response.
     */
    protected function do_request($url, $method = 'POST', $data = array(), $headers = array())
    {
        $params = array(
            'method' => $method,
            'timeout' => 60,
        );

        if (('POST' == $method || 'PUT' == $method) && !empty($data)) {
            $params['body'] = $data;
        }

        if (!empty($headers)) {
            $params['headers'] = $headers;
        }

        $token = $this->gateway->get_token();

        $params['headers']['Authorization'] = "ApiKey $token";
        $params['headers']['Content-Type'] = "application/json";
        $processar = wp_safe_remote_post($url, $params);
        //print_r($processar);
        return $processar;
    }

    /**
     * Get order items.
     *
     * @param  WC_Order $order Order data.
     *
     * @return array           Items list, extra amount and shipping cost.
     */
    protected function get_order_items($order)
    {
        $items = array();
        $extra_amount = 0;
        $shipping_cost = 0;

        // Force only one item.
        if ('yes' == $this->gateway->send_only_total) {
            $items[] = array(
                'description' => $this->sanitize_description(sprintf(__('Order %s', 'woocommerce-easypayment'), $order->get_order_number())),
                'amount' => $this->money_format($order->get_total()),
                'quantity' => 1,
            );
        } else {

            // Products.
            if (0 < count($order->get_items())) {
                foreach ($order->get_items() as $order_item) {
                    if ($order_item['qty']) {
                        $item_total = $order->get_item_total($order_item, false);
                        if (0 >= (float) $item_total) {
                            continue;
                        }

                        $item_name = $order_item['name'];

                        if (defined('WC_VERSION') && version_compare(WC_VERSION, '3.0', '<')) {
                            if (defined('WC_VERSION') && version_compare(WC_VERSION, '2.4.0', '<')) {
                                $item_meta = new WC_Order_Item_Meta($order_item['item_meta']);
                            } else {
                                $item_meta = new WC_Order_Item_Meta($order_item);
                            }

                            if ($meta = $item_meta->display(true, true)) {
                                $item_name .= ' - ' . $meta;
                            }
                        }

                        $items[] = array(
                            'description' => $this->sanitize_description(str_replace('&ndash;', '-', $item_name)),
                            'amount' => $this->money_format($item_total),
                            'quantity' => $order_item['qty'],
                        );
                    }
                }
            }

            // Fees.
            if (0 < count($order->get_fees())) {
                foreach ($order->get_fees() as $fee) {
                    if (0 >= (float) $fee['line_total']) {
                        continue;
                    }

                    $items[] = array(
                        'description' => $this->sanitize_description($fee['name']),
                        'amount' => $this->money_format($fee['line_total']),
                        'quantity' => 1,
                    );
                }
            }

            // Taxes.
            if (0 < count($order->get_taxes())) {
                foreach ($order->get_taxes() as $tax) {
                    $tax_total = $tax['tax_amount'] + $tax['shipping_tax_amount'];
                    if (0 >= (float) $tax_total) {
                        continue;
                    }

                    $items[] = array(
                        'description' => $this->sanitize_description($tax['label']),
                        'amount' => $this->money_format($tax_total),
                        'quantity' => 1,
                    );
                }
            }

            // Shipping Cost.
            if (0 < $order->get_total_shipping()) {
                $shipping_cost = $this->money_format($order->get_total_shipping());
            }

            // Discount.
            if (defined('WC_VERSION') && version_compare(WC_VERSION, '2.3', '<')) {
                if (0 < $order->get_order_discount()) {
                    $extra_amount = '-' . $this->money_format($order->get_order_discount());
                }
            }
        }

        return array(
            'items' => $items,
            'extra_amount' => $extra_amount,
            'shipping_cost' => $shipping_cost,
        );
    }

}