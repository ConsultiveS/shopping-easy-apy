<?php

defined( 'ABSPATH' ) || exit;


//https://gist.github.com/leonirlopes/5a4a1f796c776d4a695b2d8ca78ab108
// PHP Máscara CNPJ, CPF, Data e qualquer outra coisa
// http://blog.clares.com.br/php-mascara-cnpj-cpf-data-e-qualquer-outra-coisa/
// ver em funcionamento ~~> https://ideone.com/wP7zN2

if( !function_exists('mask') ){
    function mask($val, $mask){
        $maskared = '';
        $k = 0;
        for ($i = 0; $i <= strlen($mask) - 1; ++$i) {
            if ($mask[$i] == '#') {
                if (isset($val[$k])) {
                    $maskared .= $val[$k++];
                }
            } else {
                if (isset($mask[$i])) {
                    $maskared .= $mask[$i];
                }
            }
        }
    
        return $maskared;
    }
}
/*
$cnpj = '11222333000199';
$cpf = '00100200300';
$cep = '08665110';
$data = '10102010';
$hora = '021050';

echo mask($cnpj, '##.###.###/####-##').'<br>';
echo mask($cpf, '###.###.###-##').'<br>';
echo mask($cep, '#####-###').'<br>';
echo mask($data, '##/##/####').'<br>';
echo mask($data, '##/##/####').'<br>';
echo mask($data, '[##][##][####]').'<br>';
echo mask($data, '(##)(##)(####)').'<br>';
echo mask($hora, 'Agora são ## horas ## minutos e ## segundos').'<br>';
echo mask($hora, '##:##:##');
*/

/**
 * Extrair somente os números de uma string
 * Source: https://www.codegrepper.com/code-examples/php/php+get+only+numbers+from+string
 * @param string $str
 * @return string
*/
function get_only_numbers($str) {
    preg_match_all('/\d+/', $str, $matches);
    return implode('', $matches[0]);
    //return $matches;
}


/**
 * POG: Get installments and return option with installments
 * @source get by selector  : https://stackoverflow.com/a/29108424
 * @source get by url       : https://stackoverflow.com/a/10922267/7691346
 * @param string : token generate from Easypayment
 * @example get_installments_easypayment('6466201c-1d01-4ba7-ad7e-80fadc61f70c');
 * @return string
*/
function get_installments_easypayment($token){
    $url_checkout = WC_EASYPAUMENT_URL_CHECKOUT;
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $dom->loadHTMLFile("$url_checkout/$token/");
    $xpath = new DOMXPath($dom);
    $data = $xpath->query("//select[@id='id_number_installments']/option");
    
    foreach ($xpath->evaluate('//option') as $opt){
        $textContent    = $opt->nodeValue;
        $valueContent   = $opt->getAttribute('value');
        $opts[] = "<option value=\"$valueContent\">$textContent</option>";
    }
    
    return $opts;
}