<?php
/**
 * Conexão para a administração suprema
 */
//defined( 'ABSPATH' ) || die('Você não tem poder aqui');

// Dados de autenticação
define('EASYPAYMENT_URL', 'https://sistema.shoppingeasypay.com.br');
define('EASYPAYMENT_KEY', '118366153253f980154ec728afb70e6e62ce79c9:HUQhqd69iRF_b-DGJnDcb5sSpNs');

function easypayment_runner($method, $url, $data)
{
    $api_key = EASYPAYMENT_KEY;
    $api_base = EASYPAYMENT_URL;
    $url_full = "$api_base/$url";

    $curl = curl_init();
    switch ($method) {
        case "POST":
            curl_setopt($curl, CURLOPT_POST, 1);
            if ($data)
                curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
            break;
        case "PUT":
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
            if ($data)
                curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
            break;
        default:
            if ($data)
                $url_full = sprintf("%s?%s", $url_full, http_build_query($data));
    }

    // OPTIONS:
    curl_setopt($curl, CURLOPT_URL, $url_full);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        "Authorization: ApiKey $api_key",
        "Content-Type: application/json",
    )
    );

    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);

    // EXECUTE:
    $result = curl_exec($curl);

    //if(!$result){die("Connection Failure");}
    curl_close($curl);
    return $result;
}
header("Content-type: application/json; charset=utf-8");
print easypayment_runner('GET', 'api/v1/sellers/', array());