<?php
/**
 * Webhook class to handle custom webhook
 *
 * Helps create the webhook url and also handling whatever is sent to the url :)
 *
 * @author Precious Omonze (Code Explorer) <https://github.com/Preciousomonze>
 * License: GPLv2 or later
 * @source https://github.com/Preciousomonze/wordpress-custom-webhook/blob/master/class-wp-webhook.php
 * @example https://yoursite.dev/dsp-api/easypayment
 * @source status code response: https://gist.github.com/phoenixg/5326222
 */

//defined( 'ABSPATH' ) || die( 'Você não tem poder aqui!' );

if (!class_exists('DSP_Webhook_easypayment')) {

    class DSP_Webhook_easypayment
    {

        private static $_instance = null;

        // These paramaters are for custom webhook
        //your url will look like https://site.com/eaysypayment-api/webhook
        // network_site_url( self::$webhook . DIRECTORY_SEPARATOR . self::$webhook_tag ); //this helps return the full url

        /**
         * Parent wekbhook
         * replace with a unique value you want
         * 
         * @var string
         */
        private static $webhook = 'eaysypayment-api';

        /**
         * webhook tag
         * replace with a unique value you want
         * 
         * @var string
         */
        private static $webhook_tag = 'webhook';

        /**
         * ini prefix, leave as it is :)
         * 
         * @var string
         */
        private static $ini_hook_prefix = 'dsp_';

        /**
         * Action to be triggered when the url is loaded
         * replace with a unique value you want
         * 
         * @var string
         */
        private static $webhook_action = 'hook_action';

        /**
         * Constructor :)
         */

        protected $api_key = 'some_api_key';

        public function __construct()
        {
            $this->Gateway = new WC_EasyPayment_Gateway;
            $this->token = $this->Gateway->settings['token'];
            $this->posted = $_POST; //Receber os dados do gateway
            //update_option( 'webhook_testes', maybe_serialize($_POST), false );
            add_action('init', array($this, 'setup'));
            add_action('parse_request', array($this, 'parse_request'));
            add_action(self::$ini_hook_prefix . self::$webhook_action, array($this, 'webhook_handler'));
        }

        public function setup()
        {
            $this->add_rewrite_rules_tags();
            $this->add_rewrite_rules();
        }

        /**
         * Get the API environment.
         * @return string
         */
        protected function get_environment()
        {
            return isset($this->Gateway->settings['sandbox']) && 'yes' == $this->Gateway->settings['sandbox'] ? WC_EASYPAYMENT_URL_SANDBOX : WC_EASYPAYMENT_URL_PRODUCTION;
        }

        /**
         * Joiner the webhook URL
         * @return string url
         */
        protected function this_webhook()
        {
            $webhook_url = array(
                site_url(),
                self::$webhook,
                self::$webhook_tag
            );
            return implode("/", $webhook_url);
        }

        /**
         * Handles the HTTP Request sent to your site's webhook
         */
        public function webhook_handler($objects)
        {
            $webhook_url = $this->this_webhook();

            $return['posted'] = $this->posted;
            $return['getted'] = $_GET;
            $return['getallheaders'] = getallheaders();
            $return['header_list'] = headers_list();

            //$return['headers']  = getallheaders();

            $listar_wh = $this->webhook_listar();

            $listar['body'] = json_decode($listar_wh['body'], true, JSON_UNESCAPED_SLASHES);
            $listar['response'] = $listar_wh['response'];

            //$get_saved = get_option( 'webhook_testes', true );

            if (isset($listar['body']['objects']) && count($listar['body']['objects']) > 0) {
                //echo "Tem webhook cadastrado, show()!";
            } else {

                $body_params['url'] = $webhook_url;
                $body_params['events'] = ["TRANSACTION.*", "TRANSFER.*"];

                $webhook_post = $this->webhook_criar(json_encode($body_params));
            }

            $return['code'] = http_response_code();
            $return['status'] = true;
            //$return['server']   = $_SERVER;
            $return['request'] = $_REQUEST;

            $this->logger($return);

            wp_send_json($return); //Pronto,, agora me faça feliz, funcione webhook!

            die();
        }

        public function parse_request(&$wp)
        {
            $ini = self::$ini_hook_prefix;
            if (array_key_exists(self::$webhook_tag, $wp->query_vars)) {
                do_action($ini . self::$webhook_action);
                die(0);
            }
        }

        protected function add_rewrite_rules_tags()
        {
            add_rewrite_tag('%' . self::$webhook_tag . '%', '([^&]+)');
        }

        protected function add_rewrite_rules()
        {
            add_rewrite_rule('^' . self::$webhook . '/([^/]*)/?', 'index.php?' . self::$webhook_tag . '=$matches[1]', 'top');
        }
        /**
         * Do requests in the EasyPayment API.
         *
         * @param  string $url      URL.
         * @param  string $method   Request method.
         * @param  array  $data     Request data.
         * @param  array  $headers  Request headers.
         *
         * @return array            Request response.
         */
        protected function do_request($url, $method = 'POST', $data = array(), $headers = array())
        {
            $params = array(
                'method' => $method,
                'timeout' => 60,
            );
            if (('POST' == $method || 'PUT' == $method || 'DELETE' == $method) && !empty($data)) {
                $params['body'] = $data;
            }
            if (!empty($headers)) {
                $params['headers'] = $headers;
            }
            $token = $this->token;
            $params['headers']['Authorization'] = "ApiKey $token";
            $params['headers']['Content-Type'] = "application/json";
            $processar = wp_safe_remote_post($url, $params);
            //print_r($processar);
            return $processar;
        }
        /**
         * Criando um Webhooks
         * @link https://sistema.shoppingeasypay.com.br/reference/criando-um-webhook/
         * @method POST
         */
        public function webhook_criar($body_params)
        {
            $url = $this->get_environment() . "/webhooks";
            $response = $this->do_request($url, 'POST', $body_params);
            $responsed['out']['body'] = $response['body'];
            $responsed['out']['response'] = $response['response'];
            return $responsed['out'];
        }
        /**
         * Removendo um Webhook
         * @link https://sistema.shoppingeasypay.com.br/reference/removendo-um-webhook/
         * @method DELETE
         * @param int $webhook_id
         */
        public function webhook_remover($webhook_id)
        {
            $url = $this->get_environment() . "/webhooks/$webhook_id";
            $response = $this->do_request($url, 'DELETE');
            $responsed['out']['body'] = $response['body'];
            $responsed['out']['response'] = $response['response'];
            return $responsed['out'];
        }
        /**
         * Consultando um Webhook
         * @link https://sistema.shoppingeasypay.com.br/reference/consultando-um-webhook/
         * @method GET
         * @param int $webhook_id
         */
        public function webhook_consultar($webhook_id)
        {
            $url = $this->get_environment() . "/webhooks/$webhook_id";
            $response = $this->do_request($url, 'GET');
            $responsed['out']['body'] = $response['body'];
            $responsed['out']['response'] = $response['response'];
            return $responsed['out'];
        }
        /**
         * Listando Webhooks
         * @link https://sistema.shoppingeasypay.com.br/reference/listando-webhooks/
         * @method GET
         */
        public function webhook_listar()
        {
            $url = $this->get_environment() . "/webhooks";
            $response = $this->do_request($url, 'GET');
            $responsed['out']['body'] = $response['body'];
            $responsed['out']['response'] = $response['response'];
            return $responsed['out'];
        }
        /**
         * Registrar LOG do webhook
         * Source 1: https://www.businessbloomer.com/woocommerce-create-custom-logs/
         * Source 2: https://developer.woocommerce.com/2017/01/26/improved-logging-in-woocommerce-2-7/
         */
        public function logger($datas = ['info' => 'Sem dados para mostrar'])
        {
            if (function_exists('wc_get_logger')) {
                $logger = wc_get_logger();
            } else {
                $logger = new WC_Logger();
            }
            $logger->add('EasyPayment', 'Response: ' . print_r($datas, true));
        }
    }

    add_action('rest_api_init', function () {
        //$_SERVER['REQUEST_METHOD'] = 'POST';
        new DSP_Webhook_easypayment;
        header("HTTP/1.1 200 OK");
        header("User-Agent: python-requests/2.25.1");
        header("Accept-Encoding: gzip, deflate, br");
        header("Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7");
        header("Accept: application/json");
        header("Content-Type: application/json");
        //header( "Token: ");

        header('X-Powered-By: DanSP - https://t.me/dansp89');
    });

}