<?php

/** 
 * List categories  : https://docs.google.com/spreadsheets/d/1YXAZ9DZu3YH2vwKnC7BKQQNnPTS70u8QjofdxUD0WQ4/edit#gid=0
 * Conversion       : https://csvjson.com/csv2json
 * 
 * @example url http://youdomain.com/wp-json/wp/v2/easypayment_api/webhook || http://youdomain.com/api/wp/v2/easypayment_api/webhook
 * @endpoints google-my-business
 * 
 * @link SCHEMA https://developer.wordpress.org/rest-api/extending-the-rest-api/schema/#argument-schema
 * @link SCHEMA https://developer.wordpress.org/rest-api/extending-the-rest-api/schema/
 * @link register_rest_route https://developer.wordpress.org/rest-api/extending-the-rest-api/adding-custom-endpoints/
 * @link headers https://gist.github.com/phoenixg/5326222
 * @return mixed
 * @author DanSP <daniel.rootdir@gmail.com>
 * 
 * @example args https://www.shawnhooper.ca/2017/02/15/wp-rest-secrets-found-reading-core-code/
 * Args types array|boolean|integer|number|string
 * 
 * @doc api rest https://developer.wordpress.org/rest-api/reference/post-types/
 * //(?P<id>\d+)
 */

defined('ABSPATH') || die('You have no power here!');

class DSP_API_REST_webhook_easypayment
{
    public function __construct()
    {
        global $whitelist_easypayment_domain;

        $this->Gateway = new WC_EasyPayment_Gateway;
        $this->token = $this->Gateway->settings['token'];

        $this->domains = $whitelist_easypayment_domain;
        $version = '2';
        $base = 'easypayment_api';
        $endpoint = 'webhook';

        $this->url_webhook = "wp/v$version/$base/$endpoint";

        register_rest_route(
            "wp/v$version",
            "/$base/$endpoint",
            array(
                array(
                    'methods' => WP_REST_Server::CREATABLE,
                    'callback' => array($this, 'dsp_easypayment_webhook'),
                    'permission_callback' => '__return_true',
                ),
            )
        );
    }

    /**
     * Process the result from payloader external
     * @link Documentation, see more    : https://sistema.shoppingeasypay.com.br/docs/webhook-2/
     * @link Events receiver, see more  : https://sistema.shoppingeasypay.com.br/reference/tipos-de-eventos/
     * 
     */
    public function dsp_easypayment_webhook(WP_REST_Request $request)
    {
        $params_body = $request->get_body_params();
        $params_json = $request->get_json_params();
        $params_header = $request->get_headers();

        //$param_json     = iconv('UTF-8', 'UTF-8//IGNORE', utf8_encode($param_json));

        $gatewayName = "<b>" . ucfirst($this->Gateway->id) . "</b>";

        $whitelist = $this->domains; //Domains allow
        $payload['type'] = explode('.', $params_json['type'])[0];
        $payload['referer'] = $_SERVER['REMOTE_ADDR'];
        $payload['domains'] = $whitelist;
        $payload['consultant_domain'] = $_SERVER['HTTP_HOST'];
        $payload['headers'] = $params_header;
        $payload['webhook_token_received'] = isset($payload['headers']['token'][0]) ? sanitize_text_field($payload['headers']['token'][0]) : false;
        $payload['webhook_this_url'] = get_rest_url(null, $this->url_webhook);

        //BEGIN::Verificar se tem um webhook cadastrado, senão será cadastrado com base nesse domínio
        $listar_wh = $this->webhook_listar();
        $listar['body'] = json_decode($listar_wh['body'], true, JSON_UNESCAPED_SLASHES);
        $listar['response'] = $listar_wh['response'];
        if (isset($listar['body']['objects']) && count($listar['body']['objects']) > 0) {
            $payload['webhook_registered'] = true;
        } else {
            $payload['webhook_registered'] = false;
            $body_params['url'] = $payload['webhook_url'];
            $body_params['events'] = ["TRANSACTION.*", "TRANSFER.*"];
            $webhook_post = $this->webhook_criar(json_encode($body_params));

        }
        $payload['webhook_list'] = isset($listar['body']['objects']) ? $listar['body']['objects'] : false;
        $payload['webhook_token_autorized'] = false;

        if ($payload['webhook_list'] !== false) {
            foreach ($payload['webhook_list'] as $objectsWebhook) {
                if ($objectsWebhook['url'] == $payload['webhook_this_url']) {
                    $payload['webhook_token_autorized'] = $objectsWebhook['token'];
                    break;
                }
            }
        }
        //END::Verificar se tem um webhook cadastrado, senão será cadastrado com base nesse domínio

        // if( !in_array( $_SERVER['REMOTE_ADDR'], $whitelist) ){
        //     header( "HTTP/1.1 401 Unauthorized" );
        //     $payload['code']    = 'Unauthorized';
        //     $payload['message'] = 'EASYPAYMENT: This domain is not authorized for connection, contact the administrator.';
        //     $payload['status']  = http_response_code();
        // } else { //OK, process now 
        header("HTTP/1.1 200 OK");
        $payload['post'] = json_encode($payload);
        $payload['get_body_params'] = $params_body;
        $payload['get_json_params'] = $params_json;
        $payload['status'] = http_response_code();
        //}

        //BEGIN::Processar transações de pedidos/Compras/pagamentos
        //Source: https://sistema.shoppingeasypay.com.br/reference/tipos-de-eventos/
        if ($payload['type'] === "TRANSACTION") {
            $payload['id'] = isset($params_json['resource']['transaction']['id']) ? $params_json['resource']['transaction']['id'] : false;    //ID from EasyPayment
            $payload['order_id'] = isset($payload["id"]) ? $this->getOrderByMetaValue("id", sanitize_text_field($payload["id"])) : false;//ID from Woocommerce
            $order_status = isset($params_json['resource']['transaction']['status']) ? sanitize_text_field($params_json['resource']['transaction']['status']) : false;//Status returned from Easypayment

            $payload['statusWoocommerce'] = $this->statusConverte();
            $payload['woocommerce_order_status'] = $order_status !== false ? $payload['statusWoocommerce'][$order_status]['status'] : false;
            if ($payload['webhook_token_autorized'] === $payload['webhook_token_received']) {
                $payload['token_allowed'] = true;
                $payload['code'] = 200;

                if ($payload['order_id'] > 0) {
                    $payload['message'] = "$gatewayName: Processing order";
                    $payload['order_exists_in_woocommerce'] = true;
                    $status_for_woocommerce = $payload['woocommerce_order_status']; //Get status order
                    $order = new WC_Order($payload['order_id']);
                    $order->update_status("wc-$status_for_woocommerce");
                    $order->add_order_note(sprintf("$gatewayName: Order #%s updated to status \"%s\" through the webhook", $order->get_order_number(), __("$status_for_woocommerce", "woocommerce")));
                } else {
                    $payload['message'] = "$gatewayName: Unable to process order as it does not exist in Woocommerce";
                    $payload['woocommerce_order_status'] = 'failed';
                    $payload['order_exists_in_woocommerce'] = false;
                }
            } else {
                $payload['token_allowed'] = false;
                $payload['code'] = 410;
                $payload['message'] = "$gatewayName: This token is not authorized for connection, contact the administrator";
            }
        }
        //END::Processar transações de pedidos

        //BEGIN::Processar transações de transferências financeiras
        if ($payload['type'] === "TRANSFER") {
            //Nada por enquanto
        }
        //END::Processar transações de transferências

        $this->logger($payload);

        //BEGIN::Remove dados sensíveis da resposta JSON
        foreach (['domains', 'consultant_domain', 'headers', 'webhook_token_received', 'webhook_list', 'webhook_token_autorized', 'post', 'get_body_params', 'get_json_params', 'statusWoocommerce'] as $removeKey) {
            if (array_key_exists($removeKey, $payload) === true) {
                unset($payload[$removeKey]);
            }
        }
        ksort($payload);
        //END::Remove dados sensíveis da resposta JSON
        return new WP_REST_Response($payload, $payload['statusWoocommerce']['code']);
    }

    /**
     * Registrar LOG do webhook
     * Source 1: https://www.businessbloomer.com/woocommerce-create-custom-logs/
     * Source 2: https://developer.woocommerce.com/2017/01/26/improved-logging-in-woocommerce-2-7/
     */
    public function logger($datas = ['info' => 'Sem dados para mostrar'])
    {
        if (function_exists('wc_get_logger')) {
            $logger = wc_get_logger();
        } else {
            $logger = new WC_Logger();
        }
        $logger->add('EasyPayment', 'Response: ' . print_r($datas, true));
    }

    /**
     * Return an ID order based in 'meta_key' and 'meta_value' and return ORDER ID
     * @param string $meta_key
     * @param string $meta_value
     * @return integer
     */
    public function getOrderByMetaValue($meta_key = false, $meta_value = false)
    {
        global $post, $product;
        if ($meta_key !== false && $meta_value !== false) {
            $params = array(
                'post_type' => 'shop_order',
                'post_status' => 'published',
                'fields' => 'ids',
                'posts_per_page' => 1,
                'meta_query' => array(
                    array(
                        'key' => $meta_key,
                        'value' => $meta_value,
                    )
                )
            );

            $wc_query = new WP_Query($params);
            wp_reset_postdata();
            return $wc_query->have_posts() ? $wc_query->posts[0] : 0;
        }
        return 0;
    }

    /**
     * Convert order status from Easypayment to woocommerce
     * $key == easypayment order status
     * $val == woocommerce order status
     */
    public function statusConverte()
    {
        return array(
            'pending' => ['status' => 'pending', 'code' => 400],
            'in_analysis' => ['status' => 'processing', 'code' => 400],
            'succeeded' => ['status' => 'completed', 'code' => 200],
            'failed' => ['status' => 'failed', 'code' => 400],
            'reversed' => ['status' => 'refunded', 'code' => 400],
            'canceled' => ['status' => 'cancelled', 'code' => 400],
            'refunded' => ['status' => 'refunded', 'code' => 400],
            'dispute' => ['status' => 'dispute', 'code' => 400],
            'charged_back' => ['status' => 'charged_back', 'code' => 400]
        );
    }
    /**
     * Do requests in the EasyPayment API.
     *
     * @param  string $url      URL.
     * @param  string $method   Request method.
     * @param  array  $data     Request data.
     * @param  array  $headers  Request headers.
     *
     * @return array            Request response.
     */
    protected function do_request($url, $method = 'POST', $data = array(), $headers = array())
    {
        $params = array(
            'method' => $method,
            'timeout' => 60,
        );
        if (('POST' == $method || 'PUT' == $method || 'DELETE' == $method) && !empty($data)) {
            $params['body'] = $data;
        }
        if (!empty($headers)) {
            $params['headers'] = $headers;
        }
        $token = $this->token;
        $params['headers']['Authorization'] = "ApiKey $token";
        $params['headers']['Content-Type'] = "application/json";
        $processar = wp_safe_remote_post($url, $params);
        //print_r($processar);
        return $processar;
    }
    /**
     * Criando um Webhooks
     * @link https://sistema.shoppingeasypay.com.br/reference/criando-um-webhook/
     * @method POST
     */
    public function webhook_criar($body_params)
    {
        $url = $this->get_environment() . "/webhooks";
        $response = $this->do_request($url, 'POST', $body_params);
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }
    /**
     * Removendo um Webhook
     * @link https://sistema.shoppingeasypay.com.br/reference/removendo-um-webhook/
     * @method DELETE
     * @param int $webhook_id
     */
    public function webhook_remover($webhook_id)
    {
        $url = $this->get_environment() . "/webhooks/$webhook_id";
        $response = $this->do_request($url, 'DELETE');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }
    /**
     * Consultando um Webhook
     * @link https://sistema.shoppingeasypay.com.br/reference/consultando-um-webhook/
     * @method GET
     * @param int $webhook_id
     */
    public function webhook_consultar($webhook_id)
    {
        $url = $this->get_environment() . "/webhooks/$webhook_id";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }
    /**
     * Listando Webhooks
     * @link https://sistema.shoppingeasypay.com.br/reference/listando-webhooks/
     * @method GET
     */
    public function webhook_listar()
    {
        $url = $this->get_environment() . "/webhooks";
        $response = $this->do_request($url, 'GET');
        $responsed['out']['body'] = $response['body'];
        $responsed['out']['response'] = $response['response'];
        return $responsed['out'];
    }
    /**
     * Get the API environment.
     * @return string
     */
    protected function get_environment()
    {
        return isset($this->Gateway->settings['sandbox']) && 'yes' == $this->Gateway->settings['sandbox'] ? WC_EASYPAYMENT_URL_SANDBOX : WC_EASYPAYMENT_URL_PRODUCTION;
    }
}

add_action('rest_api_init', function () {
    error_reporting(E_ERROR | E_PARSE);
    header("HTTP/1.1 200 OK");
    header("User-Agent: python-requests/2.25.1");
    header("Accept-Encoding: gzip, deflate, br");
    header("Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7");
    header("Accept: application/json");
    // header( "Content-Type: application/json" );
    new DSP_API_REST_webhook_easypayment;
}, 21);